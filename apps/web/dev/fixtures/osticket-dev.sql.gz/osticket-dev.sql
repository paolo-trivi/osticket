/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: osticket
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ost__search`
--

DROP TABLE IF EXISTS `ost__search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost__search` (
  `object_type` varchar(8) NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  PRIMARY KEY (`object_type`,`object_id`),
  FULLTEXT KEY `search` (`title`,`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost__search`
--

LOCK TABLES `ost__search` WRITE;
/*!40000 ALTER TABLE `ost__search` DISABLE KEYS */;
INSERT INTO `ost__search` VALUES
('H',2,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',3,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',4,'','Il problema si ripresenta dopo pranzo.'),
('H',5,'Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.'),
('H',6,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',7,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',8,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',9,'','Il problema si ripresenta dopo pranzo.'),
('H',10,'Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.'),
('H',11,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',12,'','Grazie, ora funziona.'),
('H',13,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',14,'Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.'),
('H',15,'','Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?'),
('H',16,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',17,'Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".'),
('H',18,'','Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?'),
('H',19,'','Il problema si ripresenta dopo pranzo.'),
('H',20,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',21,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',22,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',23,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',24,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',25,'','Il problema si ripresenta dopo pranzo.'),
('H',26,'Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".'),
('H',27,'Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.'),
('H',28,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',29,'','Il problema si ripresenta dopo pranzo.'),
('H',30,'Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.'),
('H',31,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',32,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',33,'Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.'),
('H',34,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',35,'','Grazie, ora funziona.'),
('H',36,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',37,'Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".'),
('H',38,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',39,'','Il problema si ripresenta dopo pranzo.'),
('H',40,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',41,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',42,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',43,'Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.'),
('H',44,'Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.'),
('H',45,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',46,'','Il problema si ripresenta dopo pranzo.'),
('H',47,'Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.'),
('H',48,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',49,'Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.'),
('H',50,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',51,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',52,'Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".'),
('H',53,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',54,'','Ecco il numero di inventario: INV-2026-0451.'),
('H',55,'Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.'),
('H',56,'Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.'),
('H',57,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',58,'','Ecco il numero di inventario: INV-2026-0451.'),
('H',59,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',60,'Telefono IP senza linea','Il telefono IP della guardiola non ha linea, il display è spento.'),
('H',61,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',62,'','Ecco il numero di inventario: INV-2026-0451.'),
('H',63,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',64,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',65,'Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.'),
('H',66,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',67,'Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".'),
('H',68,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',69,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',70,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',71,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',72,'','Grazie, ora funziona.'),
('H',73,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',74,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',75,'','Il problema si ripresenta dopo pranzo.'),
('H',76,'Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.'),
('H',77,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',78,'','Il problema si ripresenta dopo pranzo.'),
('H',79,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',80,'Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.'),
('H',81,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',82,'Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.'),
('H',83,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',84,'','Grazie, ora funziona.'),
('H',85,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',86,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',87,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',88,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',89,'Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.'),
('H',90,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',91,'','Il problema si ripresenta dopo pranzo.'),
('H',92,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',93,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',94,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',95,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',96,'','Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?'),
('H',97,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',98,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',99,'Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".'),
('H',100,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',101,'','Il problema si ripresenta dopo pranzo.'),
('H',102,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',103,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',104,'Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.'),
('H',105,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',106,'','Ecco il numero di inventario: INV-2026-0451.'),
('H',107,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',108,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',109,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',110,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',111,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',112,'Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.'),
('H',113,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',114,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',115,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',116,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',117,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',118,'Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.'),
('H',119,'Nota tecnica','In attesa del fornitore per la sostituzione.'),
('H',120,'Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".'),
('H',121,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',122,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',123,'Nota tecnica','Verificato da remoto: servizio di spooling bloccato.'),
('H',124,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',125,'Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.'),
('H',126,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',127,'Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.'),
('H',128,'Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.'),
('H',129,'Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.'),
('H',130,'','Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.'),
('H',131,'Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".'),
('H',132,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',133,'','Grazie, ora funziona.'),
('H',134,'PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.'),
('H',135,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',136,'','Il problema si ripresenta dopo pranzo.'),
('H',137,'Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".'),
('H',138,'','Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?'),
('H',139,'','Grazie, ora funziona.'),
('H',140,'Nota tecnica','Possibile problema di rete sullo switch di piano.'),
('H',141,'Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.'),
('H',142,'','Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.'),
('H',143,'Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.'),
('H',144,'','Ci serve il numero di inventario del dispositivo per procedere.'),
('H',149,'Task 4 Closed','Task closed'),
('H',154,'Task 8 Closed','Task closed'),
('H',159,'Task 12 Closed','Task closed'),
('K',1,'Come richiedere un nuovo PC','Apri un ticket con argomento Report a Problem indicando reparto e numero di inventario.'),
('K',2,'Stampante di rete: cosa controllare','Verifica che sia accesa Controlla la carta Riavvia la coda di stampa'),
('K',3,'Accesso al FSE','Per accedere al Fascicolo Sanitario Elettronico serve la smart card abilitata.'),
('K',4,'Referti LIS non visibili','Controlla che la richiesta sia stata accettata dal laboratorio.'),
('K',5,'Reset password di dominio','Procedura riservata agli agenti: verifica identità, poi reset da console AD.'),
('O',2,'Radiologia',''),
('O',3,'Cardiologia',''),
('O',4,'Laboratorio Analisi',''),
('O',5,'Amministrazione',''),
('O',6,'Pronto Soccorso',''),
('T',2,'390395 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',3,'636845 Richiesta nuovo account per specializzando','Richiesta nuovo account per specializzando'),
('T',4,'958530 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',5,'926134 Errore invio ordine al magazzino','Errore invio ordine al magazzino'),
('T',6,'655927 Referti LIS non arrivano in cartella','Referti LIS non arrivano in cartella'),
('T',7,'394495 Stampante del reparto non stampa','Stampante del reparto non stampa'),
('T',8,'341214 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',9,'896022 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',10,'139774 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',11,'668749 Accesso al FSE non funziona','Accesso al FSE non funziona'),
('T',12,'753017 Casella email piena','Casella email piena'),
('T',13,'340049 Errore invio ordine al magazzino','Errore invio ordine al magazzino'),
('T',14,'537052 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',15,'289251 Richiesta installazione software DICOM viewer','Richiesta installazione software DICOM viewer'),
('T',16,'899763 Stampante del reparto non stampa','Stampante del reparto non stampa'),
('T',17,'241142 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',18,'247087 Casella email piena','Casella email piena'),
('T',19,'885820 Referti LIS non arrivano in cartella','Referti LIS non arrivano in cartella'),
('T',20,'148075 Referti LIS non arrivano in cartella','Referti LIS non arrivano in cartella'),
('T',21,'930834 Errore invio ordine al magazzino','Errore invio ordine al magazzino'),
('T',22,'854315 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',23,'647566 Stampante del reparto non stampa','Stampante del reparto non stampa'),
('T',24,'915323 Casella email piena','Casella email piena'),
('T',25,'838444 Referti LIS non arrivano in cartella','Referti LIS non arrivano in cartella'),
('T',26,'581759 Telefono IP senza linea','Telefono IP senza linea'),
('T',27,'853680 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',28,'820971 Richiesta nuovo account per specializzando','Richiesta nuovo account per specializzando'),
('T',29,'213831 Stampante del reparto non stampa','Stampante del reparto non stampa'),
('T',30,'973732 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',31,'699697 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',32,'476002 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',33,'394713 Wi-Fi assente in sala riunioni','Wi-Fi assente in sala riunioni'),
('T',34,'122134 Casella email piena','Casella email piena'),
('T',35,'382601 Richiesta nuovo account per specializzando','Richiesta nuovo account per specializzando'),
('T',36,'444625 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',37,'819979 Richiesta installazione software DICOM viewer','Richiesta installazione software DICOM viewer'),
('T',38,'704370 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',39,'599363 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',40,'543523 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',41,'214892 Accesso al FSE non funziona','Accesso al FSE non funziona'),
('T',42,'960957 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',43,'683843 Wi-Fi assente in sala riunioni','Wi-Fi assente in sala riunioni'),
('T',44,'702612 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',45,'226810 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',46,'305907 Richiesta nuovo account per specializzando','Richiesta nuovo account per specializzando'),
('T',47,'420192 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',48,'223782 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',49,'224835 Wi-Fi assente in sala riunioni','Wi-Fi assente in sala riunioni'),
('T',50,'305894 Stampante del reparto non stampa','Stampante del reparto non stampa'),
('T',51,'767502 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',52,'441565 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',53,'762918 Richiesta installazione software DICOM viewer','Richiesta installazione software DICOM viewer'),
('T',54,'414769 Errore invio ordine al magazzino','Errore invio ordine al magazzino'),
('T',55,'554187 Monitor guasto postazione triage','Monitor guasto postazione triage'),
('T',56,'535972 Badge non abilitato al varco','Badge non abilitato al varco'),
('T',57,'950873 Accesso al FSE non funziona','Accesso al FSE non funziona'),
('T',58,'671799 PC lentissimo in ambulatorio 3','PC lentissimo in ambulatorio 3'),
('T',59,'103500 Accesso al FSE non funziona','Accesso al FSE non funziona'),
('T',60,'423938 Richiesta nuovo account per specializzando','Richiesta nuovo account per specializzando'),
('T',61,'916831 Errore invio ordine al magazzino','Errore invio ordine al magazzino'),
('U',2,'Francesca Romano','(087) 447-9717 f.romano@ospedale.example\nf.romano@ospedale.example'),
('U',3,'Luca Ferrari','(087) 441-2492 l.ferrari@ospedale.example\nl.ferrari@ospedale.example'),
('U',4,'Sara Colombo','(087) 443-2615 s.colombo@ospedale.example\ns.colombo@ospedale.example'),
('U',5,'Paolo Ricci','(087) 448-9202 p.ricci@ospedale.example\np.ricci@ospedale.example'),
('U',6,'Elena Marino','(087) 442-3159 e.marino@ospedale.example\ne.marino@ospedale.example'),
('U',7,'Davide Greco','(087) 448-6930 d.greco@ospedale.example\nd.greco@ospedale.example'),
('U',8,'Chiara Bruno','(087) 444-3743 c.bruno@ospedale.example\nc.bruno@ospedale.example'),
('U',9,'Marco Gallo','(087) 441-7379 m.gallo@ospedale.example\nm.gallo@ospedale.example'),
('U',10,'Anna Conti','(087) 448-1295 a.conti@ospedale.example\na.conti@ospedale.example'),
('U',11,'Giorgio De Luca','(087) 446-1528 g.deluca@ospedale.example\ng.deluca@ospedale.example'),
('U',12,'Martina Costa','(087) 449-4187 m.costa@ospedale.example\nm.costa@ospedale.example'),
('U',13,'Stefano Giordano','(087) 448-4635 s.giordano@ospedale.example\ns.giordano@ospedale.example');
/*!40000 ALTER TABLE `ost__search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_api_key`
--

DROP TABLE IF EXISTS `ost_api_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_api_key` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) NOT NULL DEFAULT 1,
  `ipaddr` varchar(64) NOT NULL,
  `apikey` varchar(255) NOT NULL,
  `can_create_tickets` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `can_exec_cron` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `apikey` (`apikey`),
  KEY `ipaddr` (`ipaddr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_api_key`
--

LOCK TABLES `ost_api_key` WRITE;
/*!40000 ALTER TABLE `ost_api_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_api_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_attachment`
--

DROP TABLE IF EXISTS `ost_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) unsigned NOT NULL,
  `type` char(1) NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inline` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `lang` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file-type` (`object_id`,`file_id`,`type`),
  UNIQUE KEY `file_object` (`file_id`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_attachment`
--

LOCK TABLES `ost_attachment` WRITE;
/*!40000 ALTER TABLE `ost_attachment` DISABLE KEYS */;
INSERT INTO `ost_attachment` VALUES
(1,1,'C',2,NULL,0,NULL),
(2,8,'T',1,NULL,1,NULL),
(3,9,'T',1,NULL,1,NULL),
(4,10,'T',1,NULL,1,NULL),
(5,11,'T',1,NULL,1,NULL),
(6,12,'T',1,NULL,1,NULL),
(7,13,'T',1,NULL,1,NULL),
(8,14,'T',1,NULL,1,NULL),
(9,16,'T',1,NULL,1,NULL),
(10,17,'T',1,NULL,1,NULL),
(11,18,'T',1,NULL,1,NULL),
(12,19,'T',1,NULL,1,NULL);
/*!40000 ALTER TABLE `ost_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_canned_response`
--

DROP TABLE IF EXISTS `ost_canned_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_canned_response` (
  `canned_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `isenabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `response` text NOT NULL,
  `lang` varchar(16) NOT NULL DEFAULT 'en_US',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`canned_id`),
  UNIQUE KEY `title` (`title`),
  KEY `dept_id` (`dept_id`),
  KEY `active` (`isenabled`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_canned_response`
--

LOCK TABLES `ost_canned_response` WRITE;
/*!40000 ALTER TABLE `ost_canned_response` DISABLE KEYS */;
INSERT INTO `ost_canned_response` VALUES
(1,0,1,'What is osTicket (sample)?','osTicket is a widely-used open source support ticket system, an\nattractive alternative to higher-cost and complex customer support\nsystems - simple, lightweight, reliable, open source, web-based and easy\nto setup and use.','en_US',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,0,1,'Sample (with variables)','Hi %{ticket.name.first},\n<br>\n<br>\nYour ticket #%{ticket.number} created on %{ticket.create_date} is in\n%{ticket.dept.name} department.','en_US',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_canned_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_config`
--

DROP TABLE IF EXISTS `ost_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(64) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `namespace` (`namespace`,`key`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_config`
--

LOCK TABLES `ost_config` WRITE;
/*!40000 ALTER TABLE `ost_config` DISABLE KEYS */;
INSERT INTO `ost_config` VALUES
(1,'core','admin_email','admin@example.com','2026-10-08 06:22:17'),
(2,'core','helpdesk_url','http://localhost:8080/','2026-10-08 06:22:17'),
(3,'core','helpdesk_title','Helpdesk DEV','2026-10-08 06:22:17'),
(4,'core','schema_signature','5fb92bef17f3b603659e024c01cc7a59','2026-10-08 06:22:17'),
(5,'schedule.1','configuration','{\"holidays\":[4]}','2026-10-08 06:22:17'),
(6,'core','time_format','hh:mm a','2026-10-08 06:22:17'),
(7,'core','date_format','MM/dd/y','2026-10-08 06:22:17'),
(8,'core','datetime_format','MM/dd/y h:mm a','2026-10-08 06:22:17'),
(9,'core','daydatetime_format','EEE, MMM d y h:mm a','2026-10-08 06:22:17'),
(10,'core','default_priority_id','2','2026-10-08 06:22:17'),
(11,'core','enable_daylight_saving','','2026-10-08 06:22:17'),
(12,'core','reply_separator','-- reply above this line --','2026-10-08 06:22:17'),
(13,'core','isonline','1','2026-10-08 06:22:17'),
(14,'core','staff_ip_binding','','2026-10-08 06:22:17'),
(15,'core','staff_max_logins','4','2026-10-08 06:22:17'),
(16,'core','staff_login_timeout','2','2026-10-08 06:22:17'),
(17,'core','staff_session_timeout','30','2026-10-08 06:22:17'),
(18,'core','passwd_reset_period','','2026-10-08 06:22:17'),
(19,'core','client_max_logins','4','2026-10-08 06:22:17'),
(20,'core','client_login_timeout','2','2026-10-08 06:22:17'),
(21,'core','client_session_timeout','30','2026-10-08 06:22:17'),
(22,'core','max_page_size','25','2026-10-08 06:22:17'),
(23,'core','max_open_tickets','','2026-10-08 06:22:17'),
(24,'core','autolock_minutes','3','2026-10-08 06:22:17'),
(25,'core','default_smtp_id','','2026-10-08 06:22:17'),
(26,'core','use_email_priority','','2026-10-08 06:22:17'),
(27,'core','enable_kb','','2026-10-08 06:22:17'),
(28,'core','enable_premade','1','2026-10-08 06:22:17'),
(29,'core','enable_captcha','','2026-10-08 06:22:17'),
(30,'core','enable_auto_cron','','2026-10-08 06:22:17'),
(31,'core','enable_mail_polling','','2026-10-08 06:22:17'),
(32,'core','send_sys_errors','1','2026-10-08 06:22:17'),
(33,'core','send_sql_errors','1','2026-10-08 06:22:17'),
(34,'core','send_login_errors','1','2026-10-08 06:22:17'),
(35,'core','save_email_headers','1','2026-10-08 06:22:17'),
(36,'core','strip_quoted_reply','1','2026-10-08 06:22:17'),
(37,'core','ticket_autoresponder','','2026-10-08 06:22:17'),
(38,'core','message_autoresponder','','2026-10-08 06:22:17'),
(39,'core','ticket_notice_active','1','2026-10-08 06:22:17'),
(40,'core','ticket_alert_active','1','2026-10-08 06:22:17'),
(41,'core','ticket_alert_admin','1','2026-10-08 06:22:17'),
(42,'core','ticket_alert_dept_manager','1','2026-10-08 06:22:17'),
(43,'core','ticket_alert_dept_members','','2026-10-08 06:22:17'),
(44,'core','message_alert_active','1','2026-10-08 06:22:17'),
(45,'core','message_alert_laststaff','1','2026-10-08 06:22:17'),
(46,'core','message_alert_assigned','1','2026-10-08 06:22:17'),
(47,'core','message_alert_dept_manager','','2026-10-08 06:22:17'),
(48,'core','note_alert_active','','2026-10-08 06:22:17'),
(49,'core','note_alert_laststaff','1','2026-10-08 06:22:17'),
(50,'core','note_alert_assigned','1','2026-10-08 06:22:17'),
(51,'core','note_alert_dept_manager','','2026-10-08 06:22:17'),
(52,'core','transfer_alert_active','','2026-10-08 06:22:17'),
(53,'core','transfer_alert_assigned','','2026-10-08 06:22:17'),
(54,'core','transfer_alert_dept_manager','1','2026-10-08 06:22:17'),
(55,'core','transfer_alert_dept_members','','2026-10-08 06:22:17'),
(56,'core','overdue_alert_active','1','2026-10-08 06:22:17'),
(57,'core','overdue_alert_assigned','1','2026-10-08 06:22:17'),
(58,'core','overdue_alert_dept_manager','1','2026-10-08 06:22:17'),
(59,'core','overdue_alert_dept_members','','2026-10-08 06:22:17'),
(60,'core','assigned_alert_active','1','2026-10-08 06:22:17'),
(61,'core','assigned_alert_staff','1','2026-10-08 06:22:17'),
(62,'core','assigned_alert_team_lead','','2026-10-08 06:22:17'),
(63,'core','assigned_alert_team_members','','2026-10-08 06:22:17'),
(64,'core','auto_claim_tickets','1','2026-10-08 06:22:17'),
(65,'core','auto_refer_closed','1','2026-10-08 06:22:17'),
(66,'core','collaborator_ticket_visibility','1','2026-10-08 06:22:17'),
(67,'core','require_topic_to_close','','2026-10-08 06:22:17'),
(68,'core','show_related_tickets','1','2026-10-08 06:22:17'),
(69,'core','show_assigned_tickets','1','2026-10-08 06:22:17'),
(70,'core','show_answered_tickets','','2026-10-08 06:22:17'),
(71,'core','hide_staff_name','','2026-10-08 06:22:17'),
(72,'core','disable_agent_collabs','','2026-10-08 06:22:17'),
(73,'core','overlimit_notice_active','','2026-10-08 06:22:17'),
(74,'core','email_attachments','1','2026-10-08 06:22:17'),
(75,'core','ticket_number_format','######','2026-10-08 06:22:17'),
(76,'core','ticket_sequence_id','','2026-10-08 06:22:17'),
(77,'core','queue_bucket_counts','','2026-10-08 06:22:17'),
(78,'core','allow_external_images','','2026-10-08 06:22:17'),
(79,'core','task_number_format','#','2026-10-08 06:22:17'),
(80,'core','task_sequence_id','2','2026-10-08 06:22:17'),
(81,'core','log_level','2','2026-10-08 06:22:17'),
(82,'core','log_graceperiod','12','2026-10-08 06:22:17'),
(83,'core','client_registration','public','2026-10-08 06:22:17'),
(84,'core','default_ticket_queue','1','2026-10-08 06:22:17'),
(85,'core','embedded_domain_whitelist','youtube.com, dailymotion.com, vimeo.com, player.vimeo.com, web.microsoftstream.com','2026-10-08 06:22:17'),
(86,'core','max_file_size','1048576','2026-10-08 06:22:17'),
(87,'core','landing_page_id','1','2026-10-08 06:22:17'),
(88,'core','thank-you_page_id','2','2026-10-08 06:22:17'),
(89,'core','offline_page_id','3','2026-10-08 06:22:17'),
(90,'core','system_language','en_US','2026-10-08 06:22:17'),
(91,'mysqlsearch','reindex','1','2026-10-08 06:22:17'),
(92,'core','default_email_id','1','2026-10-08 06:22:17'),
(93,'core','alert_email_id','2','2026-10-08 06:22:17'),
(94,'core','default_dept_id','1','2026-10-08 06:22:17'),
(95,'core','default_sla_id','1','2026-10-08 06:22:17'),
(96,'core','schedule_id','1','2026-10-08 06:22:17'),
(97,'core','default_template_id','1','2026-10-08 06:22:17'),
(98,'core','default_timezone','Europe/Rome','2026-10-08 06:22:17'),
(99,'nextui.theme','primary_color','#0e7490','2026-10-08 06:48:19'),
(100,'nextui.theme','mode_default','light','2026-10-08 06:48:19'),
(101,'nextui.theme','allow_user_mode','1','2026-10-08 06:48:19'),
(102,'nextui.theme','sidebar_style','dark','2026-10-08 06:48:19'),
(103,'nextui.theme','font','inter','2026-10-08 06:48:19'),
(104,'nextui.theme','radius','xl','2026-10-08 06:48:19'),
(105,'nextui.theme','density','comfortable','2026-10-08 06:48:19'),
(106,'nextui.theme','app_name','RRH Helpdesk IT','2026-10-08 06:48:19'),
(107,'nextui.theme','login_tagline','Assistenza informatica — Responsible Research Hospital','2026-10-08 06:48:19'),
(108,'nextui.theme','use_osticket_logos','1','2026-10-08 06:48:19');
/*!40000 ALTER TABLE `ost_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_content`
--

DROP TABLE IF EXISTS `ost_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `type` varchar(32) NOT NULL DEFAULT 'other',
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_content`
--

LOCK TABLES `ost_content` WRITE;
/*!40000 ALTER TABLE `ost_content` DISABLE KEYS */;
INSERT INTO `ost_content` VALUES
(1,1,'landing','Landing','<h1>Welcome to the Support Center</h1> <p> In order to streamline support requests and better serve you, we utilize a support ticket system. Every support request is assigned a unique ticket number which you can use to track the progress and responses online. For your reference we provide complete archives and history of all your support requests. A valid email address is required to submit a ticket. </p>','The Landing Page refers to the content of the Customer Portal\'s initial view. The template modifies the content seen above the two links <strong>Open a New Ticket</strong> and <strong>Check Ticket Status</strong>.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,1,'thank-you','Thank You','<div>%{ticket.name},\n<br>\n<br>\nThank you for contacting us.\n<br>\n<br>\nA support ticket request has been created and a representative will be\ngetting back to you shortly if necessary.</p>\n<br>\n<br>\nSupport Team\n</div>','This template defines the content displayed on the Thank-You page after a\nClient submits a new ticket in the Client Portal.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,'offline','Offline','<div><h1>\n<span style=\"font-size: medium\">Support Ticket System Offline</span>\n</h1>\n<p>Thank you for your interest in contacting us.</p>\n<p>Our helpdesk is offline at the moment, please check back at a later\ntime.</p>\n</div>','The Offline Page appears in the Customer Portal when the Help Desk is offline.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,1,'registration-staff','Welcome to osTicket','<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> We\'ve created an account for you at our help desk at %{url}.<br /> <br /> Please follow the link below to confirm your account and gain access to your tickets.<br /> <br /> <a href=\"%{link}\">%{link}</a><br /> <br /> <em style=\"font-size: small\">Your friendly Customer Support System<br /> %{company.name}</em> </div>','This template defines the initial email (optional) sent to Agents when an account is created on their behalf.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(5,1,'pwreset-staff','osTicket Staff Password Reset','<h3><strong>Hi %{staff.name.first},</strong></h3> <div> A password reset request has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> If you feel that this has been done in error, delete and disregard this email. Your account is still secure and no one has been given access to it. It is not locked and your password has not been reset. Someone could have mistakenly entered your email address.<br /> <br /> Follow the link below to login to the help desk and change your password.<br /> <br /> <a href=\"%{link}\">%{link}</a><br /> <br /> <em style=\"font-size: small\">Your friendly Customer Support System</em> <br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width: 126px\" /> </div>','This template defines the email sent to Staff who select the <strong>Forgot My Password</strong> link on the Staff Control Panel Log In page.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(6,1,'banner-staff','Authentication Required','','This is the initial message and banner shown on the Staff Log In page. The first input field refers to the red-formatted text that appears at the top. The latter textarea is for the banner content which should serve as a disclaimer.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(7,1,'registration-client','Welcome to %{company.name}','<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> We\'ve created an account for you at our help desk at %{url}.<br /> <br /> Please follow the link below to confirm your account and gain access to your tickets.<br /> <br /> <a href=\"%{link}\">%{link}</a><br /> <br /> <em style=\"font-size: small\">Your friendly Customer Support System <br /> %{company.name}</em> </div>','This template defines the email sent to Clients when their account has been created in the Client Portal or by an Agent on their behalf. This email serves as an email address verification. Please use %{link} somewhere in the body.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(8,1,'pwreset-client','%{company.name} Help Desk Access','<h3><strong>Hi %{user.name.first},</strong></h3> <div> A password reset request has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> If you feel that this has been done in error, delete and disregard this email. Your account is still secure and no one has been given access to it. It is not locked and your password has not been reset. Someone could have mistakenly entered your email address.<br /> <br /> Follow the link below to login to the help desk and change your password.<br /> <br /> <a href=\"%{link}\">%{link}</a><br /> <br /> <em style=\"font-size: small\">Your friendly Customer Support System <br /> %{company.name}</em> </div>','This template defines the email sent to Clients who select the <strong>Forgot My Password</strong> link on the Client Log In page.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(9,1,'banner-client','Sign in to %{company.name}','To better serve you, we encourage our Clients to register for an account.','This composes the header on the Client Log In page. It can be useful to inform your Clients about your log in and registration policies.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(10,1,'registration-confirm','Account registration','<div><strong>Thanks for registering for an account.</strong><br/> <br /> We\'ve just sent you an email to the address you entered. Please follow the link in the email to confirm your account and gain access to your tickets. </div>','This templates defines the page shown to Clients after completing the registration form. The template should mention that the system is sending them an email confirmation link and what is the next step in the registration process.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(11,1,'registration-thanks','Account Confirmed!','<div> <strong>Thanks for registering for an account.</strong><br /> <br /> You\'ve confirmed your email address and successfully activated your account. You may proceed to open a new ticket or manage existing tickets.<br /> <br /> <em>Your friendly support center</em><br /> %{company.name} </div>','This template defines the content displayed after Clients successfully register by confirming their account. This page should inform the user that registration is complete and that the Client can now submit a ticket or access existing tickets.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(12,1,'access-link','Ticket [#%{ticket.number}] Access Link','<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> An access link request for ticket #%{ticket.number} has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> Follow the link below to check the status of the ticket #%{ticket.number}.<br /> <br /> <a href=\"%{recipient.ticket_link}\">%{recipient.ticket_link}</a><br /> <br /> If you <strong>did not</strong> make the request, please delete and disregard this email. Your account is still secure and no one has been given access to the ticket. Someone could have mistakenly entered your email address.<br /> <br /> --<br /> %{company.name} </div>','This template defines the notification for Clients that an access link was sent to their email. The ticket number and email address trigger the access link.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(13,1,'email2fa-staff','osTicket Two Factor Authentication','<h3><strong>Hi %{staff.name.first},</strong></h3> <div> You have just logged into for the helpdesk at %{url}.<br /> <br /> Use the verification code below to finish logging into the helpdesk.<br /> <br /> %{otp}<br /> <br /> <em style=\"font-size: small\">Your friendly Customer Support System</em> <br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width: 126px\" /> </div>','This template defines the email sent to Staff who use Email for Two Factor Authentication','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_department`
--

DROP TABLE IF EXISTS `ost_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_department` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `tpl_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `schedule_id` int(10) unsigned NOT NULL DEFAULT 0,
  `email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `autoresp_email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `manager_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `group_membership` tinyint(1) NOT NULL DEFAULT 0,
  `ticket_auto_response` tinyint(1) NOT NULL DEFAULT 1,
  `message_auto_response` tinyint(1) NOT NULL DEFAULT 0,
  `path` varchar(128) NOT NULL DEFAULT '/',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`pid`),
  KEY `manager_id` (`manager_id`),
  KEY `autoresp_email_id` (`autoresp_email_id`),
  KEY `tpl_id` (`tpl_id`),
  KEY `flags` (`flags`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_department`
--

LOCK TABLES `ost_department` WRITE;
/*!40000 ALTER TABLE `ost_department` DISABLE KEYS */;
INSERT INTO `ost_department` VALUES
(1,NULL,0,0,0,0,0,0,4,'Support','Support Department',1,1,1,1,'/1/','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,NULL,0,1,0,0,0,0,4,'Sales','Sales and Customer Retention',1,1,1,1,'/2/','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,NULL,0,0,0,0,0,0,4,'Maintenance','Maintenance Department',1,0,1,1,'/3/','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_draft`
--

DROP TABLE IF EXISTS `ost_draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_draft` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `namespace` varchar(32) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `extra` text DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`),
  KEY `namespace` (`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_draft`
--

LOCK TABLES `ost_draft` WRITE;
/*!40000 ALTER TABLE `ost_draft` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_email`
--

DROP TABLE IF EXISTS `ost_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_email` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `noautoresp` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `priority_id` int(11) unsigned NOT NULL DEFAULT 2,
  `dept_id` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(11) unsigned NOT NULL DEFAULT 0,
  `email` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email` (`email`),
  KEY `priority_id` (`priority_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_email`
--

LOCK TABLES `ost_email` WRITE;
/*!40000 ALTER TABLE `ost_email` DISABLE KEYS */;
INSERT INTO `ost_email` VALUES
(1,0,2,1,0,'support@example.com','Support',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,0,2,1,0,'alerts@example.com','osTicket Alerts',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,0,2,1,0,'noreply@example.com','',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_email_account`
--

DROP TABLE IF EXISTS `ost_email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_email_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email_id` int(11) unsigned NOT NULL,
  `type` enum('mailbox','smtp') NOT NULL DEFAULT 'mailbox',
  `auth_bk` varchar(128) NOT NULL,
  `auth_id` varchar(16) DEFAULT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `host` varchar(128) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL,
  `folder` varchar(255) DEFAULT NULL,
  `protocol` enum('IMAP','POP','SMTP','OTHER') NOT NULL DEFAULT 'OTHER',
  `encryption` enum('NONE','AUTO','SSL') NOT NULL DEFAULT 'AUTO',
  `fetchfreq` tinyint(3) unsigned NOT NULL DEFAULT 5,
  `fetchmax` tinyint(4) unsigned DEFAULT 30,
  `postfetch` enum('archive','delete','nothing') NOT NULL DEFAULT 'nothing',
  `archivefolder` varchar(255) DEFAULT NULL,
  `allow_spoofing` tinyint(1) unsigned DEFAULT 0,
  `num_errors` int(11) unsigned NOT NULL DEFAULT 0,
  `last_error_msg` tinytext DEFAULT NULL,
  `last_error` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_email_account`
--

LOCK TABLES `ost_email_account` WRITE;
/*!40000 ALTER TABLE `ost_email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_email_template`
--

DROP TABLE IF EXISTS `ost_email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_email_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tpl_id` int(11) unsigned NOT NULL,
  `code_name` varchar(32) NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_lookup` (`tpl_id`,`code_name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_email_template`
--

LOCK TABLES `ost_email_template` WRITE;
/*!40000 ALTER TABLE `ost_email_template` DISABLE KEYS */;
INSERT INTO `ost_email_template` VALUES
(1,1,'ticket.autoresp','Support Ticket Opened [#%{ticket.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> <p>A request for support has been created and assigned #%{ticket.number}. A representative will follow-up with you as soon as possible. You can <a href=\"%%7Brecipient.ticket_link%7D\">view this ticket\'s progress online</a>. </p> <br /> <div style=\"color:rgb(127, 127, 127)\">Your %{company.name} Team, <br /> %{signature} </div> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small\"><em>If you wish to provide additional comments or information regarding the issue, please reply to this email or <a href=\"%%7Brecipient.ticket_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login to your account</span></a> for a complete archive of your support requests.</em></div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,1,'ticket.autoreply','Re: %{ticket.subject} [#%{ticket.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> A request for support has been created and assigned ticket <a href=\"%%7Brecipient.ticket_link%7D\">#%{ticket.number}</a> with the following automatic reply <br /> <br /> Topic: <strong>%{ticket.topic.name}</strong> <br /> Subject: <strong>%{ticket.subject}</strong> <br /> <br /> %{response} <br /> <br /> <div style=\"color:rgb(127, 127, 127)\">Your %{company.name} Team,<br /> %{signature}</div> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small\"><em>We hope this response has sufficiently answered your questions. If you wish to provide additional comments or information, please reply to this email or <a href=\"%%7Brecipient.ticket_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login to your account</span></a> for a complete archive of your support requests.</em></div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,'message.autoresp','Message Confirmation','<h3><strong>Dear %{recipient.name.first},</strong></h3> Your reply to support request <a href=\"%%7Brecipient.ticket_link%7D\">#%{ticket.number}</a> has been noted <br /> <br /> <div style=\"color:rgb(127, 127, 127)\">Your %{company.name} Team,<br /> %{signature} </div> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small;text-align:center\"><em>You can view the support request progress <a href=\"%%7Brecipient.ticket_link%7D\">online here</a></em> </div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,1,'ticket.notice','%{ticket.subject} [#%{ticket.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> Our customer care team has created a ticket, <a href=\"%%7Brecipient.ticket_link%7D\">#%{ticket.number}</a> on your behalf, with the following details and summary: <br /> <br /> Topic: <strong>%{ticket.topic.name}</strong> <br /> Subject: <strong>%{ticket.subject}</strong> <br /> <br /> %{message} <br /> <br /> %{response} <br /> <br /> If need be, a representative will follow-up with you as soon as possible. You can also <a href=\"%%7Brecipient.ticket_link%7D\">view this ticket\'s progress online</a>. <br /> <br /> <div style=\"color:rgb(127, 127, 127)\">Your %{company.name} Team,<br /> %{signature}</div> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small\"><em>If you wish to provide additional comments or information regarding the issue, please reply to this email or <a href=\"%%7Brecipient.ticket_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login to your account</span></a> for a complete archive of your support requests.</em></div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(5,1,'ticket.overlimit','Open Tickets Limit Reached','<h3><strong>Dear %{ticket.name.first},</strong></h3> You have reached the maximum number of open tickets allowed. To be able to open another ticket, one of your pending tickets must be closed. To update or add comments to an open ticket simply <a href=\"%%7Burl%7D/tickets.php?e=%%7Bticket.email%7D\">login to our helpdesk</a>. <br /> <br /> Thank you,<br /> Support Ticket System',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(6,1,'ticket.reply','Re: %{ticket.subject} [#%{ticket.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> %{response} <br /> <br /> <div style=\"color:rgb(127, 127, 127)\">Your %{company.name} Team,<br /> %{signature} </div> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small;text-align:center\"><em>We hope this response has sufficiently answered your questions. If not, please do not send another email. Instead, reply to this email or <a href=\"%%7Brecipient.ticket_link%7D\" style=\"color:rgb(84, 141, 212)\">login to your account</a> for a complete archive of all your support requests and responses.</em></div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(7,1,'ticket.activity.notice','Re: %{ticket.subject} [#%{ticket.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> <div><em>%{poster.name}</em> just logged a message to a ticket in which you participate. </div> <br /> %{message} <br /> <br /> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small;text-align:center\"><em>You\'re getting this email because you are a collaborator on ticket <a href=\"%%7Brecipient.ticket_link%7D\" style=\"color:rgb(84, 141, 212)\">#%{ticket.number}</a>. To participate, simply reply to this email or <a href=\"%%7Brecipient.ticket_link%7D\" style=\"color:rgb(84, 141, 212)\">click here</a> for a complete archive of the ticket thread.</em> </div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(8,1,'ticket.alert','New Ticket Alert','<h2>Hi %{recipient.name},</h2> New ticket #%{ticket.number} created <br /> <br /> <table><tbody><tr><td><strong>From</strong>: </td> <td>%{ticket.name} &lt;%{ticket.email}&gt; </td> </tr> <tr><td><strong>Department</strong>: </td> <td>%{ticket.dept.name} </td> </tr> </tbody> </table> <br /> %{message} <br /> <br /> <hr /> <div>To view or respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\">login</a> to the support ticket system</div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <a href=\"https://osticket.com/\"><img width=\"126\" height=\"19\" style=\"width:126px\" alt=\"Powered By osTicket\" src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" /></a>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(9,1,'message.alert','New Message Alert','<h3><strong>Hi %{recipient.name},</strong></h3> New message appended to ticket <a href=\"%%7Bticket.staff_link%7D\">#%{ticket.number}</a> <br /> <br /> <table><tbody><tr><td><strong>From</strong>: </td> <td>%{poster.name} &lt;%{ticket.email}&gt; </td> </tr> <tr><td><strong>Department</strong>: </td> <td>%{ticket.dept.name} </td> </tr> </tbody> </table> <br /> %{message} <br /> <br /> <hr /> <div>To view or respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support ticket system</div> <em style=\"color:rgb(127,127,127);font-size:small\">Your friendly Customer Support System</em><br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(10,1,'note.alert','New Internal Activity Alert','<h3><strong>Hi %{recipient.name},</strong></h3> An agent has logged activity on ticket <a href=\"%%7Bticket.staff_link%7D\">#%{ticket.number}</a> <br /> <br /> <table><tbody><tr><td><strong>From</strong>: </td> <td>%{note.poster} </td> </tr> <tr><td><strong>Title</strong>: </td> <td>%{note.title} </td> </tr> </tbody> </table> <br /> %{note.message} <br /> <br /> <hr /> To view/respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\">login</a> to the support ticket system <br /> <br /> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(11,1,'assigned.alert','Ticket Assigned to you','<h3><strong>Hi %{assignee.name.first},</strong></h3> Ticket <a href=\"%%7Bticket.staff_link%7D\">#%{ticket.number}</a> has been assigned to you by %{assigner.name.short} <br /> <br /> <table><tbody><tr><td><strong>From</strong>: </td> <td>%{ticket.name} &lt;%{ticket.email}&gt; </td> </tr> <tr><td><strong>Subject</strong>: </td> <td>%{ticket.subject} </td> </tr> </tbody> </table> <br /> %{comments} <br /> <br /> <hr /> <div>To view/respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support ticket system</div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(12,1,'transfer.alert','Ticket #%{ticket.number} transfer - %{ticket.dept.name}','<h3>Hi %{recipient.name},</h3> Ticket <a href=\"%%7Bticket.staff_link%7D\">#%{ticket.number}</a> has been transferred to the %{ticket.dept.name} department by <strong>%{staff.name.short}</strong> <br /> <br /> <blockquote>%{comments} </blockquote> <hr /> <div>To view or respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\">login</a> to the support ticket system. </div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <a href=\"https://osticket.com/\"><img width=\"126\" height=\"19\" alt=\"Powered By osTicket\" style=\"width:126px\" src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" /></a>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(13,1,'ticket.overdue','Stale Ticket Alert','<h3><strong>Hi %{recipient.name}</strong>,</h3> A ticket, <a href=\"%%7Bticket.staff_link%7D\">#%{ticket.number}</a> is seriously overdue. <br /> <br /> We should all work hard to guarantee that all tickets are being addressed in a timely manner. <br /> <br /> Signed,<br /> %{ticket.dept.manager.name} <hr /> <div>To view or respond to the ticket, please <a href=\"%%7Bticket.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support ticket system. You\'re receiving this notice because the ticket is assigned directly to you or to a team or department of which you\'re a member.</div> <em style=\"font-size:small\">Your friendly <span style=\"font-size:smaller\">(although with limited patience)</span> Customer Support System</em><br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" height=\"19\" alt=\"Powered by osTicket\" width=\"126\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(14,1,'task.alert','New Task Alert','<h2>Hi %{recipient.name},</h2> New task <a href=\"%%7Btask.staff_link%7D\">#%{task.number}</a> created <br /> <br /> <table><tbody><tr><td><strong>Department</strong>: </td> <td>%{task.dept.name} </td> </tr> </tbody> </table> <br /> %{task.description} <br /> <br /> <hr /> <div>To view or respond to the task, please <a href=\"%%7Btask.staff_link%7D\">login</a> to the support system</div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <a href=\"https://osticket.com/\"><img width=\"126\" height=\"19\" style=\"width:126px\" alt=\"Powered By osTicket\" src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" /></a>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(15,1,'task.activity.notice','Re: %{task.title} [#%{task.number}]','<h3><strong>Dear %{recipient.name.first},</strong></h3> <div><em>%{poster.name}</em> just logged a message to a task in which you participate. </div> <br /> %{message} <br /> <br /> <hr /> <div style=\"color:rgb(127, 127, 127);font-size:small;text-align:center\"><em>You\'re getting this email because you are a collaborator on task #%{task.number}. To participate, simply reply to this email.</em> </div>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(16,1,'task.activity.alert','Task Activity [#%{task.number}] - %{activity.title}','<h3><strong>Hi %{recipient.name},</strong></h3> Task <a href=\"%%7Btask.staff_link%7D\">#%{task.number}</a> updated: %{activity.description} <br /> <br /> %{message} <br /> <br /> <hr /> <div>To view or respond to the task, please <a href=\"%%7Btask.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support system</div> <em style=\"color:rgb(127,127,127);font-size:small\">Your friendly Customer Support System</em><br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(17,1,'task.assignment.alert','Task Assigned to you','<h3><strong>Hi %{assignee.name.first},</strong></h3> Task <a href=\"%%7Btask.staff_link%7D\">#%{task.number}</a> has been assigned to you by %{assigner.name.short} <br /> <br /> %{comments} <br /> <br /> <hr /> <div>To view/respond to the task, please <a href=\"%%7Btask.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support system</div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" alt=\"Powered by osTicket\" width=\"126\" height=\"19\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(18,1,'task.transfer.alert','Task #%{task.number} transfer - %{task.dept.name}','<h3>Hi %{recipient.name},</h3> Task <a href=\"%%7Btask.staff_link%7D\">#%{task.number}</a> has been transferred to the %{task.dept.name} department by <strong>%{staff.name.short}</strong> <br /> <br /> <blockquote>%{comments} </blockquote> <hr /> <div>To view or respond to the task, please <a href=\"%%7Btask.staff_link%7D\">login</a> to the support system. </div> <em style=\"font-size:small\">Your friendly Customer Support System</em> <br /> <a href=\"https://osticket.com/\"><img width=\"126\" height=\"19\" alt=\"Powered By osTicket\" style=\"width:126px\" src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" /></a>',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(19,1,'task.overdue.alert','Stale Task Alert','<h3><strong>Hi %{recipient.name}</strong>,</h3> A task, <a href=\"%%7Btask.staff_link%7D\">#%{task.number}</a> is seriously overdue. <br /> <br /> We should all work hard to guarantee that all tasks are being addressed in a timely manner. <br /> <br /> Signed,<br /> %{task.dept.manager.name} <hr /> <div>To view or respond to the task, please <a href=\"%%7Btask.staff_link%7D\"><span style=\"color:rgb(84, 141, 212)\">login</span></a> to the support system. You\'re receiving this notice because the task is assigned directly to you or to a team or department of which you\'re a member.</div> <em style=\"font-size:small\">Your friendly <span style=\"font-size:smaller\">(although with limited patience)</span> Customer Support System</em><br /> <img src=\"cid:b56944cb4722cc5cda9d1e23a3ea7fbc\" height=\"19\" alt=\"Powered by osTicket\" width=\"126\" style=\"width:126px\" />',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_email_template_group`
--

DROP TABLE IF EXISTS `ost_email_template_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_email_template_group` (
  `tpl_id` int(11) NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(32) NOT NULL DEFAULT '',
  `lang` varchar(16) NOT NULL DEFAULT 'en_US',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NOT NULL,
  PRIMARY KEY (`tpl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_email_template_group`
--

LOCK TABLES `ost_email_template_group` WRITE;
/*!40000 ALTER TABLE `ost_email_template_group` DISABLE KEYS */;
INSERT INTO `ost_email_template_group` VALUES
(1,1,'osTicket Default Template (HTML)','en_US','Default osTicket templates','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_email_template_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_event`
--

DROP TABLE IF EXISTS `ost_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_event`
--

LOCK TABLES `ost_event` WRITE;
/*!40000 ALTER TABLE `ost_event` DISABLE KEYS */;
INSERT INTO `ost_event` VALUES
(1,'created',NULL),
(2,'closed',NULL),
(3,'reopened',NULL),
(4,'assigned',NULL),
(5,'released',NULL),
(6,'transferred',NULL),
(7,'referred',NULL),
(8,'overdue',NULL),
(9,'edited',NULL),
(10,'viewed',NULL),
(11,'error',NULL),
(12,'collab',NULL),
(13,'resent',NULL),
(14,'deleted',NULL),
(15,'merged',NULL),
(16,'unlinked',NULL),
(17,'linked',NULL),
(18,'login',NULL),
(19,'logout',NULL),
(20,'message',NULL),
(21,'note',NULL);
/*!40000 ALTER TABLE `ost_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_faq`
--

DROP TABLE IF EXISTS `ost_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_faq` (
  `faq_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL DEFAULT 0,
  `ispublished` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `keywords` tinytext DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`faq_id`),
  UNIQUE KEY `question` (`question`),
  KEY `category_id` (`category_id`),
  KEY `ispublished` (`ispublished`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_faq`
--

LOCK TABLES `ost_faq` WRITE;
/*!40000 ALTER TABLE `ost_faq` DISABLE KEYS */;
INSERT INTO `ost_faq` VALUES
(1,1,1,'Come richiedere un nuovo PC','Apri un ticket con argomento <b>Report a Problem</b> indicando reparto e numero di inventario.',' ',NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(2,1,2,'Stampante di rete: cosa controllare','<ol><li>Verifica che sia accesa</li><li>Controlla la carta</li><li>Riavvia la coda di stampa</li></ol>',' ',NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(3,2,1,'Accesso al FSE','Per accedere al Fascicolo Sanitario Elettronico serve la smart card abilitata.',' ',NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(4,2,0,'Referti LIS non visibili','Controlla che la richiesta sia stata accettata dal laboratorio.',' ',NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(5,3,0,'Reset password di dominio','Procedura riservata agli agenti: verifica identità, poi reset da console AD.',' ',NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26');
/*!40000 ALTER TABLE `ost_faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_faq_category`
--

DROP TABLE IF EXISTS `ost_faq_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_faq_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_pid` int(10) unsigned DEFAULT NULL,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(125) DEFAULT NULL,
  `description` text NOT NULL,
  `notes` tinytext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `ispublic` (`ispublic`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_faq_category`
--

LOCK TABLES `ost_faq_category` WRITE;
/*!40000 ALTER TABLE `ost_faq_category` DISABLE KEYS */;
INSERT INTO `ost_faq_category` VALUES
(1,NULL,1,'Postazioni di lavoro','Articoli: Postazioni di lavoro','','2026-10-09 10:44:26','2026-10-09 10:44:26'),
(2,NULL,1,'Applicativi sanitari','Articoli: Applicativi sanitari','','2026-10-09 10:44:26','2026-10-09 10:44:26'),
(3,NULL,0,'Procedure interne IT','Articoli: Procedure interne IT','','2026-10-09 10:44:26','2026-10-09 10:44:26');
/*!40000 ALTER TABLE `ost_faq_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_faq_topic`
--

DROP TABLE IF EXISTS `ost_faq_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_faq_topic` (
  `faq_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`faq_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_faq_topic`
--

LOCK TABLES `ost_faq_topic` WRITE;
/*!40000 ALTER TABLE `ost_faq_topic` DISABLE KEYS */;
INSERT INTO `ost_faq_topic` VALUES
(1,10),
(2,10),
(3,10),
(4,10),
(5,10);
/*!40000 ALTER TABLE `ost_faq_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_file`
--

DROP TABLE IF EXISTS `ost_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ft` char(1) NOT NULL DEFAULT 'T',
  `bk` char(1) NOT NULL DEFAULT 'D',
  `type` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `key` varchar(86) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `signature` varchar(86) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `attrs` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ft` (`ft`),
  KEY `key` (`key`),
  KEY `signature` (`signature`),
  KEY `type` (`type`),
  KEY `created` (`created`),
  KEY `size` (`size`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_file`
--

LOCK TABLES `ost_file` WRITE;
/*!40000 ALTER TABLE `ost_file` DISABLE KEYS */;
INSERT INTO `ost_file` VALUES
(1,'T','D','image/png',9452,'b56944cb4722cc5cda9d1e23a3ea7fbc','gjMyblHhAxCQvzLfPBW3EjMUY1AmQQmz','powered-by-osticket.png',NULL,'2026-10-08 06:22:17'),
(2,'T','D','text/plain',24,'6mZ14MWtx86n3ccfeGGNagoRoTDtol7o','MWtx86n3ccfeGGNafaacpitTxmJ4h3Ls','osTicket.txt',NULL,'2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_file_chunk`
--

DROP TABLE IF EXISTS `ost_file_chunk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_file_chunk` (
  `file_id` int(11) NOT NULL,
  `chunk_id` int(11) NOT NULL,
  `filedata` longblob NOT NULL,
  PRIMARY KEY (`file_id`,`chunk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_file_chunk`
--

LOCK TABLES `ost_file_chunk` WRITE;
/*!40000 ALTER TABLE `ost_file_chunk` DISABLE KEYS */;
INSERT INTO `ost_file_chunk` VALUES
(1,0,'�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0�\0\0\0(\0\0\0�G��\0\0\nCiCCPICC profile\0\0xڝSwX��>��eVB��l�\0\"#��Y��\0a�@Ņ�\nV�HUĂ�\nH���(�gA��Z�U\\8�ܧ�}z�����������y��&��j\09R�<:��OH�ɽ�H� ���g�\0\0�yx~t�?��o\0\0p�.$�����P&W\0 �\0�\"��R\0�.T�\0�\0�S�d\n\0�\0\0ly|B\"\0�\r\0��I>\0ة��\0آ�\0�\0�(G$@�\0`U�R,��\0��@\".���Y�2G��\0v�X�@`\0��B,�\0 8\0C� L�0ҿ�_p��H\0�˕͗K�3���\Zw����!��l�Ba)f	�\"���#H�L�\0\0\Z����8?������f�l��Ţ�k�o\">!�����\0N���_���p��u�k�[\0�V\0h��]3�	�Z\n�z��y8�@��P�<\n�%b��0�>�3�o��~��@��z�\0q�@������qanv�R���B1n��#�ǅ��)��4�\\,��X��P\"M�y�R�D!ɕ��2���	�w\r\0��O�N���l�~��X�v\0@~�-�\Z�\0g42y�\0\0����@+\0͗��\0\0��\\��L�\0\0D��*�A�������aD@$�<B�\n��AT�:���\Z�����18\r��\\��p`����	A�a!:�b��\"���\"aH4��� �Q\"��r��Bj�]H#�-r9�\\@���� 2����G1���Q�u@��\Z�Ơs�t4]���k�\Z�=�����K�ut\0}��c��1f��a\\��E`�X\Z&�c�X5V�5cX7v��a�$���^��l���GXLXC�%�#��W	��1�\'\"��O�%z��xb:��XF�&�!!�%^\'_�H$ɒ�N\n!%�2IIkH�H-�S�>�i�L&�m������ �����O�����:ň�L	�$R��J5e?���2B���Qͩ����:�ZIm�vP/S��4u�%͛Cˤ-��Кigi�h/�t�	݃E�З�k�����w\r�\r��Hb(k{��/�L�ӗ��T0�2�g��oUX*�*|���:�V�~��TUsU?�y�T�U�^V}�FU�P�	��թU��6��RwR�P�Q_��_���c\r���F��H�Tc���!�2e�XB�rV�,k�Mb[���Lv�v/{LSCs�f�f�f��q�Ʊ��9ٜJ�!�\r�{--?-��j�f�~�7�zھ�b�r�����up�@�,��:m:�u	�6�Q����u��>�c�y�	������G�m��������7046�l18c�̐c�k�i������h���h��I�\'�&�g�5x>f�ob�4�e�k<abi2ۤĤ��)͔k�f�Ѵ�t���,ܬج��9՜k�a�ټ�����E��J�6�ǖږ|��M����V>VyV�V׬I�\\�,�m�WlPW��:�˶�����v�m���)�)�Sn�1���\n���9�a�%�m����;t;|rtu�vlp���4éĩ��Wgg�s��5�K���v�Sm���n�z˕�\Z�ҵ������ܭ�m���=�}��M.��]�=�A���X�q�㝧�����/^v^Y^��O��&��0m���[��{`:>=e���>�>�z�����\"�=�#~�~�~���;�������y��N`����\Z��k��5��/>B	\rYr�o���c3�g,����Z�0�&L�����~o��L�̶��Gl��i��})*2�.�Q�Stqt�,֬�Y�g��񏩌�;�j�rvg�jlRlc웸�����x��E�t$	�����=��s�l�3��T�tc��ܢ����˞w<Y5Y�|8����?� BP/O�nM򄛅OE����Q���J<��V��8�;}C�h�OFu�3	OR+y���#�MVD�ެ��q�-9�����R\ri��+�0�(�Of++�\r�y�m������#�s��l�Lѣ�R�PL/�+x[[x�H�HZ�3�f���#�|���P���ظxY��\"�E�#�Sw.1]R�dxi��}�h˲��P�XRU�jy��R�ҥ�C+�W4�����n��Z�ca�dU�j��[V*�_�p�����F���WN_�|�ym���J����H��n��Y��J�jA�І�\r���_mJ�t�zj��ʹ���5a5�[̶���6��z�]�V������&�ֿ�w{��;��켵+xWk�E}�n��ݏ\Zb���~ݸGwOŞ�{�{�E��jtolܯ���	mR6�H:p囀oڛ�w�pZ*�A��\'ߦ|{�P������ߙ���Hy+�:�u�-�m�=���茣�^G���~�1�cu�5�W���(=��䂓�d���N?=ԙ�y�L��k]Q]�gCϞ?t�L�_�����]�p�\"�b�%�K�=�=G~p��H�[o�e���W<�t�M�;����j��s���.]�y�����n&��%���v��w\n�L�]z�x�����������e�m��`�`��Y�	�����Ӈ��G�G�#F#���\r\Z��dΓ᧲���~V�y�s������K�X�����Ͽ�y��r﫩�:�#���y=�����}���ǽ�(�@�P���cǧ�O�>�|��/�����9%\0\0\0tEXtSoftware\0Adobe ImageReadyq�e<\0\0(iTXtXML:com.adobe.xmp\0\0\0\0\0<?xpacket begin=\"﻿\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?> <x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156797, 2014/08/20-09:53:02        \"> <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"> <rdf:Description rdf:about=\"\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\" xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\" xmlns:stRef=\"http://ns.adobe.com/xap/1.0/sType/ResourceRef#\" xmp:CreatorTool=\"Adobe Photoshop CC 2014 (Macintosh)\" xmpMM:InstanceID=\"xmp.iid:6E2C95DEA67311E4BDCDDF91FAF94DA5\" xmpMM:DocumentID=\"xmp.did:6E2C95DFA67311E4BDCDDF91FAF94DA5\"> <xmpMM:DerivedFrom stRef:instanceID=\"xmp.iid:CFA74E4FA67111E4BDCDDF91FAF94DA5\" stRef:documentID=\"xmp.did:CFA74E50A67111E4BDCDDF91FAF94DA5\"/> </rdf:Description> </rdf:RDF> </x:xmpmeta> <?xpacket end=\"r\"?>����\0\0IDATx��]	�S��?/{2�df�aq�]67�ϭ(*�-\n��.�+�օ� n�J���S�R��:VDT�,e�2�l�����3��L���ݛ�os�N��Pq���$���������s�1�NY96��t����S�/Q��]k~K����z���>�%4ߤ�5���<��,��clmY������\'��B�h���B�LZ��M?���\0]s�G�>���Z(4W�]h\r\"Ҿ&F4�]���?JKD$�F>Yd-}Q�ZY�e�)���*t��ӄ���$��\r	=(t���Bg	=�����_���єQ\0m�V�+�S�va�D�W�g�����B���B�e���B��L�H���#t�B�	�mFW�\0;t� _���@��њ�x��.t!�[�!#�\\���|��W��:��\rG��I��9��*ʍ6ˁ���Jk�S��A�qG�N��\09���EB�M�~-4?홝�~�I�}�&�y�eY�����o\n�u��{.r��Bk��iv?���LG��є�j�-+��Q散\02%>�|���(^����\n�X��r��T��R��-�*����-��R�˅V���BI�:G�T�#��5i�\ZE\"F��lD;�\\_�p��sj�d��B\"t��B)�2�w���ϊ��`���Ф�^���MnA!��<�Y�>���������\n�kt�M�Jw%���<.����B�U\\G�BI?禓]\0�o����^����eF�&.���a��a5�͚��#ңo>��=L^���]F����J�N\0�G��ㅾV�\Z��!q#!�����6=X�9�\\T2�ﲨ{��c�捳,Ў)zak�l��@1���{���^��MF��_b��(7�9����+\'J��{h�n��[\\�hi��Gc41\'\'�M��1����>;k�ǐL�����݋���$�|�~�,��ݕ�x� �l��(4W.�\ZAjՈ�r���sr�W���M�W�r�\"z�h��>��;��Y�窊E,�0ތ\\�\\1�b����\"�\'����x���u�LY�ȣx9�)��^[\0�P�XV��NX�ͻ�T(\"Y���u��W�e�v�݈RU�C55A��C��GY6?���@��1k�VS|�9��I�X���*�rD�\"��L���Ύ=*@4�=N�wZj�9�%p���%a��~��yBe����������\r���K�;HT�o�+�)�Q�_Ÿt����cI�U�ȱB\"�Vڪ�Vg>L�vW�S�1�|�X���pѰ�y����Zx�rR��\'�#��)��W�H�[ ԍ����	�(#�=B2��C�۲@�JL,H$�ݵ(��N)2���\'��䘮\Z��/*��\'rZ�KD��V�((��g	��ś{��P�]aY� �jߊ=B��\n\"4~n�VnwR���X�F�U�rQsΐJd��\Zz��7\"�y�7e�cV������������%�B�T`��S�O�;]NNy�X�z7�s��}���~j/�߬\rn����F�z���*��f�ۉ洌5)��E��EK|��j�4��4\rI.��x����.�j�6��GJ�G_��Ә�Zz1`Nx�P��<8�^��$6�v�hUY�\n�G���jrެ/^�D����a�S��ۚIm·L��\Z�^ f��Z��A36�ck��{,\Z9�Rܱ@W�Q%��Z�d���Wm��o��\'rK��J���U0�7YާD~&*�������1~��&=PH:	��e�ְȁ~��|�d4ş:�҇��\n��{��ţTǹ+h�,��9ww��z��X\0�����-�K��N/R������\r�3-H��h+�apymv+��gɧ�7��E#�:��*����Z;x��΁w�*��Kq�8W�Q���ȶ<�{X�&�ң�xPTR�;Pđ �#�����%·\'��H/�d���&A�y��?�����Ljȇ6�=\"�9�t9\Z_��2I$��\0�K�,�-\"�h���g.��v��8߼�a�=�ٞ]MV*D-z�c0:�z7y�ɣGϯ(/y=�|ҧ^[�Ӻ�ca�q�>ѺQj���)�bD���ky��J@���c��K�����leh\rK���)��Axn�v�F8\r�J��Bww*%Gl^͖̋*�D�LV���� �)Q�x��1�NT�7o��.�|�e�S�V�>^�����B/�\Z�ҽ��qSE���>;-��41�t����iD�瓍8U�}\'�\"�OB�z��#����w���v8;���I�F>�:Թ�㰀�O4D��r�����S�m�.��F!%�8䊛I��y\"�������e�*H�NE�f�t5��K#��L��B���E�3��6P����$�V72��;��P\"1�Óȹ������ڹ��\\y�� �(�r�\"�W�>�����z�S�}��|?A��6N���y΋p9H��\0����6�1�6ʧP�Z}i�\"���R7�%��O��č��ыkCU!j/@61�z	�\'�[�~��wף�7V\0q_�+�}�o^e4\"6����¨�s����!��\\r��k�JN�T�$@�Q�N���S�������$yZ(_�:�{���W,��\r�/��u�\Zs�x��Ѱqh�����.��}	����g(�b[\Z�s�L7��RF��+�%�(��G�8\"�4�r��)�5V��6I��F�\r:� XR>9��Q;G)ڴ����^��LȰR�#���.c�/ ��5/d�Izf9�,��}Og+>{8���xq�*���k��^�Z`5��r�u��u��ʠ��\"�I��E[uT�\\�\n�q���f�-�ϵ�ͺ/I4%8�{0�7\"W+k���T��Ga_�dC:���2����v\0�Y���-���{���0ǟN�6V�����!1��y��\0@�LF�y�@:�:x�:�/+E�îu.^f=0	�W�V\"b��K�5�3G��ht�#�+��>?��ǽ=���0�}0��t�ɼ��u\r�V���9�)�ftѼ~;��W�9Xt�tƊ#)\n6Ex�9r���8���_K���g����D�������+	ȸ�\n���Z���u��-@�G��L���M\Z��`��^N�\r�^F�ȫ	�����` #��bL�FD�~�x֎@7���:���!l�1�l\Z��\'�9@p)�b�PbN�UP��q�����t��8��\"�\'�\r\\&!ª���&OGGׂb�nf`]�0��N=m?��k����X�F$?��2�bP\n��ؕp�0��{�EAoh��|��d�Y�E,�qjQe�0��T`��K|4bf.�D�f�����o��N�D�Á���=l,uف1�\\����v�U����P��w�B�G_�)1�\0�N�o������C�����&ҁ��痁�<Pq~�6����cmZ����b>�	�\\�U�����\' �y�>!ܶF��G�,�G���MO�f �uQ������nx�����H�rL<�4�?f/��qR���Jʿ�ɤ%e\"���2�s!֧�!��\'�~��p\r#Je�+R=u���m�^J��U�|���F�op�C���(h_oI3��]puB4�+�q.��C���I[�IM�gTm(��F�F�g/\"�X���A��]��\03#��)I�5�r���cӨ}ʪ�G���@�@Q�|\0��E(�N���w��̥�uD�K\0��h�*�Y�C�.�1��UrX4<�y��̐;���_B�@�D1p~mx�V�ޯ�g�5Ze�+x���H��\'�P\rD龬��lw����P��d�x�>]h���B����G���G���R�|��`���Q��v���Ӡ�B��C,ERO�g*��/6��9�p�8!ĭ��씯�q\"BZ45xH2Ţ-G:��I83%���$�|��aY�\0<ܴ�Z��W���0�&����aTn��U��â�Zt���ep�\Z��i#E���F�6���*��\\��o��&H\'	�=�c6�m\"Ķ6�W���JVQSq*겨b���,�Q����d��{�4��{r���u!Ʋ��F�n��-赒��7a��L�����7i@�{P�L閮%$��(��\'q��c���w`��`@��5	�e�����\Z����9�fգ���V%������M(�ë�q�a���s���Q��w^��w�\nRZ0ǲ�E�O�tn`Ň�藸eY=�m.���\'2_��CN`Ʈ�(!�k��M�č�4u���%�4)��H�[��/�;��}\\��8�*�X���=Mwh\r\Zt\n�\\\'\"�\nƄ�Z~M3��-9�8�R8��g�_@uWN��4��ꓚϹ�5b5��T^RcSVh�b�>b\0#��5:�,�w�cT��Pma������\'� �E	e0�XԎBI�Fx\\y���U��\"�8�r���[��E�r:!5�dIA��h�\'Z4Wt�����g�4醲�v�<�Q�]�-��\\��A(5`m,�	皌�V�\Z�Xd��*��Pb��<�B%+�#c.V*���P���,Vՙy(:�\0�F#\"|Fu7����l+\0(����ŀ�b�����`xڗPR�7՝*)�.^U(�\\�Μ��;��脫PЙ\0�y�\Z�������\0�j��8���\Z�����y�d�Q�e���Z�	�EO����h�u)���h�3�!�[SU�\'��_��q����(.��RO�B�b�W�Ѷh�ԋG\r�N���)����|V�F�h��&D]���E4 k�y6hw���=���?D��\'����u�b-�Ts��G���y�y��`8����<�\na+V�\rh�2	�x��1�іMA��y�)l�k$����H��y�7��t\r��j�H�/6-�J�u&<}\"�Qĕn@{�j�K\Z�.`-N�Bچ�ӫh�M/^���\\߀1vS�/GJP�!�6#���9�:Cb������DčR�_�9���C\r��SU]SE4;���B�o�\"�(���Px)\'��̵pʲ�	ޝӜ{�P�4	��0,@:�L���\\j�_��g�08�0�c�\"!��,x77��\Z\n��d�\"~�h������~P�9I��,FS��;km@F2?\n%�5z|:��5h�D��C�tG�TET��}-��qz�{\n��iI�Q�3�#��dt�-�!�DWD�#w#e&��\Z��QND�w���ݔj�q���{p��k���+܏{gZǫrХl��\"�l�m$l�p$I?�1�`<���:$���Bi�b�B��c]��݀k8q��v�C�d�W��xU�\'�y�������Q��.�=o��3��V�� %��|F��=�V�+��$�E\'^9O�7K��L��轲Z��ȫ�I�4x��a���A��>��g�Џ����\0`_c:\Z��\rF�(D�~@3ѷ3)��S:�� _?𵀓\\�M)��8�~x/����F!�Pn�p/ؽ��%h[p݋Xes,ھđ�\nie�L���D��JKKr��u�A�)J�w\"�d����x^���W��\np���$��\0D�(�-�]�]��:�hk���i��d3�����+��;��Un�4\nKɶP(P�h���\n;^�Ʋ�,]|��X�˫�Tw	V���v\0�u���ྞbS(��ٖZ?=g`x��ѡ5�MY9\Z��\\S�l3�e:Y	j�Bn�v�J5�s�z��S��.\'��%�jh̜�\0Z=_�\Z���h`oe[���)�#�2�i����M�7י�bV����N@t�S�_]����wfHu͙He��m����Hk Z�D۽��\'(�����NT��|_;�\"��VJL�ɔi����/�Bh�����8�\"��/�!w�������F5��vT!+Q��/A�FOҘ��4�C�\Zp0jC�\nJ�\'6��Q�~�7vD3/�B5���@�Z p����_�\0�௘s]J�\0\0\0\0IEND�B`�'),
(2,0,'Canned Attachments Rock!');
/*!40000 ALTER TABLE `ost_file_chunk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_filter`
--

DROP TABLE IF EXISTS `ost_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_filter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `execorder` int(10) unsigned NOT NULL DEFAULT 99,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `flags` int(10) unsigned DEFAULT 0,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `match_all_rules` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `stop_onmatch` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `target` enum('Any','Web','Email','API') NOT NULL DEFAULT 'Any',
  `email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(32) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `target` (`target`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_filter`
--

LOCK TABLES `ost_filter` WRITE;
/*!40000 ALTER TABLE `ost_filter` DISABLE KEYS */;
INSERT INTO `ost_filter` VALUES
(1,99,1,0,0,0,0,'Email',0,'SYSTEM BAN LIST','Internal list for email banning. Do not remove','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_filter_action`
--

DROP TABLE IF EXISTS `ost_filter_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_filter_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  `type` varchar(24) NOT NULL,
  `configuration` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `filter_id` (`filter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_filter_action`
--

LOCK TABLES `ost_filter_action` WRITE;
/*!40000 ALTER TABLE `ost_filter_action` DISABLE KEYS */;
INSERT INTO `ost_filter_action` VALUES
(1,1,1,'reject','[]','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_filter_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_filter_rule`
--

DROP TABLE IF EXISTS `ost_filter_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_filter_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` int(10) unsigned NOT NULL DEFAULT 0,
  `what` varchar(32) NOT NULL,
  `how` enum('equal','not_equal','contains','dn_contain','starts','ends','match','not_match') NOT NULL,
  `val` varchar(255) NOT NULL,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `notes` tinytext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filter` (`filter_id`,`what`,`how`,`val`),
  KEY `filter_id` (`filter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_filter_rule`
--

LOCK TABLES `ost_filter_rule` WRITE;
/*!40000 ALTER TABLE `ost_filter_rule` DISABLE KEYS */;
INSERT INTO `ost_filter_rule` VALUES
(1,1,'email','equal','test@example.com',1,'','0000-00-00 00:00:00','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_filter_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_form`
--

DROP TABLE IF EXISTS `ost_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned DEFAULT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'G',
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `instructions` varchar(512) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_form`
--

LOCK TABLES `ost_form` WRITE;
/*!40000 ALTER TABLE `ost_form` DISABLE KEYS */;
INSERT INTO `ost_form` VALUES
(1,NULL,'U',1,'Contact Information',NULL,'',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,NULL,'T',1,'Ticket Details','Please Describe Your Issue','','This form will be attached to every ticket, regardless of its source.\nYou can add any fields to this form and they will be available to all\ntickets, and will be searchable with advanced search and filterable.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,NULL,'C',1,'Company Information','Details available in email templates','',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,NULL,'O',1,'Organization Information','Details on user organization','',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(5,NULL,'A',1,'Task Details','Please Describe The Issue','','This form is used to create a task.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(6,NULL,'L1',0,'Ticket Status Properties','Properties that can be set on a ticket status.','',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_form_entry`
--

DROP TABLE IF EXISTS `ost_form_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_form_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(11) unsigned NOT NULL,
  `object_id` int(11) unsigned DEFAULT NULL,
  `object_type` char(1) NOT NULL DEFAULT 'T',
  `sort` int(11) unsigned NOT NULL DEFAULT 1,
  `extra` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_lookup` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_form_entry`
--

LOCK TABLES `ost_form_entry` WRITE;
/*!40000 ALTER TABLE `ost_form_entry` DISABLE KEYS */;
INSERT INTO `ost_form_entry` VALUES
(1,4,1,'O',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,3,NULL,'C',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,1,'U',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,2,1,'T',0,'{\"disable\":[]}','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(5,4,2,'O',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(6,4,3,'O',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(7,4,4,'O',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(8,4,5,'O',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(9,4,6,'O',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(10,1,2,'U',1,NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(11,1,3,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(12,1,4,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(13,1,5,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(14,1,6,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(15,1,7,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(16,1,8,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(17,1,9,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(18,1,10,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(19,1,11,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(20,1,12,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(21,1,13,'U',1,NULL,'2026-10-09 05:59:03','2026-10-09 05:59:03'),
(22,2,2,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(23,2,3,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(24,2,4,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(25,2,5,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(26,2,6,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(27,2,7,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(28,2,8,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(29,2,9,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(30,2,10,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(31,2,11,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(32,2,12,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(33,2,13,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(34,2,14,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(35,2,15,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(36,2,16,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(37,2,17,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(38,2,18,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(39,2,19,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(40,2,20,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(41,2,21,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(42,2,22,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(43,2,23,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(44,2,24,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(45,2,25,'T',0,'{\"disable\":[]}','2026-10-09 05:59:14','2026-10-09 05:59:14'),
(46,2,26,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(47,2,27,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(48,2,28,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(49,2,29,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(50,2,30,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(51,2,31,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(52,2,32,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(53,2,33,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(54,2,34,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(55,2,35,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(56,2,36,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(57,2,37,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(58,2,38,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(59,2,39,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(60,2,40,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(61,2,41,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(62,2,42,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(63,2,43,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(64,2,44,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(65,2,45,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(66,2,46,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(67,2,47,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(68,2,48,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(69,2,49,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(70,2,50,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(71,2,51,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(72,2,52,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(73,2,53,'T',0,'{\"disable\":[]}','2026-10-09 05:59:15','2026-10-09 05:59:15'),
(74,2,54,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(75,2,55,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(76,2,56,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(77,2,57,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(78,2,58,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(79,2,59,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(80,2,60,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(81,2,61,'T',0,'{\"disable\":[]}','2026-10-09 05:59:16','2026-10-09 05:59:16'),
(82,5,1,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(83,5,2,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(84,5,3,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(85,5,4,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(86,5,5,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(87,5,6,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(88,5,7,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(89,5,8,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(90,5,9,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(91,5,10,'A',1,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(92,5,11,'A',1,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27'),
(93,5,12,'A',1,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27');
/*!40000 ALTER TABLE `ost_form_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_form_entry_values`
--

DROP TABLE IF EXISTS `ost_form_entry_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_form_entry_values` (
  `entry_id` int(11) unsigned NOT NULL,
  `field_id` int(11) unsigned NOT NULL,
  `value` text DEFAULT NULL,
  `value_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`entry_id`,`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_form_entry_values`
--

LOCK TABLES `ost_form_entry_values` WRITE;
/*!40000 ALTER TABLE `ost_form_entry_values` DISABLE KEYS */;
INSERT INTO `ost_form_entry_values` VALUES
(2,23,'Helpdesk DEV',NULL),
(2,24,NULL,NULL),
(2,25,NULL,NULL),
(2,26,NULL,NULL),
(4,20,'osTicket Installed!',NULL),
(5,28,NULL,NULL),
(5,29,NULL,NULL),
(5,30,NULL,NULL),
(5,31,NULL,NULL),
(6,28,NULL,NULL),
(6,29,NULL,NULL),
(6,30,NULL,NULL),
(6,31,NULL,NULL),
(7,28,NULL,NULL),
(7,29,NULL,NULL),
(7,30,NULL,NULL),
(7,31,NULL,NULL),
(8,28,NULL,NULL),
(8,29,NULL,NULL),
(8,30,NULL,NULL),
(8,31,NULL,NULL),
(9,28,NULL,NULL),
(9,29,NULL,NULL),
(9,30,NULL,NULL),
(9,31,NULL,NULL),
(10,3,'0874479717',NULL),
(10,4,NULL,NULL),
(11,3,'0874412492',NULL),
(11,4,NULL,NULL),
(12,3,'0874432615',NULL),
(12,4,NULL,NULL),
(13,3,'0874489202',NULL),
(13,4,NULL,NULL),
(14,3,'0874423159',NULL),
(14,4,NULL,NULL),
(15,3,'0874486930',NULL),
(15,4,NULL,NULL),
(16,3,'0874443743',NULL),
(16,4,NULL,NULL),
(17,3,'0874417379',NULL),
(17,4,NULL,NULL),
(18,3,'0874481295',NULL),
(18,4,NULL,NULL),
(19,3,'0874461528',NULL),
(19,4,NULL,NULL),
(20,3,'0874494187',NULL),
(20,4,NULL,NULL),
(21,3,'0874484635',NULL),
(21,4,NULL,NULL),
(22,20,'Badge non abilitato al varco',NULL),
(22,22,'Normal',2),
(23,20,'Richiesta nuovo account per specializzando',NULL),
(23,22,'Low',1),
(24,20,'Monitor guasto postazione triage',NULL),
(24,22,'High',3),
(25,20,'Errore invio ordine al magazzino',NULL),
(25,22,'High',3),
(26,20,'Referti LIS non arrivano in cartella',NULL),
(26,22,'Normal',2),
(27,20,'Stampante del reparto non stampa',NULL),
(27,22,'High',3),
(28,20,'Monitor guasto postazione triage',NULL),
(28,22,'Low',1),
(29,20,'Badge non abilitato al varco',NULL),
(29,22,'Low',1),
(30,20,'Badge non abilitato al varco',NULL),
(30,22,'Normal',2),
(31,20,'Accesso al FSE non funziona',NULL),
(31,22,'High',3),
(32,20,'Casella email piena',NULL),
(32,22,'Normal',2),
(33,20,'Errore invio ordine al magazzino',NULL),
(33,22,'High',3),
(34,20,'Badge non abilitato al varco',NULL),
(34,22,'Normal',2),
(35,20,'Richiesta installazione software DICOM viewer',NULL),
(35,22,'Emergency',4),
(36,20,'Stampante del reparto non stampa',NULL),
(36,22,'High',3),
(37,20,'Monitor guasto postazione triage',NULL),
(37,22,'High',3),
(38,20,'Casella email piena',NULL),
(38,22,'Normal',2),
(39,20,'Referti LIS non arrivano in cartella',NULL),
(39,22,'Emergency',4),
(40,20,'Referti LIS non arrivano in cartella',NULL),
(40,22,'Low',1),
(41,20,'Errore invio ordine al magazzino',NULL),
(41,22,'Normal',2),
(42,20,'PC lentissimo in ambulatorio 3',NULL),
(42,22,'Normal',2),
(43,20,'Stampante del reparto non stampa',NULL),
(43,22,'High',3),
(44,20,'Casella email piena',NULL),
(44,22,'High',3),
(45,20,'Referti LIS non arrivano in cartella',NULL),
(45,22,'Normal',2),
(46,20,'Telefono IP senza linea',NULL),
(46,22,'Normal',2),
(47,20,'PC lentissimo in ambulatorio 3',NULL),
(47,22,'Normal',2),
(48,20,'Richiesta nuovo account per specializzando',NULL),
(48,22,'Normal',2),
(49,20,'Stampante del reparto non stampa',NULL),
(49,22,'Normal',2),
(50,20,'Monitor guasto postazione triage',NULL),
(50,22,'High',3),
(51,20,'PC lentissimo in ambulatorio 3',NULL),
(51,22,'Emergency',4),
(52,20,'Badge non abilitato al varco',NULL),
(52,22,'High',3),
(53,20,'Wi-Fi assente in sala riunioni',NULL),
(53,22,'High',3),
(54,20,'Casella email piena',NULL),
(54,22,'Low',1),
(55,20,'Richiesta nuovo account per specializzando',NULL),
(55,22,'Normal',2),
(56,20,'Monitor guasto postazione triage',NULL),
(56,22,'High',3),
(57,20,'Richiesta installazione software DICOM viewer',NULL),
(57,22,'Normal',2),
(58,20,'PC lentissimo in ambulatorio 3',NULL),
(58,22,'Emergency',4),
(59,20,'Monitor guasto postazione triage',NULL),
(59,22,'Low',1),
(60,20,'PC lentissimo in ambulatorio 3',NULL),
(60,22,'Normal',2),
(61,20,'Accesso al FSE non funziona',NULL),
(61,22,'Low',1),
(62,20,'PC lentissimo in ambulatorio 3',NULL),
(62,22,'High',3),
(63,20,'Wi-Fi assente in sala riunioni',NULL),
(63,22,'Normal',2),
(64,20,'Badge non abilitato al varco',NULL),
(64,22,'Normal',2),
(65,20,'Monitor guasto postazione triage',NULL),
(65,22,'Normal',2),
(66,20,'Richiesta nuovo account per specializzando',NULL),
(66,22,'High',3),
(67,20,'Monitor guasto postazione triage',NULL),
(67,22,'Emergency',4),
(68,20,'Monitor guasto postazione triage',NULL),
(68,22,'Emergency',4),
(69,20,'Wi-Fi assente in sala riunioni',NULL),
(69,22,'Normal',2),
(70,20,'Stampante del reparto non stampa',NULL),
(70,22,'Normal',2),
(71,20,'Monitor guasto postazione triage',NULL),
(71,22,'Emergency',4),
(72,20,'PC lentissimo in ambulatorio 3',NULL),
(72,22,'Normal',2),
(73,20,'Richiesta installazione software DICOM viewer',NULL),
(73,22,'Low',1),
(74,20,'Errore invio ordine al magazzino',NULL),
(74,22,'High',3),
(75,20,'Monitor guasto postazione triage',NULL),
(75,22,'Low',1),
(76,20,'Badge non abilitato al varco',NULL),
(76,22,'Normal',2),
(77,20,'Accesso al FSE non funziona',NULL),
(77,22,'Low',1),
(78,20,'PC lentissimo in ambulatorio 3',NULL),
(78,22,'Normal',2),
(79,20,'Accesso al FSE non funziona',NULL),
(79,22,'Normal',2),
(80,20,'Richiesta nuovo account per specializzando',NULL),
(80,22,'Normal',2),
(81,20,'Errore invio ordine al magazzino',NULL),
(81,22,'Emergency',4),
(82,32,'Configurare nuovo account',NULL),
(83,32,'Contattare fornitore',NULL),
(84,32,'Aggiornare driver stampante',NULL),
(85,32,'Aggiornare driver stampante',NULL),
(86,32,'Sostituire toner',NULL),
(87,32,'Configurare nuovo account',NULL),
(88,32,'Contattare fornitore',NULL),
(89,32,'Sostituire toner',NULL),
(90,32,'Aggiornare driver stampante',NULL),
(91,32,'Configurare nuovo account',NULL),
(92,32,'Configurare nuovo account',NULL),
(93,32,'Sostituire toner',NULL);
/*!40000 ALTER TABLE `ost_form_entry_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_form_field`
--

DROP TABLE IF EXISTS `ost_form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_form_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(11) unsigned NOT NULL,
  `flags` int(10) unsigned DEFAULT 1,
  `type` varchar(255) NOT NULL DEFAULT 'text',
  `label` varchar(255) NOT NULL,
  `name` varchar(64) NOT NULL,
  `configuration` text DEFAULT NULL,
  `sort` int(11) unsigned NOT NULL,
  `hint` varchar(512) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_form_field`
--

LOCK TABLES `ost_form_field` WRITE;
/*!40000 ALTER TABLE `ost_form_field` DISABLE KEYS */;
INSERT INTO `ost_form_field` VALUES
(1,1,489395,'text','Email Address','email','{\"size\":40,\"length\":64,\"validator\":\"email\"}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,1,489395,'text','Full Name','name','{\"size\":40,\"length\":64}',2,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,13057,'phone','Phone Number','phone',NULL,3,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,1,12289,'memo','Internal Notes','notes','{\"rows\":4,\"cols\":40}',4,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(20,2,489265,'text','Issue Summary','subject','{\"size\":40,\"length\":50}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(21,2,480547,'thread','Issue Details','message',NULL,2,'Details on the reason(s) for opening the ticket.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(22,2,274609,'priority','Priority Level','priority',NULL,3,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(23,3,291249,'text','Company Name','name','{\"size\":40,\"length\":64}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(24,3,274705,'text','Website','website','{\"size\":40,\"length\":64}',2,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(25,3,274705,'phone','Phone Number','phone','{\"ext\":false}',3,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(26,3,12545,'memo','Address','address','{\"rows\":2,\"cols\":40,\"html\":false,\"length\":100}',4,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(27,4,489395,'text','Name','name','{\"size\":40,\"length\":64}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(28,4,13057,'memo','Address','address','{\"rows\":2,\"cols\":40,\"length\":100,\"html\":false}',2,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(29,4,13057,'phone','Phone','phone',NULL,3,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(30,4,13057,'text','Website','website','{\"size\":40,\"length\":0}',4,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(31,4,12289,'memo','Internal Notes','notes','{\"rows\":4,\"cols\":40}',5,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(32,5,487601,'text','Title','title','{\"size\":40,\"length\":50}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(33,5,413939,'thread','Description','description',NULL,2,'Details on the reason(s) for creating the task.','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(34,6,487665,'state','State','state','{\"prompt\":\"State of a ticket\"}',1,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(35,6,471073,'memo','Description','description','{\"rows\":\"2\",\"cols\":\"40\",\"html\":\"\",\"length\":\"100\"}',3,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_group`
--

DROP TABLE IF EXISTS `ost_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) unsigned NOT NULL,
  `flags` int(11) unsigned NOT NULL DEFAULT 1,
  `name` varchar(120) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_group`
--

LOCK TABLES `ost_group` WRITE;
/*!40000 ALTER TABLE `ost_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_help_topic`
--

DROP TABLE IF EXISTS `ost_help_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_help_topic` (
  `topic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `noautoresp` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned DEFAULT 0,
  `status_id` int(10) unsigned NOT NULL DEFAULT 0,
  `priority_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sequence_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  `topic` varchar(128) NOT NULL DEFAULT '',
  `number_format` varchar(32) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic` (`topic`,`topic_pid`),
  KEY `topic_pid` (`topic_pid`),
  KEY `priority_id` (`priority_id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`,`team_id`),
  KEY `sla_id` (`sla_id`),
  KEY `page_id` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_help_topic`
--

LOCK TABLES `ost_help_topic` WRITE;
/*!40000 ALTER TABLE `ost_help_topic` DISABLE KEYS */;
INSERT INTO `ost_help_topic` VALUES
(1,0,1,0,2,0,2,0,0,0,0,0,0,1,'General Inquiry',NULL,'Questions about products or services','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,0,1,0,2,0,1,0,0,0,0,0,0,0,'Feedback',NULL,'Tickets that primarily concern the sales and billing departments','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(10,0,1,0,2,0,2,3,0,0,0,0,0,0,'Report a Problem',NULL,'Product, service, or equipment related issues','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(11,10,1,0,2,0,3,0,0,0,1,0,0,1,'Access Issue',NULL,'Report an inability access a physical or virtual asset','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_help_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_help_topic_form`
--

DROP TABLE IF EXISTS `ost_help_topic_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_help_topic_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) unsigned NOT NULL DEFAULT 0,
  `form_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  `extra` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `topic-form` (`topic_id`,`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_help_topic_form`
--

LOCK TABLES `ost_help_topic_form` WRITE;
/*!40000 ALTER TABLE `ost_help_topic_form` DISABLE KEYS */;
INSERT INTO `ost_help_topic_form` VALUES
(1,1,2,1,'{\"disable\":[]}'),
(2,2,2,1,'{\"disable\":[]}'),
(3,10,2,1,'{\"disable\":[]}'),
(4,11,2,1,'{\"disable\":[]}');
/*!40000 ALTER TABLE `ost_help_topic_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_list`
--

DROP TABLE IF EXISTS `ost_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_list` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_plural` varchar(255) DEFAULT NULL,
  `sort_mode` enum('Alpha','-Alpha','SortCol') NOT NULL DEFAULT 'Alpha',
  `masks` int(11) unsigned NOT NULL DEFAULT 0,
  `type` varchar(16) DEFAULT NULL,
  `configuration` text NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_list`
--

LOCK TABLES `ost_list` WRITE;
/*!40000 ALTER TABLE `ost_list` DISABLE KEYS */;
INSERT INTO `ost_list` VALUES
(1,'Ticket Status','Ticket Statuses','SortCol',13,'ticket-status','{\"handler\":\"TicketStatusList\"}','Ticket statuses','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_list_items`
--

DROP TABLE IF EXISTS `ost_list_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_list_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) DEFAULT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 1,
  `value` varchar(255) NOT NULL,
  `extra` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `properties` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `list_item_lookup` (`list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_list_items`
--

LOCK TABLES `ost_list_items` WRITE;
/*!40000 ALTER TABLE `ost_list_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_list_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_lock`
--

DROP TABLE IF EXISTS `ost_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_lock` (
  `lock_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `expire` datetime DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`lock_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_lock`
--

LOCK TABLES `ost_lock` WRITE;
/*!40000 ALTER TABLE `ost_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_note`
--

DROP TABLE IF EXISTS `ost_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `ext_id` varchar(10) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ext_id` (`ext_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_note`
--

LOCK TABLES `ost_note` WRITE;
/*!40000 ALTER TABLE `ost_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_organization`
--

DROP TABLE IF EXISTS `ost_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_organization` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `manager` varchar(16) NOT NULL DEFAULT '',
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `domain` varchar(256) NOT NULL DEFAULT '',
  `extra` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_organization`
--

LOCK TABLES `ost_organization` WRITE;
/*!40000 ALTER TABLE `ost_organization` DISABLE KEYS */;
INSERT INTO `ost_organization` VALUES
(1,'osTicket','',8,'',NULL,'2026-10-08 06:22:17',NULL),
(2,'Radiologia','',8,'',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(3,'Cardiologia','',8,'',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(4,'Laboratorio Analisi','',8,'',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(5,'Amministrazione','',8,'',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(6,'Pronto Soccorso','',8,'',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02');
/*!40000 ALTER TABLE `ost_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_organization__cdata`
--

DROP TABLE IF EXISTS `ost_organization__cdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_organization__cdata` (
  `org_id` int(11) unsigned NOT NULL,
  `name` mediumtext DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `phone` mediumtext DEFAULT NULL,
  `website` mediumtext DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_organization__cdata`
--

LOCK TABLES `ost_organization__cdata` WRITE;
/*!40000 ALTER TABLE `ost_organization__cdata` DISABLE KEYS */;
INSERT INTO `ost_organization__cdata` VALUES
(2,NULL,'','','',''),
(3,NULL,'','','',''),
(4,NULL,'','','',''),
(5,NULL,'','','',''),
(6,NULL,'','','','');
/*!40000 ALTER TABLE `ost_organization__cdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_plugin`
--

DROP TABLE IF EXISTS `ost_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `install_path` varchar(60) NOT NULL,
  `isphar` tinyint(1) NOT NULL DEFAULT 0,
  `isactive` tinyint(1) NOT NULL DEFAULT 0,
  `version` varchar(64) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `installed` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `install_path` (`install_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_plugin`
--

LOCK TABLES `ost_plugin` WRITE;
/*!40000 ALTER TABLE `ost_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_plugin_instance`
--

DROP TABLE IF EXISTS `ost_plugin_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_plugin_instance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_id` int(11) unsigned NOT NULL,
  `flags` int(10) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plugin_id` (`plugin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_plugin_instance`
--

LOCK TABLES `ost_plugin_instance` WRITE;
/*!40000 ALTER TABLE `ost_plugin_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_plugin_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue`
--

DROP TABLE IF EXISTS `ost_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT 0,
  `columns_id` int(11) unsigned DEFAULT NULL,
  `sort_id` int(11) unsigned DEFAULT NULL,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `title` varchar(60) DEFAULT NULL,
  `config` text DEFAULT NULL,
  `filter` varchar(64) DEFAULT NULL,
  `root` varchar(32) DEFAULT NULL,
  `path` varchar(80) NOT NULL DEFAULT '/',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue`
--

LOCK TABLES `ost_queue` WRITE;
/*!40000 ALTER TABLE `ost_queue` DISABLE KEYS */;
INSERT INTO `ost_queue` VALUES
(1,0,NULL,1,3,0,1,'Open','[[\"status__state\",\"includes\",{\"open\":\"Open\"}]]',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(2,1,NULL,4,43,0,1,'Open','{\"criteria\":[[\"isanswered\",\"nset\",null]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(3,1,NULL,4,43,0,2,'Answered','{\"criteria\":[[\"isanswered\",\"set\",null]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(4,1,NULL,4,43,0,3,'Overdue','{\"criteria\":[[\"isoverdue\",\"set\",null]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(5,0,NULL,3,3,0,3,'My Tickets','{\"criteria\":[[\"assignee\",\"includes\",{\"M\":\"Me\",\"T\":\"One of my teams\"}],[\"status__state\",\"includes\",{\"open\":\"Open\"}]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(6,5,NULL,NULL,43,0,1,'Assigned to Me','{\"criteria\":[[\"assignee\",\"includes\",{\"M\":\"Me\"}]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(7,5,NULL,NULL,43,0,2,'Assigned to Teams','{\"criteria\":[[\"assignee\",\"!includes\",{\"M\":\"Me\"}]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(8,0,NULL,5,3,0,4,'Closed','{\"criteria\":[[\"status__state\",\"includes\",{\"closed\":\"Closed\"}]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(9,8,NULL,5,43,0,1,'Today','{\"criteria\":[[\"closed\",\"period\",\"td\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(10,8,NULL,5,43,0,2,'Yesterday','{\"criteria\":[[\"closed\",\"period\",\"yd\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(11,8,NULL,5,43,0,3,'This Week','{\"criteria\":[[\"closed\",\"period\",\"tw\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(12,8,NULL,5,43,0,4,'This Month','{\"criteria\":[[\"closed\",\"period\",\"tm\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(13,8,NULL,6,43,0,5,'This Quarter','{\"criteria\":[[\"closed\",\"period\",\"tq\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(14,8,NULL,7,43,0,6,'This Year','{\"criteria\":[[\"closed\",\"period\",\"ty\"]],\"conditions\":[]}',NULL,'T','/','2026-10-08 06:22:17','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `ost_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_column`
--

DROP TABLE IF EXISTS `ost_queue_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_column` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL DEFAULT '',
  `primary` varchar(64) NOT NULL DEFAULT '',
  `secondary` varchar(64) DEFAULT NULL,
  `filter` varchar(32) DEFAULT NULL,
  `truncate` varchar(16) DEFAULT NULL,
  `annotations` text DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `extra` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_column`
--

LOCK TABLES `ost_queue_column` WRITE;
/*!40000 ALTER TABLE `ost_queue_column` DISABLE KEYS */;
INSERT INTO `ost_queue_column` VALUES
(1,0,'Ticket #','number',NULL,'link:ticketP','wrap','[{\"c\":\"TicketSourceDecoration\",\"p\":\"b\"}]','[{\"crit\":[\"isanswered\",\"nset\",null],\"prop\":{\"font-weight\":\"bold\"}}]',NULL),
(2,0,'Date Created','created',NULL,'date:full','wrap','[]','[]',NULL),
(3,0,'Subject','cdata__subject',NULL,'link:ticket','ellipsis','[{\"c\":\"TicketThreadCount\",\"p\":\">\"},{\"c\":\"ThreadAttachmentCount\",\"p\":\"a\"},{\"c\":\"OverdueFlagDecoration\",\"p\":\"<\"},{\"c\":\"LockDecoration\",\"p\":\"<\"}]','[{\"crit\":[\"isanswered\",\"nset\",null],\"prop\":{\"font-weight\":\"bold\"}}]',NULL),
(4,0,'User Name','user__name',NULL,NULL,'wrap','[{\"c\":\"ThreadCollaboratorCount\",\"p\":\">\"}]','[]',NULL),
(5,0,'Priority','cdata__priority',NULL,NULL,'wrap','[]','[]',NULL),
(6,0,'Status','status__id',NULL,NULL,'wrap','[]','[]',NULL),
(7,0,'Close Date','closed',NULL,'date:full','wrap','[]','[]',NULL),
(8,0,'Assignee','assignee',NULL,NULL,'wrap','[]','[]',NULL),
(9,0,'Due Date','duedate','est_duedate','date:human','wrap','[]','[]',NULL),
(10,0,'Last Updated','lastupdate',NULL,'date:full','wrap','[]','[]',NULL),
(11,0,'Department','dept_id',NULL,NULL,'wrap','[]','[]',NULL),
(12,0,'Last Message','thread__lastmessage',NULL,'date:human','wrap','[]','[]',NULL),
(13,0,'Last Response','thread__lastresponse',NULL,'date:human','wrap','[]','[]',NULL),
(14,0,'Team','team_id',NULL,NULL,'wrap','[]','[]',NULL);
/*!40000 ALTER TABLE `ost_queue_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_columns`
--

DROP TABLE IF EXISTS `ost_queue_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_columns` (
  `queue_id` int(11) unsigned NOT NULL,
  `column_id` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `bits` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  `heading` varchar(64) DEFAULT NULL,
  `width` int(10) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`queue_id`,`column_id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_columns`
--

LOCK TABLES `ost_queue_columns` WRITE;
/*!40000 ALTER TABLE `ost_queue_columns` DISABLE KEYS */;
INSERT INTO `ost_queue_columns` VALUES
(1,1,0,1,1,'Ticket',100),
(1,3,0,1,3,'Subject',300),
(1,4,0,1,4,'From',185),
(1,5,0,1,5,'Priority',85),
(1,8,0,1,6,'Assigned To',160),
(1,10,0,1,2,'Last Updated',150),
(2,1,0,1,1,'Ticket',100),
(2,3,0,1,3,'Subject',300),
(2,4,0,1,4,'From',185),
(2,5,0,1,5,'Priority',85),
(2,8,0,1,6,'Assigned To',160),
(2,10,0,1,2,'Last Updated',150),
(3,1,0,1,1,'Ticket',100),
(3,3,0,1,3,'Subject',300),
(3,4,0,1,4,'From',185),
(3,5,0,1,5,'Priority',85),
(3,8,0,1,6,'Assigned To',160),
(3,10,0,1,2,'Last Updated',150),
(4,1,0,1,1,'Ticket',100),
(4,3,0,1,3,'Subject',300),
(4,4,0,1,4,'From',185),
(4,5,0,1,5,'Priority',85),
(4,8,0,1,6,'Assigned To',160),
(4,9,0,1,9,'Due Date',150),
(5,1,0,1,1,'Ticket',100),
(5,3,0,1,3,'Subject',300),
(5,4,0,1,4,'From',185),
(5,5,0,1,5,'Priority',85),
(5,10,0,1,2,'Last Update',150),
(5,11,0,1,6,'Department',160),
(6,1,0,1,1,'Ticket',100),
(6,3,0,1,3,'Subject',300),
(6,4,0,1,4,'From',185),
(6,5,0,1,5,'Priority',85),
(6,10,0,1,2,'Last Update',150),
(6,11,0,1,6,'Department',160),
(7,1,0,1,1,'Ticket',100),
(7,3,0,1,3,'Subject',300),
(7,4,0,1,4,'From',185),
(7,5,0,1,5,'Priority',85),
(7,10,0,1,2,'Last Update',150),
(7,14,0,1,6,'Team',160),
(8,1,0,1,1,'Ticket',100),
(8,3,0,1,3,'Subject',300),
(8,4,0,1,4,'From',185),
(8,7,0,1,2,'Date Closed',150),
(8,8,0,1,6,'Closed By',160),
(9,1,0,1,1,'Ticket',100),
(9,3,0,1,3,'Subject',300),
(9,4,0,1,4,'From',185),
(9,7,0,1,2,'Date Closed',150),
(9,8,0,1,6,'Closed By',160),
(10,1,0,1,1,'Ticket',100),
(10,3,0,1,3,'Subject',300),
(10,4,0,1,4,'From',185),
(10,7,0,1,2,'Date Closed',150),
(10,8,0,1,6,'Closed By',160),
(11,1,0,1,1,'Ticket',100),
(11,3,0,1,3,'Subject',300),
(11,4,0,1,4,'From',185),
(11,7,0,1,2,'Date Closed',150),
(11,8,0,1,6,'Closed By',160),
(12,1,0,1,1,'Ticket',100),
(12,3,0,1,3,'Subject',300),
(12,4,0,1,4,'From',185),
(12,7,0,1,2,'Date Closed',150),
(12,8,0,1,6,'Closed By',160),
(13,1,0,1,1,'Ticket',100),
(13,3,0,1,3,'Subject',300),
(13,4,0,1,4,'From',185),
(13,7,0,1,2,'Date Closed',150),
(13,8,0,1,6,'Closed By',160),
(14,1,0,1,1,'Ticket',100),
(14,3,0,1,3,'Subject',300),
(14,4,0,1,4,'From',185),
(14,7,0,1,2,'Date Closed',150),
(14,8,0,1,6,'Closed By',160);
/*!40000 ALTER TABLE `ost_queue_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_config`
--

DROP TABLE IF EXISTS `ost_queue_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_config` (
  `queue_id` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `setting` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`queue_id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_config`
--

LOCK TABLES `ost_queue_config` WRITE;
/*!40000 ALTER TABLE `ost_queue_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_queue_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_export`
--

DROP TABLE IF EXISTS `ost_queue_export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_export` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `queue_id` int(11) unsigned NOT NULL,
  `path` varchar(64) NOT NULL DEFAULT '',
  `heading` varchar(64) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `queue_id` (`queue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_export`
--

LOCK TABLES `ost_queue_export` WRITE;
/*!40000 ALTER TABLE `ost_queue_export` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_queue_export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_sort`
--

DROP TABLE IF EXISTS `ost_queue_sort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_sort` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `root` varchar(32) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `columns` text DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_sort`
--

LOCK TABLES `ost_queue_sort` WRITE;
/*!40000 ALTER TABLE `ost_queue_sort` DISABLE KEYS */;
INSERT INTO `ost_queue_sort` VALUES
(1,NULL,'Priority + Most Recently Updated','[\"-cdata__priority\",\"-lastupdate\"]','2026-10-08 06:22:17'),
(2,NULL,'Priority + Most Recently Created','[\"-cdata__priority\",\"-created\"]','2026-10-08 06:22:17'),
(3,NULL,'Priority + Due Date','[\"-cdata__priority\",\"-est_duedate\"]','2026-10-08 06:22:17'),
(4,NULL,'Due Date','[\"-est_duedate\"]','2026-10-08 06:22:17'),
(5,NULL,'Closed Date','[\"-closed\"]','2026-10-08 06:22:17'),
(6,NULL,'Create Date','[\"-created\"]','2026-10-08 06:22:17'),
(7,NULL,'Update Date','[\"-lastupdate\"]','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_queue_sort` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_queue_sorts`
--

DROP TABLE IF EXISTS `ost_queue_sorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_queue_sorts` (
  `queue_id` int(11) unsigned NOT NULL,
  `sort_id` int(11) unsigned NOT NULL,
  `bits` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`queue_id`,`sort_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_queue_sorts`
--

LOCK TABLES `ost_queue_sorts` WRITE;
/*!40000 ALTER TABLE `ost_queue_sorts` DISABLE KEYS */;
INSERT INTO `ost_queue_sorts` VALUES
(1,1,0,0),
(1,2,0,0),
(1,3,0,0),
(1,4,0,0),
(1,6,0,0),
(1,7,0,0),
(5,1,0,0),
(5,2,0,0),
(5,3,0,0),
(5,4,0,0),
(5,6,0,0),
(5,7,0,0),
(6,1,0,0),
(6,2,0,0),
(6,3,0,0),
(6,4,0,0),
(6,6,0,0),
(6,7,0,0),
(7,1,0,0),
(7,2,0,0),
(7,3,0,0),
(7,4,0,0),
(7,6,0,0),
(7,7,0,0),
(8,1,0,0),
(8,2,0,0),
(8,3,0,0),
(8,4,0,0),
(8,5,0,0),
(8,6,0,0),
(8,7,0,0),
(9,1,0,0),
(9,2,0,0),
(9,3,0,0),
(9,4,0,0),
(9,5,0,0),
(9,6,0,0),
(9,7,0,0),
(10,1,0,0),
(10,2,0,0),
(10,3,0,0),
(10,4,0,0),
(10,5,0,0),
(10,6,0,0),
(10,7,0,0),
(11,1,0,0),
(11,2,0,0),
(11,3,0,0),
(11,4,0,0),
(11,5,0,0),
(11,6,0,0),
(11,7,0,0),
(12,1,0,0),
(12,2,0,0),
(12,3,0,0),
(12,4,0,0),
(12,5,0,0),
(12,6,0,0),
(12,7,0,0),
(13,1,0,0),
(13,2,0,0),
(13,3,0,0),
(13,4,0,0),
(13,5,0,0),
(13,6,0,0),
(13,7,0,0),
(14,1,0,0),
(14,2,0,0),
(14,3,0,0),
(14,4,0,0),
(14,5,0,0),
(14,6,0,0),
(14,7,0,0);
/*!40000 ALTER TABLE `ost_queue_sorts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_role`
--

DROP TABLE IF EXISTS `ost_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `name` varchar(64) DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_role`
--

LOCK TABLES `ost_role` WRITE;
/*!40000 ALTER TABLE `ost_role` DISABLE KEYS */;
INSERT INTO `ost_role` VALUES
(1,1,'All Access','{\"ticket.assign\":1,\"ticket.close\":1,\"ticket.create\":1,\"ticket.delete\":1,\"ticket.edit\":1,\"thread.edit\":1,\"ticket.link\":1,\"ticket.markanswered\":1,\"ticket.merge\":1,\"ticket.reply\":1,\"ticket.refer\":1,\"ticket.release\":1,\"ticket.transfer\":1,\"task.assign\":1,\"task.close\":1,\"task.create\":1,\"task.delete\":1,\"task.edit\":1,\"task.reply\":1,\"task.transfer\":1,\"canned.manage\":1}','Role with unlimited access','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,1,'Expanded Access','{\"ticket.assign\":1,\"ticket.close\":1,\"ticket.create\":1,\"ticket.edit\":1,\"ticket.link\":1,\"ticket.merge\":1,\"ticket.reply\":1,\"ticket.refer\":1,\"ticket.release\":1,\"ticket.transfer\":1,\"task.assign\":1,\"task.close\":1,\"task.create\":1,\"task.edit\":1,\"task.reply\":1,\"task.transfer\":1,\"canned.manage\":1}','Role with expanded access','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,'Limited Access','{\"ticket.assign\":1,\"ticket.create\":1,\"ticket.link\":1,\"ticket.merge\":1,\"ticket.refer\":1,\"ticket.release\":1,\"ticket.transfer\":1,\"task.assign\":1,\"task.reply\":1,\"task.transfer\":1}','Role with limited access','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,1,'View only',NULL,'Simple role with no permissions','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_schedule`
--

DROP TABLE IF EXISTS `ost_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_schedule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_schedule`
--

LOCK TABLES `ost_schedule` WRITE;
/*!40000 ALTER TABLE `ost_schedule` DISABLE KEYS */;
INSERT INTO `ost_schedule` VALUES
(1,1,'Monday - Friday 8am - 5pm with U.S. Holidays',NULL,'','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,1,'24/7',NULL,'','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(3,1,'24/5',NULL,'','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(4,0,'U.S. Holidays',NULL,'','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_schedule_entry`
--

DROP TABLE IF EXISTS `ost_schedule_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_schedule_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `repeats` varchar(16) NOT NULL DEFAULT 'never',
  `starts_on` date DEFAULT NULL,
  `starts_at` time DEFAULT NULL,
  `ends_on` date DEFAULT NULL,
  `ends_at` time DEFAULT NULL,
  `stops_on` datetime DEFAULT NULL,
  `day` tinyint(4) DEFAULT NULL,
  `week` tinyint(4) DEFAULT NULL,
  `month` tinyint(4) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `repeats` (`repeats`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_schedule_entry`
--

LOCK TABLES `ost_schedule_entry` WRITE;
/*!40000 ALTER TABLE `ost_schedule_entry` DISABLE KEYS */;
INSERT INTO `ost_schedule_entry` VALUES
(1,1,0,0,'Monday','weekly','2019-01-07','08:00:00','2019-01-07','17:00:00',NULL,1,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(2,1,0,0,'Tuesday','weekly','2019-01-08','08:00:00','2019-01-08','17:00:00',NULL,2,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(3,1,0,0,'Wednesday','weekly','2019-01-09','08:00:00','2019-01-09','17:00:00',NULL,3,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(4,1,0,0,'Thursday','weekly','2019-01-10','08:00:00','2019-01-10','17:00:00',NULL,4,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(5,1,0,0,'Friday','weekly','2019-01-11','08:00:00','2019-01-11','17:00:00',NULL,5,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(6,2,0,0,'Daily','daily','2019-01-01','00:00:00','2019-01-01','23:59:59',NULL,NULL,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(7,3,0,0,'Weekdays','weekdays','2019-01-01','00:00:00','2019-01-01','23:59:59',NULL,NULL,NULL,NULL,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(8,4,0,0,'New Year\'s Day','yearly','2019-01-01','00:00:00','2019-01-01','23:59:59',NULL,1,NULL,1,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(9,4,0,0,'MLK Day','yearly','2019-01-21','00:00:00','2019-01-21','23:59:59',NULL,1,3,1,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(10,4,0,0,'Memorial Day','yearly','2019-05-27','00:00:00','2019-05-27','23:59:59',NULL,1,-1,5,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(11,4,0,0,'Independence Day (4th of July)','yearly','2019-07-04','00:00:00','2019-07-04','23:59:59',NULL,4,NULL,7,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(12,4,0,0,'Labor Day','yearly','2019-09-02','00:00:00','2019-09-02','23:59:59',NULL,1,1,9,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(13,4,0,0,'Indigenous Peoples\' Day (Whodat Columbus)','yearly','2019-10-14','00:00:00','2019-10-14','23:59:59',NULL,1,2,10,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(14,4,0,0,'Veterans Day','yearly','2019-11-11','00:00:00','2019-11-11','23:59:59',NULL,11,NULL,11,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(15,4,0,0,'Thanksgiving Day','yearly','2019-11-28','00:00:00','2019-11-28','23:59:59',NULL,4,4,11,'0000-00-00 00:00:00','2026-10-08 06:22:17'),
(16,4,0,0,'Christmas Day','yearly','2019-11-25','00:00:00','2019-11-25','23:59:59',NULL,25,NULL,12,'0000-00-00 00:00:00','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_schedule_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_sequence`
--

DROP TABLE IF EXISTS `ost_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_sequence` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `flags` int(10) unsigned DEFAULT NULL,
  `next` bigint(20) unsigned NOT NULL DEFAULT 1,
  `increment` int(11) DEFAULT 1,
  `padding` char(1) DEFAULT '0',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_sequence`
--

LOCK TABLES `ost_sequence` WRITE;
/*!40000 ALTER TABLE `ost_sequence` DISABLE KEYS */;
INSERT INTO `ost_sequence` VALUES
(1,'General Tickets',1,1,1,'0','0000-00-00 00:00:00'),
(2,'Tasks Sequence',1,13,1,'0','2026-10-09 10:44:26');
/*!40000 ALTER TABLE `ost_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_session`
--

DROP TABLE IF EXISTS `ost_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_session` (
  `session_id` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `session_data` blob DEFAULT NULL,
  `session_expire` datetime DEFAULT NULL,
  `session_updated` datetime DEFAULT NULL,
  `user_id` varchar(16) NOT NULL DEFAULT '0' COMMENT 'osTicket staff/client ID',
  `user_ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `updated` (`session_updated`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_session`
--

LOCK TABLES `ost_session` WRITE;
/*!40000 ALTER TABLE `ost_session` DISABLE KEYS */;
INSERT INTO `ost_session` VALUES
('bs4546bpijo5orod6llf8q2vve','csrf|N;cfg:core|a:1:{s:18:\"verify_email_addrs\";i:0;}','2026-10-10 05:59:06','2026-10-09 05:59:06','0','10.20.0.15',''),
('fc2pgghq96n4dlbc6dg4it43v7','csrf|N;','2026-10-10 05:58:56','2026-10-09 05:58:56','0','10.20.0.15',''),
('h3he0kbdldtp429tmlgvsrd9qf','csrf|N;cfg:core|a:2:{s:18:\"verify_email_addrs\";i:0;s:11:\"db_timezone\";s:3:\"UTC\";}','2026-10-10 05:59:16','2026-10-09 05:59:16','0','10.20.0.15',''),
('hrve8ef2rel6vlve4g6ieuac93','csrf|a:2:{s:5:\"token\";s:40:\"33cb30dd170f39ba202b6fb8169d524dcddec4b5\";s:4:\"time\";i:1791440581;}','2026-10-09 06:23:01','2026-10-08 06:23:01','0','127.0.0.1','curl/8.5.0'),
('is9tou0c12ssbuff4vhkg92a7h','csrf|N;_staff|a:1:{s:4:\"auth\";a:2:{s:4:\"dest\";s:17:\"/scp/settings.php\";s:3:\"msg\";s:23:\"Authentication Required\";}}','2026-10-09 06:48:49','2026-10-08 06:48:49','0','127.0.0.1','curl/8.5.0'),
('jaq8ggs4tolmju3uk78lg9cu4v','csrf|a:2:{s:5:\"token\";s:40:\"86ff2f56ecc88828a1a50dbfec0fbcc774e4d6b3\";s:4:\"time\";i:1791440546;}_auth|a:1:{s:5:\"staff\";a:3:{s:2:\"id\";i:1;s:3:\"key\";s:14:\"local:devadmin\";s:3:\"2fa\";N;}}:token|a:1:{s:5:\"staff\";s:76:\"b042d939f4ae57f439ca9c7c3072f112:1791440546:f528764d624db129b32c21fbca0cb8d6\";}TIME_BOMB|i:1791440556;::Q:T|i:1;sort|a:1:{i:1;a:2:{s:9:\"queuesort\";O:9:\"QueueSort\":7:{s:2:\"ht\";a:5:{s:2:\"id\";i:1;s:4:\"root\";N;s:4:\"name\";s:32:\"Priority + Most Recently Updated\";s:7:\"columns\";s:34:\"[\"-cdata__priority\",\"-lastupdate\"]\";s:7:\"updated\";s:19:\"2026-10-08 06:22:17\";}s:5:\"dirty\";a:0:{}s:7:\"__new__\";b:0;s:11:\"__deleted__\";b:0;s:12:\"__deferred__\";a:0:{}s:8:\"_columns\";a:2:{s:15:\"cdata__priority\";b:1;s:10:\"lastupdate\";b:1;}s:6:\"_extra\";N;}s:3:\"dir\";i:0;}}cfg:core|a:1:{s:11:\"db_timezone\";s:3:\"UTC\";}qcounts|a:1:{s:48:\"counts.queues.1.XLZrga8SAcBgd7oxcrl02CIUAkRjYkXt\";a:2:{s:6:\"counts\";a:14:{s:2:\"q1\";d:1;s:2:\"q2\";d:1;s:2:\"q6\";d:0;s:2:\"q9\";d:0;s:2:\"q3\";d:0;s:2:\"q7\";d:0;s:3:\"q10\";d:0;s:2:\"q4\";d:0;s:2:\"q5\";d:0;s:3:\"q11\";d:0;s:2:\"q8\";d:0;s:3:\"q12\";d:0;s:3:\"q13\";d:0;s:3:\"q14\";d:0;}s:4:\"time\";i:1791440546;}}','2026-10-09 06:22:22','2026-10-08 06:22:26','1','127.0.0.1','curl/8.5.0'),
('m4mmmdadsrvjcbcosc9cknqka7','csrf|a:2:{s:5:\"token\";s:40:\"12ecf8efe0a12665367dd71027dff4c7512c6cb1\";s:4:\"time\";i:1791442138;}_auth|a:1:{s:5:\"staff\";a:3:{s:2:\"id\";i:1;s:3:\"key\";s:14:\"local:devadmin\";s:3:\"2fa\";N;}}:token|a:1:{s:5:\"staff\";s:76:\"d48ad009b0f12e7f96afbcedbcb99860:1791442138:f528764d624db129b32c21fbca0cb8d6\";}TIME_BOMB|i:1791442148;cfg:core|a:1:{s:11:\"db_timezone\";s:3:\"UTC\";}::Q:T|i:1;sort|a:1:{i:1;a:2:{s:9:\"queuesort\";O:9:\"QueueSort\":7:{s:2:\"ht\";a:5:{s:2:\"id\";i:1;s:4:\"root\";N;s:4:\"name\";s:32:\"Priority + Most Recently Updated\";s:7:\"columns\";s:34:\"[\"-cdata__priority\",\"-lastupdate\"]\";s:7:\"updated\";s:19:\"2026-10-08 06:22:17\";}s:5:\"dirty\";a:0:{}s:7:\"__new__\";b:0;s:11:\"__deleted__\";b:0;s:12:\"__deferred__\";a:0:{}s:8:\"_columns\";a:2:{s:15:\"cdata__priority\";b:1;s:10:\"lastupdate\";b:1;}s:6:\"_extra\";N;}s:3:\"dir\";i:0;}}qcounts|a:1:{s:48:\"counts.queues.1.XLZrga8SAcBgd7oxcrl02CIUAkRjYkXt\";a:2:{s:6:\"counts\";a:14:{s:2:\"q1\";d:1;s:2:\"q2\";d:1;s:2:\"q6\";d:0;s:2:\"q9\";d:0;s:2:\"q3\";d:0;s:2:\"q7\";d:0;s:3:\"q10\";d:0;s:2:\"q4\";d:0;s:2:\"q5\";d:0;s:3:\"q11\";d:0;s:2:\"q8\";d:0;s:3:\"q12\";d:0;s:3:\"q13\";d:0;s:3:\"q14\";d:0;}s:4:\"time\";i:1791442138;}}','2026-10-09 06:48:58','2026-10-08 06:48:58','1','127.0.0.1','curl/8.5.0'),
('nehil18a17tfc004uhc0bh4r43','csrf|a:2:{s:5:\"token\";s:40:\"0d06fe709b54455bfcbf18e153393a20f14e6f77\";s:4:\"time\";i:1791543239;}_auth|a:1:{s:5:\"staff\";N;}','2026-10-10 10:53:59','2026-10-09 10:53:59','0','127.0.0.1','curl/8.5.0'),
('tsd26qscdrbgqins2dd25r7hdo','csrf|N;cfg:core|a:1:{s:18:\"verify_email_addrs\";i:0;}','2026-10-10 05:59:03','2026-10-09 05:59:03','0','10.20.0.15',''),
('u2358cgc78u1s0258s0p7bah73','csrf|N;cfg:core|a:1:{s:18:\"verify_email_addrs\";i:0;}','2026-10-10 10:44:27','2026-10-09 10:44:27','0','10.20.0.15','');
/*!40000 ALTER TABLE `ost_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_sla`
--

DROP TABLE IF EXISTS `ost_sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_sla` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 3,
  `grace_period` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_sla`
--

LOCK TABLES `ost_sla` WRITE;
/*!40000 ALTER TABLE `ost_sla` DISABLE KEYS */;
INSERT INTO `ost_sla` VALUES
(1,0,3,18,'Default SLA',NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_staff`
--

DROP TABLE IF EXISTS `ost_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_staff` (
  `staff_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(32) NOT NULL DEFAULT '',
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `passwd` varchar(128) DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(24) NOT NULL DEFAULT '',
  `phone_ext` varchar(6) DEFAULT NULL,
  `mobile` varchar(24) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `locale` varchar(16) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT 1,
  `isadmin` tinyint(1) NOT NULL DEFAULT 0,
  `isvisible` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `onvacation` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `assigned_only` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `show_assigned_tickets` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `change_passwd` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `max_page_size` int(11) unsigned NOT NULL DEFAULT 0,
  `auto_refresh_rate` int(10) unsigned NOT NULL DEFAULT 0,
  `default_signature_type` enum('none','mine','dept') NOT NULL DEFAULT 'none',
  `default_paper_size` enum('Letter','Legal','Ledger','A4','A3') NOT NULL DEFAULT 'Letter',
  `extra` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `passwdreset` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `username` (`username`),
  KEY `dept_id` (`dept_id`),
  KEY `issuperuser` (`isadmin`),
  KEY `isactive` (`isactive`),
  KEY `onvacation` (`onvacation`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_staff`
--

LOCK TABLES `ost_staff` WRITE;
/*!40000 ALTER TABLE `ost_staff` DISABLE KEYS */;
INSERT INTO `ost_staff` VALUES
(1,1,1,'devadmin','Admin','Dev','$2a$08$ekEzWFtpJzSaoaqq7optsOfe7bz5KQMGAjZJIhsN5C0Cg3dHTyIme',NULL,'admin@example.com','',NULL,'','',NULL,NULL,NULL,NULL,1,1,1,0,0,0,0,25,0,'none','Letter','{\"browser_lang\":\"en_US\"}','{\"user.create\":1,\"user.delete\":1,\"user.edit\":1,\"user.manage\":1,\"user.dir\":1,\"org.create\":1,\"org.delete\":1,\"org.edit\":1,\"faq.manage\":1,\"visibility.agents\":1,\"emails.banlist\":1,\"visibility.departments\":1}','2026-10-08 06:22:17','2026-10-09 10:49:38','2026-10-08 06:22:17','2026-10-09 10:49:38'),
(2,1,2,'mrossi','Mario','Rossi','$2a$08$dXkmyHE7CUMEQrduZLI6ROL9/KJQfGFV4tKPnnXveAuhk5SkkKT/e',NULL,'mrossi@ospedale.example','(087) 440-9470',NULL,'','',NULL,NULL,NULL,NULL,1,0,1,0,0,0,0,0,0,'none','Letter','{\"def_assn_role\":false}','{\"user.create\":1,\"user.edit\":1,\"user.dir\":1,\"org.create\":1,\"org.edit\":1,\"faq.manage\":1}','2026-10-09 05:59:02',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(3,3,1,'lbianchi','Laura','Bianchi','$2a$08$jN/R9kDfxI9qngddC7EnsuUnC.dbm03qk74HYxZqqVCgSWxkUiW8O',NULL,'lbianchi@ospedale.example','(087) 440-9774',NULL,'','',NULL,NULL,NULL,NULL,1,0,1,0,0,0,0,0,0,'none','Letter','{\"def_assn_role\":false}','{\"user.dir\":1}','2026-10-09 05:59:02',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(4,2,3,'gverdi','Giulia','Verdi','$2a$08$zdc6iCU/UYE7lpW8OqK.cu5ftLlzgSnL5BrNlQwhtSvw3Ew.U2GVe',NULL,'gverdi@ospedale.example','(087) 440-9179',NULL,'','',NULL,NULL,NULL,NULL,1,0,1,0,0,0,0,0,0,'none','Letter','{\"def_assn_role\":false}','{\"user.dir\":1}','2026-10-09 05:59:02',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02'),
(5,1,4,'aesposito','Antonio','Esposito','$2a$08$UMY4NDKR1gKPG/OmTwZdRORuSeCzT0VnJ18ZwgqWVVaxMPsh2SCw6',NULL,'aesposito@ospedale.example','(087) 440-9583',NULL,'','',NULL,NULL,NULL,NULL,1,0,1,0,1,0,0,0,0,'none','Letter','{\"def_assn_role\":false}',NULL,'2026-10-09 05:59:02',NULL,'2026-10-09 05:59:02','2026-10-09 05:59:02');
/*!40000 ALTER TABLE `ost_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_staff_dept_access`
--

DROP TABLE IF EXISTS `ost_staff_dept_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_staff_dept_access` (
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`staff_id`,`dept_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_staff_dept_access`
--

LOCK TABLES `ost_staff_dept_access` WRITE;
/*!40000 ALTER TABLE `ost_staff_dept_access` DISABLE KEYS */;
INSERT INTO `ost_staff_dept_access` VALUES
(1,2,1,1),
(1,3,1,1),
(2,3,3,1),
(3,1,2,1);
/*!40000 ALTER TABLE `ost_staff_dept_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_syslog`
--

DROP TABLE IF EXISTS `ost_syslog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_syslog` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` enum('Debug','Warning','Error') NOT NULL,
  `title` varchar(255) NOT NULL,
  `log` text NOT NULL,
  `logger` varchar(64) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_syslog`
--

LOCK TABLES `ost_syslog` WRITE;
/*!40000 ALTER TABLE `ost_syslog` DISABLE KEYS */;
INSERT INTO `ost_syslog` VALUES
(1,'Debug','osTicket installed!','Congratulations osTicket basic installation completed!\n\nThank you for choosing osTicket!','','127.0.0.1','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_syslog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_task`
--

DROP TABLE IF EXISTS `ost_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_task` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL DEFAULT 0,
  `object_type` char(1) NOT NULL,
  `number` varchar(20) DEFAULT NULL,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `lock_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `duedate` datetime DEFAULT NULL,
  `closed` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`),
  KEY `team_id` (`team_id`),
  KEY `created` (`created`),
  KEY `object` (`object_id`,`object_type`),
  KEY `flags` (`flags`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_task`
--

LOCK TABLES `ost_task` WRITE;
/*!40000 ALTER TABLE `ost_task` DISABLE KEYS */;
INSERT INTO `ost_task` VALUES
(1,1,'T','1',1,4,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(2,24,'T','2',1,5,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(3,26,'T','3',1,3,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(4,27,'T','4',3,5,0,0,0,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26','2026-10-09 10:44:26'),
(5,9,'T','5',1,5,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(6,12,'T','6',1,5,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(7,23,'T','7',1,5,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(8,30,'T','8',1,5,0,0,0,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26','2026-10-09 10:44:26'),
(9,46,'T','9',1,3,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(10,53,'T','10',1,5,0,0,1,NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(11,17,'T','11',3,2,0,0,1,NULL,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27'),
(12,21,'T','12',1,2,0,0,0,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27','2026-10-09 10:44:27');
/*!40000 ALTER TABLE `ost_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_task__cdata`
--

DROP TABLE IF EXISTS `ost_task__cdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_task__cdata` (
  `task_id` int(11) unsigned NOT NULL,
  `title` mediumtext DEFAULT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_task__cdata`
--

LOCK TABLES `ost_task__cdata` WRITE;
/*!40000 ALTER TABLE `ost_task__cdata` DISABLE KEYS */;
INSERT INTO `ost_task__cdata` VALUES
(1,'Configurare nuovo account'),
(2,'Contattare fornitore'),
(3,'Aggiornare driver stampante'),
(4,'Aggiornare driver stampante'),
(5,'Sostituire toner'),
(6,'Configurare nuovo account'),
(7,'Contattare fornitore'),
(8,'Sostituire toner'),
(9,'Aggiornare driver stampante'),
(10,'Configurare nuovo account'),
(11,'Configurare nuovo account'),
(12,'Sostituire toner');
/*!40000 ALTER TABLE `ost_task__cdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_team`
--

DROP TABLE IF EXISTS `ost_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_team` (
  `team_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `name` varchar(125) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`team_id`),
  UNIQUE KEY `name` (`name`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_team`
--

LOCK TABLES `ost_team` WRITE;
/*!40000 ALTER TABLE `ost_team` DISABLE KEYS */;
INSERT INTO `ost_team` VALUES
(1,0,1,'Level I Support','Tier 1 support, responsible for the initial iteraction with customers','2026-10-08 06:22:17','2026-10-08 06:22:17');
/*!40000 ALTER TABLE `ost_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_team_member`
--

DROP TABLE IF EXISTS `ost_team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_team_member` (
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`team_id`,`staff_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_team_member`
--

LOCK TABLES `ost_team_member` WRITE;
/*!40000 ALTER TABLE `ost_team_member` DISABLE KEYS */;
INSERT INTO `ost_team_member` VALUES
(1,2,0),
(1,3,0);
/*!40000 ALTER TABLE `ost_team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread`
--

DROP TABLE IF EXISTS `ost_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) unsigned NOT NULL,
  `object_type` char(1) NOT NULL,
  `extra` text DEFAULT NULL,
  `lastresponse` datetime DEFAULT NULL,
  `lastmessage` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `object_type` (`object_type`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread`
--

LOCK TABLES `ost_thread` WRITE;
/*!40000 ALTER TABLE `ost_thread` DISABLE KEYS */;
INSERT INTO `ost_thread` VALUES
(1,1,'T',NULL,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,2,'T',NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14','2026-08-10 22:59:14'),
(3,3,'T',NULL,'2026-09-06 05:59:14','2026-09-06 05:59:14','2026-09-06 03:59:14'),
(4,4,'T',NULL,'2026-09-28 05:59:14','2026-09-28 05:59:14','2026-09-28 00:59:14'),
(5,5,'T',NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14','2026-08-11 04:59:14'),
(6,6,'T',NULL,'2026-10-06 05:59:14','2026-10-06 05:59:14','2026-10-06 00:59:14'),
(7,7,'T',NULL,'2026-07-13 05:59:14','2026-07-13 05:59:14','2026-07-13 04:59:14'),
(8,8,'T',NULL,'2026-09-16 05:59:14','2026-09-16 05:59:14','2026-09-16 05:59:14'),
(9,9,'T',NULL,NULL,'2026-07-29 05:59:14','2026-07-29 05:59:14'),
(10,10,'T',NULL,'2026-08-24 05:59:14','2026-08-24 05:59:14','2026-08-23 21:59:14'),
(11,11,'T',NULL,NULL,'2026-07-29 05:59:14','2026-07-28 23:59:14'),
(12,12,'T',NULL,'2026-09-21 05:59:14','2026-09-21 05:59:14','2026-09-20 23:59:14'),
(13,13,'T',NULL,'2026-07-13 05:59:14','2026-07-13 05:59:14','2026-07-13 04:59:14'),
(14,14,'T',NULL,NULL,'2026-08-10 05:59:14','2026-08-09 20:59:14'),
(15,15,'T',NULL,'2026-07-21 05:59:14','2026-07-21 05:59:14','2026-07-20 23:59:14'),
(16,16,'T',NULL,'2026-07-26 05:59:14','2026-07-26 05:59:14','2026-07-26 00:59:14'),
(17,17,'T',NULL,NULL,'2026-09-11 05:59:14','2026-09-10 22:59:14'),
(18,18,'T',NULL,NULL,'2026-08-27 05:59:14','2026-08-27 02:59:14'),
(19,19,'T',NULL,'2026-09-24 05:59:14','2026-09-24 05:59:14','2026-09-23 22:59:14'),
(20,20,'T',NULL,NULL,'2026-07-27 05:59:14','2026-07-26 22:59:14'),
(21,21,'T',NULL,'2026-07-28 05:59:14','2026-07-28 05:59:14','2026-07-27 23:59:14'),
(22,22,'T',NULL,NULL,'2026-08-06 05:59:14','2026-08-06 00:59:14'),
(23,23,'T',NULL,'2026-10-05 05:59:14','2026-10-05 05:59:14','2026-10-05 03:59:14'),
(24,24,'T',NULL,NULL,'2026-09-24 05:59:14','2026-09-23 21:59:14'),
(25,25,'T',NULL,'2026-07-19 05:59:14','2026-07-19 05:59:15','2026-07-19 05:59:14'),
(26,26,'T',NULL,'2026-10-07 05:59:15','2026-10-07 05:59:15','2026-10-07 05:59:15'),
(27,27,'T',NULL,NULL,'2026-07-20 05:59:15','2026-07-20 02:59:15'),
(28,28,'T',NULL,'2026-09-20 05:59:15','2026-09-20 05:59:15','2026-09-20 00:59:15'),
(29,29,'T',NULL,NULL,'2026-08-31 05:59:15','2026-08-31 05:59:15'),
(30,30,'T',NULL,NULL,'2026-09-11 05:59:15','2026-09-10 21:59:15'),
(31,31,'T',NULL,'2026-10-08 05:59:15','2026-10-08 05:59:15','2026-10-08 05:59:15'),
(32,32,'T',NULL,'2026-09-06 05:59:15','2026-09-06 05:59:15','2026-09-05 23:59:15'),
(33,33,'T',NULL,'2026-07-29 05:59:15','2026-07-29 05:59:15','2026-07-28 23:59:15'),
(34,34,'T',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 01:59:15'),
(35,35,'T',NULL,'2026-10-01 05:59:15','2026-10-01 05:59:15','2026-09-30 20:59:15'),
(36,36,'T',NULL,'2026-09-10 05:59:15','2026-09-10 05:59:15','2026-09-09 20:59:15'),
(37,37,'T',NULL,'2026-08-04 05:59:15','2026-08-04 05:59:15','2026-08-03 22:59:15'),
(38,38,'T',NULL,'2026-07-15 05:59:15','2026-07-15 05:59:15','2026-07-15 02:59:15'),
(39,39,'T',NULL,'2026-08-07 05:59:15','2026-08-07 05:59:15','2026-08-07 01:59:15'),
(40,40,'T',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 03:59:15'),
(41,41,'T',NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15','2026-09-15 23:59:15'),
(42,42,'T',NULL,NULL,'2026-07-19 05:59:15','2026-07-18 23:59:15'),
(43,43,'T',NULL,'2026-10-02 05:59:15','2026-10-02 05:59:15','2026-10-01 23:59:15'),
(44,44,'T',NULL,NULL,'2026-08-02 05:59:15','2026-08-02 01:59:15'),
(45,45,'T',NULL,'2026-07-24 05:59:15','2026-07-24 05:59:15','2026-07-24 03:59:15'),
(46,46,'T',NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15','2026-09-15 21:59:15'),
(47,47,'T',NULL,'2026-08-28 05:59:15','2026-08-28 05:59:15','2026-08-28 04:59:15'),
(48,48,'T',NULL,NULL,'2026-09-26 05:59:15','2026-09-25 20:59:15'),
(49,49,'T',NULL,NULL,'2026-07-18 05:59:15','2026-07-17 21:59:15'),
(50,50,'T',NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15','2026-09-15 22:59:15'),
(51,51,'T',NULL,NULL,'2026-08-27 05:59:15','2026-08-27 00:59:15'),
(52,52,'T',NULL,NULL,'2026-07-23 05:59:15','2026-07-22 23:59:15'),
(53,53,'T',NULL,NULL,'2026-08-08 05:59:15','2026-08-08 05:59:15'),
(54,54,'T',NULL,NULL,'2026-08-26 05:59:16','2026-08-25 22:59:16'),
(55,55,'T',NULL,NULL,'2026-08-09 05:59:16','2026-08-09 00:59:16'),
(56,56,'T',NULL,'2026-07-12 05:59:16','2026-07-12 05:59:16','2026-07-12 03:59:16'),
(57,57,'T',NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16','2026-08-12 05:59:16'),
(58,58,'T',NULL,'2026-07-22 05:59:16','2026-07-22 05:59:16','2026-07-22 02:59:16'),
(59,59,'T',NULL,'2026-07-31 05:59:16','2026-07-31 05:59:16','2026-07-30 22:59:16'),
(60,60,'T',NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16','2026-08-11 22:59:16'),
(61,61,'T',NULL,'2026-09-27 05:59:16','2026-09-27 05:59:16','2026-09-26 23:59:16'),
(62,1,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(63,2,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(64,3,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(65,4,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(66,5,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(67,6,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(68,7,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(69,8,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(70,9,'A',NULL,NULL,NULL,'2026-10-09 10:44:26'),
(71,10,'A',NULL,NULL,NULL,'2026-10-09 10:44:27'),
(72,11,'A',NULL,NULL,NULL,'2026-10-09 10:44:27'),
(73,12,'A',NULL,NULL,NULL,'2026-10-09 10:44:27');
/*!40000 ALTER TABLE `ost_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_collaborator`
--

DROP TABLE IF EXISTS `ost_thread_collaborator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_collaborator` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `role` char(1) NOT NULL DEFAULT 'M',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `collab` (`thread_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_collaborator`
--

LOCK TABLES `ost_thread_collaborator` WRITE;
/*!40000 ALTER TABLE `ost_thread_collaborator` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_thread_collaborator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_entry`
--

DROP TABLE IF EXISTS `ost_thread_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT 0,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` char(1) NOT NULL DEFAULT '',
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `poster` varchar(128) NOT NULL DEFAULT '',
  `editor` int(10) unsigned DEFAULT NULL,
  `editor_type` char(1) DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `body` text NOT NULL,
  `format` varchar(16) NOT NULL DEFAULT 'html',
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  `extra` text DEFAULT NULL,
  `recipients` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `thread_id` (`thread_id`),
  KEY `staff_id` (`staff_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_entry`
--

LOCK TABLES `ost_thread_entry` WRITE;
/*!40000 ALTER TABLE `ost_thread_entry` DISABLE KEYS */;
INSERT INTO `ost_thread_entry` VALUES
(1,0,1,0,1,'M',65,'osTicket Team',NULL,NULL,'Web','osTicket Installed!',' <p>Thank you for choosing osTicket. </p> <p>Please make sure you join the <a href=\"https://forum.osticket.com\">osTicket forums</a> and our <a href=\"https://osticket.com\">mailing list</a> to stay up to date on the latest news, security alerts and updates. The osTicket forums are also a great place to get assistance, guidance, tips, and help from other osTicket users. In addition to the forums, the <a href=\"https://docs.osticket.com\">osTicket Docs</a> provides a useful collection of educational materials, documentation, and notes from the community. We welcome your contributions to the osTicket community. </p> <p>If you are looking for a greater level of support, we provide professional services and commercial support with guaranteed response times, and access to the core development team. We can also help customize osTicket or even add new features to the system to meet your unique needs. </p> <p>If the idea of managing and upgrading this osTicket installation is daunting, you can try osTicket as a hosted service at <a href=\"https://supportsystem.com\">https://supportsystem.com/</a> -- no installation required and we can import your data! With SupportSystem\'s turnkey infrastructure, you get osTicket at its best, leaving you free to focus on your customers without the burden of making sure the application is stable, maintained, and secure. </p> <p>Cheers, </p> <p>-<br /> osTicket Team - https://osticket.com/ </p> <p><strong>PS.</strong> Don\'t just make customers happy, make happy customers! </p>','html','127.0.0.1',NULL,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,0,2,0,4,'M',65,'Sara Colombo',NULL,NULL,'Email','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.9.198',NULL,NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14'),
(3,2,2,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"4\":\"Sara Colombo <s.colombo@ospedale.example>\"}}','2026-08-11 05:59:14','2026-08-11 05:59:14'),
(4,0,2,0,4,'M',64,'Sara Colombo',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14'),
(5,0,3,0,10,'M',65,'Anna Conti',NULL,NULL,'Phone','Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.','html','10.20.3.46',NULL,NULL,'2026-09-06 05:59:14','2026-09-06 05:59:14'),
(6,5,3,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"10\":\"Anna Conti <a.conti@ospedale.example>\"}}','2026-09-06 05:59:14','2026-09-06 05:59:14'),
(7,0,4,0,12,'M',65,'Martina Costa',NULL,NULL,'Email','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.6.195',NULL,NULL,'2026-09-28 05:59:14','2026-09-28 05:59:14'),
(8,7,4,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"12\":\"Martina Costa <m.costa@ospedale.example>\"}}','2026-09-28 05:59:14','2026-09-28 05:59:14'),
(9,0,4,0,12,'M',64,'Martina Costa',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-09-28 05:59:14','2026-09-28 05:59:14'),
(10,0,5,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Web','Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.','html','10.20.4.117',NULL,NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14'),
(11,10,5,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"8\":\"Chiara Bruno <c.bruno@ospedale.example>\"}}','2026-08-11 05:59:14','2026-08-11 05:59:14'),
(12,0,5,0,8,'M',64,'Chiara Bruno',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14'),
(13,0,5,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-08-11 05:59:14','2026-08-11 05:59:14'),
(14,0,6,0,7,'M',65,'Davide Greco',NULL,NULL,'Phone','Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.','html','10.20.9.105',NULL,NULL,'2026-10-06 05:59:14','2026-10-06 05:59:14'),
(15,14,6,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?','html','10.20.0.15',NULL,'{\"to\":{\"7\":\"Davide Greco <d.greco@ospedale.example>\"}}','2026-10-06 05:59:14','2026-10-06 05:59:14'),
(16,0,6,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-10-06 05:59:14','2026-10-06 05:59:14'),
(17,0,7,0,9,'M',65,'Marco Gallo',NULL,NULL,'Web','Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".','html','10.20.7.200',NULL,NULL,'2026-07-13 05:59:14','2026-07-13 05:59:14'),
(18,17,7,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?','html','10.20.0.15',NULL,'{\"to\":{\"9\":\"Marco Gallo <m.gallo@ospedale.example>\"}}','2026-07-13 05:59:14','2026-07-13 05:59:14'),
(19,0,7,0,9,'M',64,'Marco Gallo',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-07-13 05:59:14','2026-07-13 05:59:14'),
(20,0,8,0,9,'M',65,'Marco Gallo',NULL,NULL,'API','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.2.9',NULL,NULL,'2026-09-16 05:59:14','2026-09-16 05:59:14'),
(21,20,8,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"9\":\"Marco Gallo <m.gallo@ospedale.example>\"}}','2026-09-16 05:59:14','2026-09-16 05:59:14'),
(22,0,9,0,3,'M',65,'Luca Ferrari',NULL,NULL,'Email','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.6.223',NULL,NULL,'2026-07-29 05:59:14','2026-07-29 05:59:14'),
(23,0,10,0,10,'M',65,'Anna Conti',NULL,NULL,'Email','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.2.26',NULL,NULL,'2026-08-24 05:59:14','2026-08-24 05:59:14'),
(24,23,10,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"10\":\"Anna Conti <a.conti@ospedale.example>\"}}','2026-08-24 05:59:14','2026-08-24 05:59:14'),
(25,0,10,0,10,'M',64,'Anna Conti',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-08-24 05:59:14','2026-08-24 05:59:14'),
(26,0,11,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Phone','Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".','html','10.20.2.136',NULL,NULL,'2026-07-29 05:59:14','2026-07-29 05:59:14'),
(27,0,12,0,3,'M',65,'Luca Ferrari',NULL,NULL,'Web','Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.','html','10.20.6.74',NULL,NULL,'2026-09-21 05:59:14','2026-09-21 05:59:14'),
(28,27,12,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"3\":\"Luca Ferrari <l.ferrari@ospedale.example>\"}}','2026-09-21 05:59:14','2026-09-21 05:59:14'),
(29,0,12,0,3,'M',64,'Luca Ferrari',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-09-21 05:59:14','2026-09-21 05:59:14'),
(30,0,13,0,13,'M',65,'Stefano Giordano',NULL,NULL,'Web','Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.','html','10.20.4.200',NULL,NULL,'2026-07-13 05:59:14','2026-07-13 05:59:14'),
(31,30,13,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"13\":\"Stefano Giordano <s.giordano@ospedale.example>\"}}','2026-07-13 05:59:14','2026-07-13 05:59:14'),
(32,0,14,0,10,'M',65,'Anna Conti',NULL,NULL,'Phone','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.1.55',NULL,NULL,'2026-08-10 05:59:14','2026-08-10 05:59:14'),
(33,0,15,0,10,'M',65,'Anna Conti',NULL,NULL,'Web','Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.','html','10.20.6.30',NULL,NULL,'2026-07-21 05:59:14','2026-07-21 05:59:14'),
(34,33,15,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"10\":\"Anna Conti <a.conti@ospedale.example>\"}}','2026-07-21 05:59:14','2026-07-21 05:59:14'),
(35,0,15,0,10,'M',64,'Anna Conti',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-07-21 05:59:14','2026-07-21 05:59:14'),
(36,0,15,5,0,'N',64,'Antonio Esposito',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-07-21 05:59:14','2026-07-21 05:59:14'),
(37,0,16,0,12,'M',65,'Martina Costa',NULL,NULL,'Web','Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".','html','10.20.2.239',NULL,NULL,'2026-07-26 05:59:14','2026-07-26 05:59:14'),
(38,37,16,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"12\":\"Martina Costa <m.costa@ospedale.example>\"}}','2026-07-26 05:59:14','2026-07-26 05:59:14'),
(39,0,16,0,12,'M',64,'Martina Costa',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-07-26 05:59:14','2026-07-26 05:59:14'),
(40,0,16,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-07-26 05:59:14','2026-07-26 05:59:14'),
(41,0,17,0,4,'M',65,'Sara Colombo',NULL,NULL,'Email','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.8.165',NULL,NULL,'2026-09-11 05:59:14','2026-09-11 05:59:14'),
(42,0,17,5,0,'N',64,'Antonio Esposito',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-09-11 05:59:14','2026-09-11 05:59:14'),
(43,0,18,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Web','Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.','html','10.20.6.237',NULL,NULL,'2026-08-27 05:59:14','2026-08-27 05:59:14'),
(44,0,19,0,11,'M',65,'Giorgio De Luca',NULL,NULL,'API','Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.','html','10.20.3.3',NULL,NULL,'2026-09-24 05:59:14','2026-09-24 05:59:14'),
(45,44,19,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"11\":\"Giorgio De Luca <g.deluca@ospedale.example>\"}}','2026-09-24 05:59:14','2026-09-24 05:59:14'),
(46,0,19,0,11,'M',64,'Giorgio De Luca',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-09-24 05:59:14','2026-09-24 05:59:14'),
(47,0,20,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Web','Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.','html','10.20.1.35',NULL,NULL,'2026-07-27 05:59:14','2026-07-27 05:59:14'),
(48,0,20,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-07-27 05:59:14','2026-07-27 05:59:14'),
(49,0,21,0,4,'M',65,'Sara Colombo',NULL,NULL,'API','Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.','html','10.20.5.208',NULL,NULL,'2026-07-28 05:59:14','2026-07-28 05:59:14'),
(50,49,21,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"4\":\"Sara Colombo <s.colombo@ospedale.example>\"}}','2026-07-28 05:59:14','2026-07-28 05:59:14'),
(51,0,22,0,10,'M',65,'Anna Conti',NULL,NULL,'Web','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.5.160',NULL,NULL,'2026-08-06 05:59:14','2026-08-06 05:59:14'),
(52,0,23,0,3,'M',65,'Luca Ferrari',NULL,NULL,'Email','Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".','html','10.20.5.73',NULL,NULL,'2026-10-05 05:59:14','2026-10-05 05:59:14'),
(53,52,23,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"3\":\"Luca Ferrari <l.ferrari@ospedale.example>\"}}','2026-10-05 05:59:14','2026-10-05 05:59:14'),
(54,0,23,0,3,'M',64,'Luca Ferrari',NULL,NULL,'',NULL,'Ecco il numero di inventario: INV-2026-0451.','html','10.20.0.15',NULL,NULL,'2026-10-05 05:59:14','2026-10-05 05:59:14'),
(55,0,24,0,2,'M',65,'Francesca Romano',NULL,NULL,'Web','Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.','html','10.20.2.173',NULL,NULL,'2026-09-24 05:59:14','2026-09-24 05:59:14'),
(56,0,25,0,12,'M',65,'Martina Costa',NULL,NULL,'Phone','Referti LIS non arrivano in cartella','Da ieri i referti di laboratorio non compaiono nella cartella clinica elettronica.','html','10.20.2.117',NULL,NULL,'2026-07-19 05:59:14','2026-07-19 05:59:14'),
(57,56,25,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"12\":\"Martina Costa <m.costa@ospedale.example>\"}}','2026-07-19 05:59:14','2026-07-19 05:59:14'),
(58,0,25,0,12,'M',64,'Martina Costa',NULL,NULL,'',NULL,'Ecco il numero di inventario: INV-2026-0451.','html','10.20.0.15',NULL,NULL,'2026-07-19 05:59:14','2026-07-19 05:59:14'),
(59,0,25,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-07-19 05:59:15','2026-07-19 05:59:15'),
(60,0,26,0,2,'M',65,'Francesca Romano',NULL,NULL,'Phone','Telefono IP senza linea','Il telefono IP della guardiola non ha linea, il display è spento.','html','10.20.8.142',NULL,NULL,'2026-10-07 05:59:15','2026-10-07 05:59:15'),
(61,60,26,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"2\":\"Francesca Romano <f.romano@ospedale.example>\"}}','2026-10-07 05:59:15','2026-10-07 05:59:15'),
(62,0,26,0,2,'M',64,'Francesca Romano',NULL,NULL,'',NULL,'Ecco il numero di inventario: INV-2026-0451.','html','10.20.0.15',NULL,NULL,'2026-10-07 05:59:15','2026-10-07 05:59:15'),
(63,0,27,0,2,'M',65,'Francesca Romano',NULL,NULL,'API','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.1.79',NULL,NULL,'2026-07-20 05:59:15','2026-07-20 05:59:15'),
(64,0,27,5,0,'N',64,'Antonio Esposito',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-07-20 05:59:15','2026-07-20 05:59:15'),
(65,0,28,0,13,'M',65,'Stefano Giordano',NULL,NULL,'Phone','Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.','html','10.20.4.102',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 05:59:15'),
(66,65,28,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"13\":\"Stefano Giordano <s.giordano@ospedale.example>\"}}','2026-09-20 05:59:15','2026-09-20 05:59:15'),
(67,0,29,0,11,'M',65,'Giorgio De Luca',NULL,NULL,'Phone','Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".','html','10.20.2.64',NULL,NULL,'2026-08-31 05:59:15','2026-08-31 05:59:15'),
(68,0,30,0,3,'M',65,'Luca Ferrari',NULL,NULL,'Web','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.3.65',NULL,NULL,'2026-09-11 05:59:15','2026-09-11 05:59:15'),
(69,0,30,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-09-11 05:59:15','2026-09-11 05:59:15'),
(70,0,31,0,12,'M',65,'Martina Costa',NULL,NULL,'Email','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.8.215',NULL,NULL,'2026-10-08 05:59:15','2026-10-08 05:59:15'),
(71,70,31,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"12\":\"Martina Costa <m.costa@ospedale.example>\"}}','2026-10-08 05:59:15','2026-10-08 05:59:15'),
(72,0,31,0,12,'M',64,'Martina Costa',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-10-08 05:59:15','2026-10-08 05:59:15'),
(73,0,32,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Phone','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.6.170',NULL,NULL,'2026-09-06 05:59:15','2026-09-06 05:59:15'),
(74,73,32,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-09-06 05:59:15','2026-09-06 05:59:15'),
(75,0,32,0,5,'M',64,'Paolo Ricci',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-09-06 05:59:15','2026-09-06 05:59:15'),
(76,0,33,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Web','Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.','html','10.20.4.166',NULL,NULL,'2026-07-29 05:59:15','2026-07-29 05:59:15'),
(77,76,33,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-07-29 05:59:15','2026-07-29 05:59:15'),
(78,0,33,0,5,'M',64,'Paolo Ricci',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-07-29 05:59:15','2026-07-29 05:59:15'),
(79,0,33,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-07-29 05:59:15','2026-07-29 05:59:15'),
(80,0,34,0,10,'M',65,'Anna Conti',NULL,NULL,'Phone','Casella email piena','La casella condivisa del reparto ha raggiunto il limite e non riceve più messaggi.','html','10.20.1.136',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 05:59:15'),
(81,0,34,5,0,'N',64,'Antonio Esposito',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 05:59:15'),
(82,0,35,0,7,'M',65,'Davide Greco',NULL,NULL,'Email','Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.','html','10.20.3.103',NULL,NULL,'2026-10-01 05:59:15','2026-10-01 05:59:15'),
(83,82,35,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"7\":\"Davide Greco <d.greco@ospedale.example>\"}}','2026-10-01 05:59:15','2026-10-01 05:59:15'),
(84,0,35,0,7,'M',64,'Davide Greco',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-10-01 05:59:15','2026-10-01 05:59:15'),
(85,0,35,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-10-01 05:59:15','2026-10-01 05:59:15'),
(86,0,36,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Email','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.7.146',NULL,NULL,'2026-09-10 05:59:15','2026-09-10 05:59:15'),
(87,86,36,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-09-10 05:59:15','2026-09-10 05:59:15'),
(88,0,36,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-09-10 05:59:15','2026-09-10 05:59:15'),
(89,0,37,0,10,'M',65,'Anna Conti',NULL,NULL,'Phone','Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.','html','10.20.4.122',NULL,NULL,'2026-08-04 05:59:15','2026-08-04 05:59:15'),
(90,89,37,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"10\":\"Anna Conti <a.conti@ospedale.example>\"}}','2026-08-04 05:59:15','2026-08-04 05:59:15'),
(91,0,37,0,10,'M',64,'Anna Conti',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-08-04 05:59:15','2026-08-04 05:59:15'),
(92,0,38,0,12,'M',65,'Martina Costa',NULL,NULL,'API','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.1.95',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 05:59:15'),
(93,92,38,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"12\":\"Martina Costa <m.costa@ospedale.example>\"}}','2026-07-15 05:59:15','2026-07-15 05:59:15'),
(94,0,38,5,0,'N',64,'Antonio Esposito',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 05:59:15'),
(95,0,39,0,6,'M',65,'Elena Marino',NULL,NULL,'Phone','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.3.233',NULL,NULL,'2026-08-07 05:59:15','2026-08-07 05:59:15'),
(96,95,39,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?','html','10.20.0.15',NULL,'{\"to\":{\"6\":\"Elena Marino <e.marino@ospedale.example>\"}}','2026-08-07 05:59:15','2026-08-07 05:59:15'),
(97,0,40,0,7,'M',65,'Davide Greco',NULL,NULL,'API','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.4.60',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 05:59:15'),
(98,0,40,4,0,'N',64,'Giulia Verdi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 05:59:15'),
(99,0,41,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Web','Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".','html','10.20.9.9',NULL,NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15'),
(100,99,41,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-09-16 05:59:15','2026-09-16 05:59:15'),
(101,0,41,0,5,'M',64,'Paolo Ricci',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15'),
(102,0,42,0,11,'M',65,'Giorgio De Luca',NULL,NULL,'Web','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.6.22',NULL,NULL,'2026-07-19 05:59:15','2026-07-19 05:59:15'),
(103,0,42,4,0,'N',64,'Giulia Verdi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-07-19 05:59:15','2026-07-19 05:59:15'),
(104,0,43,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Email','Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.','html','10.20.9.149',NULL,NULL,'2026-10-02 05:59:15','2026-10-02 05:59:15'),
(105,104,43,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-10-02 05:59:15','2026-10-02 05:59:15'),
(106,0,43,0,5,'M',64,'Paolo Ricci',NULL,NULL,'',NULL,'Ecco il numero di inventario: INV-2026-0451.','html','10.20.0.15',NULL,NULL,'2026-10-02 05:59:15','2026-10-02 05:59:15'),
(107,0,43,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-10-02 05:59:15','2026-10-02 05:59:15'),
(108,0,44,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Web','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.1.208',NULL,NULL,'2026-08-02 05:59:15','2026-08-02 05:59:15'),
(109,0,45,0,9,'M',65,'Marco Gallo',NULL,NULL,'Phone','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.8.205',NULL,NULL,'2026-07-24 05:59:15','2026-07-24 05:59:15'),
(110,109,45,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"9\":\"Marco Gallo <m.gallo@ospedale.example>\"}}','2026-07-24 05:59:15','2026-07-24 05:59:15'),
(111,0,45,4,0,'N',64,'Giulia Verdi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-07-24 05:59:15','2026-07-24 05:59:15'),
(112,0,46,0,3,'M',65,'Luca Ferrari',NULL,NULL,'Email','Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.','html','10.20.4.77',NULL,NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15'),
(113,112,46,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"3\":\"Luca Ferrari <l.ferrari@ospedale.example>\"}}','2026-09-16 05:59:15','2026-09-16 05:59:15'),
(114,0,47,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Email','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.5.29',NULL,NULL,'2026-08-28 05:59:15','2026-08-28 05:59:15'),
(115,114,47,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-08-28 05:59:15','2026-08-28 05:59:15'),
(116,0,47,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-08-28 05:59:15','2026-08-28 05:59:15'),
(117,0,48,0,4,'M',65,'Sara Colombo',NULL,NULL,'API','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.8.84',NULL,NULL,'2026-09-26 05:59:15','2026-09-26 05:59:15'),
(118,0,49,0,8,'M',65,'Chiara Bruno',NULL,NULL,'API','Wi-Fi assente in sala riunioni','In sala riunioni del terzo piano il Wi-Fi ospiti non è disponibile.','html','10.20.4.32',NULL,NULL,'2026-07-18 05:59:15','2026-07-18 05:59:15'),
(119,0,49,4,0,'N',64,'Giulia Verdi',NULL,NULL,'','Nota tecnica','In attesa del fornitore per la sostituzione.','html','10.20.0.15',NULL,NULL,'2026-07-18 05:59:15','2026-07-18 05:59:15'),
(120,0,50,0,7,'M',65,'Davide Greco',NULL,NULL,'Web','Stampante del reparto non stampa','La stampante di rete al secondo piano non stampa da stamattina. Il display segnala \"errore 49\".','html','10.20.4.239',NULL,NULL,'2026-09-16 05:59:15','2026-09-16 05:59:15'),
(121,120,50,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"7\":\"Davide Greco <d.greco@ospedale.example>\"}}','2026-09-16 05:59:15','2026-09-16 05:59:15'),
(122,0,51,0,8,'M',65,'Chiara Bruno',NULL,NULL,'Phone','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.9.202',NULL,NULL,'2026-08-27 05:59:15','2026-08-27 05:59:15'),
(123,0,51,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Verificato da remoto: servizio di spooling bloccato.','html','10.20.0.15',NULL,NULL,'2026-08-27 05:59:15','2026-08-27 05:59:15'),
(124,0,52,0,12,'M',65,'Martina Costa',NULL,NULL,'API','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.6.89',NULL,NULL,'2026-07-23 05:59:15','2026-07-23 05:59:15'),
(125,0,53,0,3,'M',65,'Luca Ferrari',NULL,NULL,'API','Richiesta installazione software DICOM viewer','Avremmo bisogno del viewer DICOM sul PC della sala refertazione.','html','10.20.4.219',NULL,NULL,'2026-08-08 05:59:15','2026-08-08 05:59:15'),
(126,0,53,2,0,'N',64,'Mario Rossi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-08-08 05:59:16','2026-08-08 05:59:16'),
(127,0,54,0,7,'M',65,'Davide Greco',NULL,NULL,'Web','Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.','html','10.20.3.93',NULL,NULL,'2026-08-26 05:59:16','2026-08-26 05:59:16'),
(128,0,55,0,7,'M',65,'Davide Greco',NULL,NULL,'API','Monitor guasto postazione triage','Il monitor della postazione triage sfarfalla e a tratti si spegne.','html','10.20.1.106',NULL,NULL,'2026-08-09 05:59:16','2026-08-09 05:59:16'),
(129,0,56,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Phone','Badge non abilitato al varco','Il badge di un nuovo infermiere non apre il varco del blocco operatorio.','html','10.20.7.176',NULL,NULL,'2026-07-12 05:59:16','2026-07-12 05:59:16'),
(130,129,56,2,0,'R',576,'Mario Rossi',NULL,NULL,'',NULL,'Il problema è stato risolto. Chiudiamo la segnalazione, ma ci scriva se si ripresenta.','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-07-12 05:59:16','2026-07-12 05:59:16'),
(131,0,57,0,13,'M',65,'Stefano Giordano',NULL,NULL,'Phone','Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".','html','10.20.2.104',NULL,NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16'),
(132,131,57,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"13\":\"Stefano Giordano <s.giordano@ospedale.example>\"}}','2026-08-12 05:59:16','2026-08-12 05:59:16'),
(133,0,57,0,13,'M',64,'Stefano Giordano',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16'),
(134,0,58,0,6,'M',65,'Elena Marino',NULL,NULL,'API','PC lentissimo in ambulatorio 3','Il PC dell\'ambulatorio 3 impiega diversi minuti ad aprire il gestionale.','html','10.20.1.108',NULL,NULL,'2026-07-22 05:59:16','2026-07-22 05:59:16'),
(135,134,58,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"6\":\"Elena Marino <e.marino@ospedale.example>\"}}','2026-07-22 05:59:16','2026-07-22 05:59:16'),
(136,0,58,0,6,'M',64,'Elena Marino',NULL,NULL,'',NULL,'Il problema si ripresenta dopo pranzo.','html','10.20.0.15',NULL,NULL,'2026-07-22 05:59:16','2026-07-22 05:59:16'),
(137,0,59,0,5,'M',65,'Paolo Ricci',NULL,NULL,'Web','Accesso al FSE non funziona','Non riesco ad accedere al Fascicolo Sanitario Elettronico: ricevo \"credenziali non valide\".','html','10.20.1.142',NULL,NULL,'2026-07-31 05:59:16','2026-07-31 05:59:16'),
(138,137,59,3,0,'R',576,'Laura Bianchi',NULL,NULL,'',NULL,'Abbiamo riavviato il servizio: può verificare se ora funziona correttamente?','html','10.20.0.15',NULL,'{\"to\":{\"5\":\"Paolo Ricci <p.ricci@ospedale.example>\"}}','2026-07-31 05:59:16','2026-07-31 05:59:16'),
(139,0,59,0,5,'M',64,'Paolo Ricci',NULL,NULL,'',NULL,'Grazie, ora funziona.','html','10.20.0.15',NULL,NULL,'2026-07-31 05:59:16','2026-07-31 05:59:16'),
(140,0,59,3,0,'N',64,'Laura Bianchi',NULL,NULL,'','Nota tecnica','Possibile problema di rete sullo switch di piano.','html','10.20.0.15',NULL,NULL,'2026-07-31 05:59:16','2026-07-31 05:59:16'),
(141,0,60,0,9,'M',65,'Marco Gallo',NULL,NULL,'Phone','Richiesta nuovo account per specializzando','Serve un account di dominio e l\'accesso al RIS per il nuovo specializzando che inizia lunedì.','html','10.20.6.23',NULL,NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16'),
(142,141,60,4,0,'R',576,'Giulia Verdi',NULL,NULL,'',NULL,'Buongiorno, abbiamo preso in carico la richiesta. Un tecnico passerà in mattinata.','html','10.20.0.15',NULL,'{\"to\":{\"9\":\"Marco Gallo <m.gallo@ospedale.example>\"}}','2026-08-12 05:59:16','2026-08-12 05:59:16'),
(143,0,61,0,10,'M',65,'Anna Conti',NULL,NULL,'Email','Errore invio ordine al magazzino','Il gestionale magazzino restituisce un errore all\'invio degli ordini.','html','10.20.7.199',NULL,NULL,'2026-09-27 05:59:16','2026-09-27 05:59:16'),
(144,143,61,5,0,'R',576,'Antonio Esposito',NULL,NULL,'',NULL,'Ci serve il numero di inventario del dispositivo per procedere.','html','10.20.0.15',NULL,'{\"to\":{\"10\":\"Anna Conti <a.conti@ospedale.example>\"}}','2026-09-27 05:59:16','2026-09-27 05:59:16'),
(145,0,62,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #247301','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(146,0,63,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #915323','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(147,0,64,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #581759','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(148,0,65,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #853680','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(149,0,27,1,0,'N',64,'Admin Dev',NULL,NULL,'','Task 4 Closed','Task closed','html','10.20.0.15',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(150,0,66,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #896022','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(151,0,67,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #753017','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(152,0,68,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #647566','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(153,0,69,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #973732','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(154,0,30,1,0,'N',64,'Admin Dev',NULL,NULL,'','Task 8 Closed','Task closed','html','10.20.0.15',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(155,0,70,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #305907','html','',NULL,NULL,'2026-10-09 10:44:26','2026-10-09 10:44:26'),
(156,0,71,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #762918','html','',NULL,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27'),
(157,0,72,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #241142','html','',NULL,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27'),
(158,0,73,0,0,'M',193,'',NULL,NULL,'',NULL,'Attività collegata al ticket #930834','html','',NULL,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27'),
(159,0,21,1,0,'N',64,'Admin Dev',NULL,NULL,'','Task 12 Closed','Task closed','html','10.20.0.15',NULL,NULL,'2026-10-09 10:44:27','2026-10-09 10:44:27');
/*!40000 ALTER TABLE `ost_thread_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_entry_email`
--

DROP TABLE IF EXISTS `ost_thread_entry_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_entry_email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `thread_entry_id` int(11) unsigned NOT NULL,
  `email_id` int(11) unsigned DEFAULT NULL,
  `mid` varchar(255) NOT NULL,
  `headers` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thread_entry_id` (`thread_entry_id`),
  KEY `mid` (`mid`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_entry_email`
--

LOCK TABLES `ost_thread_entry_email` WRITE;
/*!40000 ALTER TABLE `ost_thread_entry_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_thread_entry_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_entry_merge`
--

DROP TABLE IF EXISTS `ost_thread_entry_merge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_entry_merge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `thread_entry_id` int(11) unsigned NOT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thread_entry_id` (`thread_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_entry_merge`
--

LOCK TABLES `ost_thread_entry_merge` WRITE;
/*!40000 ALTER TABLE `ost_thread_entry_merge` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_thread_entry_merge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_event`
--

DROP TABLE IF EXISTS `ost_thread_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `thread_type` char(1) NOT NULL DEFAULT '',
  `event_id` int(11) unsigned DEFAULT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `team_id` int(11) unsigned NOT NULL,
  `dept_id` int(11) unsigned NOT NULL,
  `topic_id` int(11) unsigned NOT NULL,
  `data` varchar(1024) DEFAULT NULL COMMENT 'Encoded differences',
  `username` varchar(128) NOT NULL DEFAULT 'SYSTEM',
  `uid` int(11) unsigned DEFAULT NULL,
  `uid_type` char(1) NOT NULL DEFAULT 'S',
  `annulled` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_state` (`thread_id`,`event_id`,`timestamp`),
  KEY `ticket_stats` (`timestamp`,`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_event`
--

LOCK TABLES `ost_thread_event` WRITE;
/*!40000 ALTER TABLE `ost_thread_event` DISABLE KEYS */;
INSERT INTO `ost_thread_event` VALUES
(1,1,'T',1,0,0,1,1,NULL,'SYSTEM',1,'U',0,'2026-10-08 06:22:17'),
(2,2,'T',1,0,0,1,11,NULL,'SYSTEM',4,'U',0,'2026-08-11 05:59:14'),
(3,2,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-11 05:59:14'),
(4,2,'T',2,2,0,1,11,'{\"status\":[3,\"Closed\"]}','mrossi',2,'S',0,'2026-08-11 05:59:14'),
(5,3,'T',1,0,0,1,11,NULL,'SYSTEM',10,'U',0,'2026-09-06 05:59:14'),
(6,3,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-06 05:59:14'),
(7,4,'T',1,0,0,3,10,NULL,'SYSTEM',12,'U',0,'2026-09-28 05:59:14'),
(8,4,'T',4,3,0,3,10,'{\"claim\":true}','lbianchi',3,'S',0,'2026-09-28 05:59:14'),
(9,4,'T',8,3,0,3,10,NULL,'lbianchi',3,'S',0,'2026-09-28 05:59:14'),
(10,5,'T',1,0,0,1,2,NULL,'SYSTEM',8,'U',0,'2026-08-11 05:59:14'),
(11,5,'T',4,2,0,1,2,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-11 05:59:14'),
(12,5,'T',2,2,0,1,2,'{\"status\":[3,\"Closed\"]}','mrossi',2,'S',0,'2026-08-11 05:59:14'),
(13,6,'T',1,0,0,1,11,NULL,'SYSTEM',7,'U',0,'2026-10-06 05:59:14'),
(14,6,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-10-06 05:59:14'),
(15,7,'T',1,0,0,3,10,NULL,'SYSTEM',9,'U',0,'2026-07-13 05:59:14'),
(16,7,'T',4,5,0,3,10,'{\"claim\":true}','aesposito',5,'S',0,'2026-07-13 05:59:14'),
(17,8,'T',1,0,0,3,10,NULL,'SYSTEM',9,'U',0,'2026-09-16 05:59:14'),
(18,8,'T',4,5,0,3,10,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-16 05:59:14'),
(19,9,'T',1,0,0,1,2,NULL,'SYSTEM',3,'U',0,'2026-07-29 05:59:14'),
(20,10,'T',1,0,0,3,10,NULL,'SYSTEM',10,'U',0,'2026-08-24 05:59:14'),
(21,10,'T',4,5,0,3,10,'{\"claim\":true}','aesposito',5,'S',0,'2026-08-24 05:59:14'),
(22,11,'T',1,0,0,1,1,NULL,'SYSTEM',8,'U',0,'2026-07-29 05:59:14'),
(23,11,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-29 05:59:14'),
(24,12,'T',1,0,0,1,2,NULL,'SYSTEM',3,'U',0,'2026-09-21 05:59:14'),
(25,12,'T',4,5,0,1,2,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-21 05:59:14'),
(26,13,'T',1,0,0,1,1,NULL,'SYSTEM',13,'U',0,'2026-07-13 05:59:14'),
(27,13,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-13 05:59:14'),
(28,14,'T',1,0,0,1,11,NULL,'SYSTEM',10,'U',0,'2026-08-10 05:59:14'),
(29,14,'T',4,5,0,1,11,'{\"claim\":true}','aesposito',5,'S',0,'2026-08-10 05:59:14'),
(30,15,'T',1,0,0,1,2,NULL,'SYSTEM',10,'U',0,'2026-07-21 05:59:14'),
(31,15,'T',4,5,0,1,2,'{\"claim\":true}','aesposito',5,'S',0,'2026-07-21 05:59:14'),
(32,16,'T',1,0,0,1,11,NULL,'SYSTEM',12,'U',0,'2026-07-26 05:59:14'),
(33,16,'T',4,3,0,1,11,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-26 05:59:14'),
(34,16,'T',2,3,0,1,11,'{\"status\":[3,\"Closed\"]}','lbianchi',3,'S',0,'2026-07-26 05:59:14'),
(35,17,'T',1,0,0,3,10,NULL,'SYSTEM',4,'U',0,'2026-09-11 05:59:14'),
(36,17,'T',4,5,1,3,10,'{\"team\":1}','aesposito',5,'S',0,'2026-09-11 05:59:14'),
(37,18,'T',1,0,0,1,2,NULL,'SYSTEM',8,'U',0,'2026-08-27 05:59:14'),
(38,19,'T',1,0,0,3,10,NULL,'SYSTEM',11,'U',0,'2026-09-24 05:59:14'),
(39,19,'T',4,5,0,3,10,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-24 05:59:14'),
(40,20,'T',1,0,0,1,11,NULL,'SYSTEM',8,'U',0,'2026-07-27 05:59:14'),
(41,20,'T',4,3,0,1,11,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-27 05:59:14'),
(42,21,'T',1,0,0,1,1,NULL,'SYSTEM',4,'U',0,'2026-07-28 05:59:14'),
(43,21,'T',4,2,0,1,1,'{\"claim\":true}','mrossi',2,'S',0,'2026-07-28 05:59:14'),
(44,22,'T',1,0,0,3,10,NULL,'SYSTEM',10,'U',0,'2026-08-06 05:59:14'),
(45,22,'T',4,4,0,3,10,'{\"claim\":true}','gverdi',4,'S',0,'2026-08-06 05:59:14'),
(46,23,'T',1,0,0,1,11,NULL,'SYSTEM',3,'U',0,'2026-10-05 05:59:14'),
(47,23,'T',4,5,0,1,11,'{\"claim\":true}','aesposito',5,'S',0,'2026-10-05 05:59:14'),
(48,24,'T',1,0,0,1,2,NULL,'SYSTEM',2,'U',0,'2026-09-24 05:59:14'),
(49,24,'T',4,5,0,1,2,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-24 05:59:14'),
(50,25,'T',1,0,0,3,10,NULL,'SYSTEM',12,'U',0,'2026-07-19 05:59:14'),
(51,25,'T',4,3,0,3,10,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-19 05:59:14'),
(52,25,'T',8,3,0,3,10,NULL,'lbianchi',3,'S',0,'2026-07-19 05:59:15'),
(53,26,'T',1,0,0,1,2,NULL,'SYSTEM',2,'U',0,'2026-10-07 05:59:15'),
(54,26,'T',4,4,0,1,2,'{\"claim\":true}','gverdi',4,'S',0,'2026-10-07 05:59:15'),
(55,27,'T',1,0,0,3,10,NULL,'SYSTEM',2,'U',0,'2026-07-20 05:59:15'),
(56,27,'T',4,5,0,3,10,'{\"claim\":true}','aesposito',5,'S',0,'2026-07-20 05:59:15'),
(57,28,'T',1,0,0,1,1,NULL,'SYSTEM',13,'U',0,'2026-09-20 05:59:15'),
(58,28,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-09-20 05:59:15'),
(59,29,'T',1,0,0,1,2,NULL,'SYSTEM',11,'U',0,'2026-08-31 05:59:15'),
(60,29,'T',4,5,0,1,2,'{\"claim\":true}','aesposito',5,'S',0,'2026-08-31 05:59:15'),
(61,30,'T',1,0,0,1,2,NULL,'SYSTEM',3,'U',0,'2026-09-11 05:59:15'),
(62,31,'T',1,0,0,1,11,NULL,'SYSTEM',12,'U',0,'2026-10-08 05:59:15'),
(63,31,'T',4,5,0,1,11,'{\"claim\":true}','aesposito',5,'S',0,'2026-10-08 05:59:15'),
(64,32,'T',1,0,0,1,2,NULL,'SYSTEM',5,'U',0,'2026-09-06 05:59:15'),
(65,32,'T',4,4,0,1,2,'{\"claim\":true}','gverdi',4,'S',0,'2026-09-06 05:59:15'),
(66,33,'T',1,0,0,1,1,NULL,'SYSTEM',5,'U',0,'2026-07-29 05:59:15'),
(67,33,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-29 05:59:15'),
(68,33,'T',2,3,0,1,1,'{\"status\":[3,\"Closed\"]}','lbianchi',3,'S',0,'2026-07-29 05:59:15'),
(69,34,'T',1,0,0,1,11,NULL,'SYSTEM',10,'U',0,'2026-09-20 05:59:15'),
(70,34,'T',4,5,0,1,11,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-20 05:59:15'),
(71,35,'T',1,0,0,1,1,NULL,'SYSTEM',7,'U',0,'2026-10-01 05:59:15'),
(72,35,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-10-01 05:59:15'),
(73,35,'T',8,3,0,1,1,NULL,'lbianchi',3,'S',0,'2026-10-01 05:59:15'),
(74,36,'T',1,0,0,1,11,NULL,'SYSTEM',5,'U',0,'2026-09-10 05:59:15'),
(75,36,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-10 05:59:15'),
(76,37,'T',1,0,0,1,11,NULL,'SYSTEM',10,'U',0,'2026-08-04 05:59:15'),
(77,37,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-04 05:59:15'),
(78,37,'T',2,2,0,1,11,'{\"status\":[3,\"Closed\"]}','mrossi',2,'S',0,'2026-08-04 05:59:15'),
(79,38,'T',1,0,0,1,11,NULL,'SYSTEM',12,'U',0,'2026-07-15 05:59:15'),
(80,38,'T',4,5,0,1,11,'{\"claim\":true}','aesposito',5,'S',0,'2026-07-15 05:59:15'),
(81,39,'T',1,0,0,3,10,NULL,'SYSTEM',6,'U',0,'2026-08-07 05:59:15'),
(82,39,'T',4,2,0,3,10,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-07 05:59:15'),
(83,40,'T',1,0,0,1,11,NULL,'SYSTEM',7,'U',0,'2026-07-15 05:59:15'),
(84,41,'T',1,0,0,1,11,NULL,'SYSTEM',5,'U',0,'2026-09-16 05:59:15'),
(85,41,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-16 05:59:15'),
(86,41,'T',2,2,0,1,11,'{\"status\":[3,\"Closed\"]}','mrossi',2,'S',0,'2026-09-16 05:59:15'),
(87,42,'T',1,0,0,1,2,NULL,'SYSTEM',11,'U',0,'2026-07-19 05:59:15'),
(88,42,'T',4,4,1,1,2,'{\"team\":1}','gverdi',4,'S',0,'2026-07-19 05:59:15'),
(89,43,'T',1,0,0,3,10,NULL,'SYSTEM',5,'U',0,'2026-10-02 05:59:15'),
(90,43,'T',4,2,0,3,10,'{\"claim\":true}','mrossi',2,'S',0,'2026-10-02 05:59:15'),
(91,43,'T',8,2,0,3,10,NULL,'mrossi',2,'S',0,'2026-10-02 05:59:15'),
(92,44,'T',1,0,0,1,1,NULL,'SYSTEM',8,'U',0,'2026-08-02 05:59:15'),
(93,44,'T',4,3,0,1,1,'{\"claim\":true}','lbianchi',3,'S',0,'2026-08-02 05:59:15'),
(94,45,'T',1,0,0,1,2,NULL,'SYSTEM',9,'U',0,'2026-07-24 05:59:15'),
(95,45,'T',4,4,0,1,2,'{\"claim\":true}','gverdi',4,'S',0,'2026-07-24 05:59:15'),
(96,46,'T',1,0,0,1,1,NULL,'SYSTEM',3,'U',0,'2026-09-16 05:59:15'),
(97,46,'T',4,2,0,1,1,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-16 05:59:15'),
(98,47,'T',1,0,0,3,10,NULL,'SYSTEM',5,'U',0,'2026-08-28 05:59:15'),
(99,47,'T',4,2,0,3,10,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-28 05:59:15'),
(100,48,'T',1,0,0,1,1,NULL,'SYSTEM',4,'U',0,'2026-09-26 05:59:15'),
(101,48,'T',4,2,0,1,1,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-26 05:59:15'),
(102,49,'T',1,0,0,1,1,NULL,'SYSTEM',8,'U',0,'2026-07-18 05:59:15'),
(103,49,'T',4,4,1,1,1,'{\"team\":1}','gverdi',4,'S',0,'2026-07-18 05:59:15'),
(104,50,'T',1,0,0,3,10,NULL,'SYSTEM',7,'U',0,'2026-09-16 05:59:15'),
(105,50,'T',4,2,0,3,10,'{\"claim\":true}','mrossi',2,'S',0,'2026-09-16 05:59:15'),
(106,51,'T',1,0,0,1,2,NULL,'SYSTEM',8,'U',0,'2026-08-27 05:59:15'),
(107,52,'T',1,0,0,3,10,NULL,'SYSTEM',12,'U',0,'2026-07-23 05:59:15'),
(108,52,'T',4,3,0,3,10,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-23 05:59:15'),
(109,53,'T',1,0,0,1,11,NULL,'SYSTEM',3,'U',0,'2026-08-08 05:59:15'),
(110,53,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-08 05:59:16'),
(111,54,'T',1,0,0,1,11,NULL,'SYSTEM',7,'U',0,'2026-08-26 05:59:16'),
(112,54,'T',4,3,0,1,11,'{\"claim\":true}','lbianchi',3,'S',0,'2026-08-26 05:59:16'),
(113,55,'T',1,0,0,1,2,NULL,'SYSTEM',7,'U',0,'2026-08-09 05:59:16'),
(114,55,'T',4,2,0,1,2,'{\"claim\":true}','mrossi',2,'S',0,'2026-08-09 05:59:16'),
(115,56,'T',1,0,0,1,11,NULL,'SYSTEM',5,'U',0,'2026-07-12 05:59:16'),
(116,56,'T',4,2,0,1,11,'{\"claim\":true}','mrossi',2,'S',0,'2026-07-12 05:59:16'),
(117,57,'T',1,0,0,1,2,NULL,'SYSTEM',13,'U',0,'2026-08-12 05:59:16'),
(118,57,'T',4,4,0,1,2,'{\"claim\":true}','gverdi',4,'S',0,'2026-08-12 05:59:16'),
(119,58,'T',1,0,0,1,11,NULL,'SYSTEM',6,'U',0,'2026-07-22 05:59:16'),
(120,58,'T',4,4,0,1,11,'{\"claim\":true}','gverdi',4,'S',0,'2026-07-22 05:59:16'),
(121,59,'T',1,0,0,3,10,NULL,'SYSTEM',5,'U',0,'2026-07-31 05:59:16'),
(122,59,'T',4,3,0,3,10,'{\"claim\":true}','lbianchi',3,'S',0,'2026-07-31 05:59:16'),
(123,59,'T',8,3,0,3,10,NULL,'lbianchi',3,'S',0,'2026-07-31 05:59:16'),
(124,60,'T',1,0,0,1,11,NULL,'SYSTEM',9,'U',0,'2026-08-12 05:59:16'),
(125,60,'T',4,4,0,1,11,'{\"claim\":true}','gverdi',4,'S',0,'2026-08-12 05:59:16'),
(126,61,'T',1,0,0,1,1,NULL,'SYSTEM',10,'U',0,'2026-09-27 05:59:16'),
(127,61,'T',4,5,0,1,1,'{\"claim\":true}','aesposito',5,'S',0,'2026-09-27 05:59:16'),
(128,62,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(129,62,'A',4,4,0,1,0,'{\"staff\":[4,{\"format\":\"full\",\"parts\":{\"first\":\"Giulia\",\"last\":\"Verdi\"},\"name\":\"Giulia Verdi\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(130,63,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(131,63,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(132,64,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(133,64,'A',4,3,0,1,0,'{\"staff\":[3,{\"format\":\"full\",\"parts\":{\"first\":\"Laura\",\"last\":\"Bianchi\"},\"name\":\"Laura Bianchi\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(134,65,'A',1,0,0,3,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(135,65,'A',4,5,0,3,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(136,65,'A',2,5,0,3,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(137,66,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(138,66,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(139,67,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(140,67,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(141,68,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(142,68,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(143,69,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(144,69,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(145,69,'A',2,5,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(146,70,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:26'),
(147,70,'A',4,3,0,1,0,'{\"staff\":[3,{\"format\":\"full\",\"parts\":{\"first\":\"Laura\",\"last\":\"Bianchi\"},\"name\":\"Laura Bianchi\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:26'),
(148,71,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:27'),
(149,71,'A',4,5,0,1,0,'{\"staff\":[5,{\"format\":\"full\",\"parts\":{\"first\":\"Antonio\",\"last\":\"Esposito\"},\"name\":\"Antonio Esposito\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:27'),
(150,72,'A',1,0,0,3,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:27'),
(151,72,'A',4,2,0,3,0,'{\"staff\":[2,{\"format\":\"full\",\"parts\":{\"first\":\"Mario\",\"last\":\"Rossi\"},\"name\":\"Mario Rossi\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:27'),
(152,73,'A',1,0,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:27'),
(153,73,'A',4,2,0,1,0,'{\"staff\":[2,{\"format\":\"full\",\"parts\":{\"first\":\"Mario\",\"last\":\"Rossi\"},\"name\":\"Mario Rossi\"}]}','devadmin',1,'S',0,'2026-10-09 10:44:27'),
(154,73,'A',2,2,0,1,0,NULL,'devadmin',1,'S',0,'2026-10-09 10:44:27');
/*!40000 ALTER TABLE `ost_thread_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_thread_referral`
--

DROP TABLE IF EXISTS `ost_thread_referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_thread_referral` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) unsigned NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `object_type` char(1) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ref` (`object_id`,`object_type`,`thread_id`),
  KEY `thread_id` (`thread_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_thread_referral`
--

LOCK TABLES `ost_thread_referral` WRITE;
/*!40000 ALTER TABLE `ost_thread_referral` DISABLE KEYS */;
INSERT INTO `ost_thread_referral` VALUES
(1,2,2,'S','2026-10-09 05:59:14'),
(2,5,2,'S','2026-10-09 05:59:14'),
(3,16,3,'S','2026-10-09 05:59:14'),
(4,33,3,'S','2026-10-09 05:59:15'),
(5,37,2,'S','2026-10-09 05:59:15'),
(6,41,2,'S','2026-10-09 05:59:15');
/*!40000 ALTER TABLE `ost_thread_referral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_ticket`
--

DROP TABLE IF EXISTS `ost_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_ticket` (
  `ticket_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_pid` int(11) unsigned DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_email_id` int(11) unsigned NOT NULL DEFAULT 0,
  `status_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `email_id` int(11) unsigned NOT NULL DEFAULT 0,
  `lock_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  `source` enum('Web','Email','Phone','API','Other') NOT NULL DEFAULT 'Other',
  `source_extra` varchar(40) DEFAULT NULL,
  `isoverdue` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `isanswered` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `duedate` datetime DEFAULT NULL,
  `est_duedate` datetime DEFAULT NULL,
  `reopened` datetime DEFAULT NULL,
  `closed` datetime DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `user_id` (`user_id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`),
  KEY `team_id` (`team_id`),
  KEY `status_id` (`status_id`),
  KEY `created` (`created`),
  KEY `closed` (`closed`),
  KEY `duedate` (`duedate`),
  KEY `topic_id` (`topic_id`),
  KEY `sla_id` (`sla_id`),
  KEY `ticket_pid` (`ticket_pid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_ticket`
--

LOCK TABLES `ost_ticket` WRITE;
/*!40000 ALTER TABLE `ost_ticket` DISABLE KEYS */;
INSERT INTO `ost_ticket` VALUES
(1,NULL,'247301',1,0,1,1,1,1,0,0,0,0,0,0,'127.0.0.1','Web',NULL,0,0,NULL,'2026-10-13 06:22:17',NULL,NULL,'2026-10-08 06:22:17','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,NULL,'390395',4,0,3,1,1,11,2,0,0,0,0,0,'10.20.9.198','Email',NULL,0,0,NULL,'2026-08-16 06:00:00',NULL,'2026-08-12 05:59:14','2026-08-11 05:59:14','2026-08-10 22:59:14','2026-08-11 05:59:14'),
(3,NULL,'636845',10,0,1,1,1,11,2,0,0,0,0,0,'10.20.3.46','Phone',NULL,0,1,NULL,'2026-09-11 06:00:00',NULL,NULL,'2026-09-06 05:59:14','2026-09-06 03:59:14','2026-09-06 05:59:14'),
(4,NULL,'958530',12,0,1,3,1,10,3,0,0,0,0,0,'10.20.6.195','Email',NULL,1,0,NULL,'2026-10-03 06:00:00',NULL,NULL,'2026-09-28 05:59:14','2026-09-28 00:59:14','2026-09-28 05:59:14'),
(5,NULL,'926134',8,0,3,1,1,2,2,0,0,0,0,0,'10.20.4.117','Web',NULL,0,0,NULL,'2026-08-16 06:00:00',NULL,'2026-08-12 05:59:14','2026-08-11 05:59:14','2026-08-11 04:59:14','2026-08-11 05:59:14'),
(6,NULL,'655927',7,0,1,1,1,11,2,0,0,0,0,0,'10.20.9.105','Phone',NULL,0,1,NULL,'2026-10-11 06:00:00',NULL,NULL,'2026-10-06 05:59:14','2026-10-06 00:59:14','2026-10-06 05:59:14'),
(7,NULL,'394495',9,0,1,3,1,10,5,0,0,0,0,0,'10.20.7.200','Web',NULL,0,0,NULL,'2026-07-18 06:00:00',NULL,NULL,'2026-07-13 05:59:14','2026-07-13 04:59:14','2026-07-13 05:59:14'),
(8,NULL,'341214',9,0,1,3,1,10,5,0,0,0,0,0,'10.20.2.9','API',NULL,0,1,NULL,'2026-09-21 06:00:00',NULL,NULL,'2026-09-16 05:59:14','2026-09-16 05:59:14','2026-09-16 05:59:14'),
(9,NULL,'896022',3,0,1,1,1,2,0,0,0,0,0,0,'10.20.6.223','Email',NULL,0,0,NULL,'2026-08-03 06:00:00',NULL,NULL,'2026-07-29 05:59:14','2026-07-29 05:59:14','2026-07-29 05:59:14'),
(10,NULL,'139774',10,0,1,3,1,10,5,0,0,0,0,0,'10.20.2.26','Email',NULL,0,0,NULL,'2026-08-29 06:00:00',NULL,NULL,'2026-08-24 05:59:14','2026-08-23 21:59:14','2026-08-24 05:59:14'),
(11,NULL,'668749',8,0,1,1,1,1,3,0,0,0,0,0,'10.20.2.136','Phone',NULL,0,0,NULL,'2026-08-03 06:00:00',NULL,NULL,'2026-07-29 05:59:14','2026-07-28 23:59:14','2026-07-29 05:59:14'),
(12,NULL,'753017',3,0,1,1,1,2,5,0,0,0,0,0,'10.20.6.74','Web',NULL,0,0,NULL,'2026-09-26 06:00:00',NULL,NULL,'2026-09-21 05:59:14','2026-09-20 23:59:14','2026-09-21 05:59:14'),
(13,NULL,'340049',13,0,1,1,1,1,3,0,0,0,0,0,'10.20.4.200','Web',NULL,0,1,NULL,'2026-07-18 06:00:00',NULL,NULL,'2026-07-13 05:59:14','2026-07-13 04:59:14','2026-07-13 05:59:14'),
(14,NULL,'537052',10,0,1,1,1,11,5,0,0,0,0,0,'10.20.1.55','Phone',NULL,0,0,NULL,'2026-08-15 06:00:00',NULL,NULL,'2026-08-10 05:59:14','2026-08-09 20:59:14','2026-08-10 05:59:14'),
(15,NULL,'289251',10,0,1,1,1,2,5,0,0,0,0,0,'10.20.6.30','Web',NULL,0,0,NULL,'2026-07-26 06:00:00',NULL,NULL,'2026-07-21 05:59:14','2026-07-20 23:59:14','2026-07-21 05:59:14'),
(16,NULL,'899763',12,0,3,1,1,11,3,0,0,0,0,0,'10.20.2.239','Web',NULL,0,0,NULL,'2026-07-31 06:00:00',NULL,'2026-07-27 05:59:14','2026-07-26 05:59:14','2026-07-26 00:59:14','2026-07-26 05:59:14'),
(17,NULL,'241142',4,0,1,3,1,10,0,1,0,0,0,0,'10.20.8.165','Email',NULL,0,0,NULL,'2026-09-16 06:00:00',NULL,NULL,'2026-09-11 05:59:14','2026-09-10 22:59:14','2026-09-11 05:59:14'),
(18,NULL,'247087',8,0,1,1,1,2,0,0,0,0,0,0,'10.20.6.237','Web',NULL,0,0,NULL,'2026-09-01 06:00:00',NULL,NULL,'2026-08-27 05:59:14','2026-08-27 02:59:14','2026-08-27 05:59:14'),
(19,NULL,'885820',11,0,1,3,1,10,5,0,0,0,0,0,'10.20.3.3','API',NULL,0,0,NULL,'2026-09-29 06:00:00',NULL,NULL,'2026-09-24 05:59:14','2026-09-23 22:59:14','2026-09-24 05:59:14'),
(20,NULL,'148075',8,0,1,1,1,11,3,0,0,0,0,0,'10.20.1.35','Web',NULL,0,0,NULL,'2026-08-01 06:00:00',NULL,NULL,'2026-07-27 05:59:14','2026-07-26 22:59:14','2026-07-27 05:59:14'),
(21,NULL,'930834',4,0,1,1,1,1,2,0,0,0,0,0,'10.20.5.208','API',NULL,0,1,NULL,'2026-08-02 06:00:00',NULL,NULL,'2026-07-28 05:59:14','2026-07-27 23:59:14','2026-07-28 05:59:14'),
(22,NULL,'854315',10,0,1,3,1,10,4,0,0,0,0,0,'10.20.5.160','Web',NULL,0,0,NULL,'2026-08-11 06:00:00',NULL,NULL,'2026-08-06 05:59:14','2026-08-06 00:59:14','2026-08-06 05:59:14'),
(23,NULL,'647566',3,0,1,1,1,11,5,0,0,0,0,0,'10.20.5.73','Email',NULL,0,0,NULL,'2026-10-10 06:00:00',NULL,NULL,'2026-10-05 05:59:14','2026-10-05 03:59:14','2026-10-05 05:59:14'),
(24,NULL,'915323',2,0,1,1,1,2,5,0,0,0,0,0,'10.20.2.173','Web',NULL,0,0,NULL,'2026-09-29 06:00:00',NULL,NULL,'2026-09-24 05:59:14','2026-09-23 21:59:14','2026-09-24 05:59:14'),
(25,NULL,'838444',12,0,1,3,1,10,3,0,0,0,0,0,'10.20.2.117','Phone',NULL,1,0,NULL,'2026-07-24 06:00:00',NULL,NULL,'2026-07-19 05:59:15','2026-07-19 05:59:14','2026-07-19 05:59:15'),
(26,NULL,'581759',2,0,1,1,1,2,4,0,0,0,0,0,'10.20.8.142','Phone',NULL,0,0,NULL,'2026-10-12 06:00:00',NULL,NULL,'2026-10-07 05:59:15','2026-10-07 05:59:15','2026-10-07 05:59:15'),
(27,NULL,'853680',2,0,1,3,1,10,5,0,0,0,0,0,'10.20.1.79','API',NULL,0,0,NULL,'2026-07-25 06:00:00',NULL,NULL,'2026-07-20 05:59:15','2026-07-20 02:59:15','2026-07-20 05:59:15'),
(28,NULL,'820971',13,0,1,1,1,1,3,0,0,0,0,0,'10.20.4.102','Phone',NULL,0,1,NULL,'2026-09-25 06:00:00',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 00:59:15','2026-09-20 05:59:15'),
(29,NULL,'213831',11,0,1,1,1,2,5,0,0,0,0,0,'10.20.2.64','Phone',NULL,0,0,NULL,'2026-09-05 06:00:00',NULL,NULL,'2026-08-31 05:59:15','2026-08-31 05:59:15','2026-08-31 05:59:15'),
(30,NULL,'973732',3,0,1,1,1,2,0,0,0,0,0,0,'10.20.3.65','Web',NULL,0,0,NULL,'2026-09-16 06:00:00',NULL,NULL,'2026-09-11 05:59:15','2026-09-10 21:59:15','2026-09-11 05:59:15'),
(31,NULL,'699697',12,0,1,1,1,11,5,0,0,0,0,0,'10.20.8.215','Email',NULL,0,0,NULL,'2026-10-13 06:00:00',NULL,NULL,'2026-10-08 05:59:15','2026-10-08 05:59:15','2026-10-08 05:59:15'),
(32,NULL,'476002',5,0,1,1,1,2,4,0,0,0,0,0,'10.20.6.170','Phone',NULL,0,0,NULL,'2026-09-11 06:00:00',NULL,NULL,'2026-09-06 05:59:15','2026-09-05 23:59:15','2026-09-06 05:59:15'),
(33,NULL,'394713',5,0,3,1,1,1,3,0,0,0,0,0,'10.20.4.166','Web',NULL,0,0,NULL,'2026-08-03 06:00:00',NULL,'2026-07-30 05:59:15','2026-07-29 05:59:15','2026-07-28 23:59:15','2026-07-29 05:59:15'),
(34,NULL,'122134',10,0,1,1,1,11,5,0,0,0,0,0,'10.20.1.136','Phone',NULL,0,0,NULL,'2026-09-25 06:00:00',NULL,NULL,'2026-09-20 05:59:15','2026-09-20 01:59:15','2026-09-20 05:59:15'),
(35,NULL,'382601',7,0,1,1,1,1,3,0,0,0,0,0,'10.20.3.103','Email',NULL,1,0,NULL,'2026-10-06 06:00:00',NULL,NULL,'2026-10-01 05:59:15','2026-09-30 20:59:15','2026-10-01 05:59:15'),
(36,NULL,'444625',5,0,1,1,1,11,2,0,0,0,0,0,'10.20.7.146','Email',NULL,0,1,NULL,'2026-09-15 06:00:00',NULL,NULL,'2026-09-10 05:59:15','2026-09-09 20:59:15','2026-09-10 05:59:15'),
(37,NULL,'819979',10,0,3,1,1,11,2,0,0,0,0,0,'10.20.4.122','Phone',NULL,0,0,NULL,'2026-08-09 06:00:00',NULL,'2026-08-05 05:59:15','2026-08-04 05:59:15','2026-08-03 22:59:15','2026-08-04 05:59:15'),
(38,NULL,'704370',12,0,1,1,1,11,5,0,0,0,0,0,'10.20.1.95','API',NULL,0,1,NULL,'2026-07-20 06:00:00',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 02:59:15','2026-07-15 05:59:15'),
(39,NULL,'599363',6,0,1,3,1,10,2,0,0,0,0,0,'10.20.3.233','Phone',NULL,0,1,NULL,'2026-08-12 06:00:00',NULL,NULL,'2026-08-07 05:59:15','2026-08-07 01:59:15','2026-08-07 05:59:15'),
(40,NULL,'543523',7,0,1,1,1,11,0,0,0,0,0,0,'10.20.4.60','API',NULL,0,0,NULL,'2026-07-20 06:00:00',NULL,NULL,'2026-07-15 05:59:15','2026-07-15 03:59:15','2026-07-15 05:59:15'),
(41,NULL,'214892',5,0,3,1,1,11,2,0,0,0,0,0,'10.20.9.9','Web',NULL,0,0,NULL,'2026-09-21 06:00:00',NULL,'2026-09-17 05:59:15','2026-09-16 05:59:15','2026-09-15 23:59:15','2026-09-16 05:59:15'),
(42,NULL,'960957',11,0,1,1,1,2,0,1,0,0,0,0,'10.20.6.22','Web',NULL,0,0,NULL,'2026-07-24 06:00:00',NULL,NULL,'2026-07-19 05:59:15','2026-07-18 23:59:15','2026-07-19 05:59:15'),
(43,NULL,'683843',5,0,1,3,1,10,2,0,0,0,0,0,'10.20.9.149','Email',NULL,1,0,NULL,'2026-10-07 06:00:00',NULL,NULL,'2026-10-02 05:59:15','2026-10-01 23:59:15','2026-10-02 05:59:15'),
(44,NULL,'702612',8,0,1,1,1,1,3,0,0,0,0,0,'10.20.1.208','Web',NULL,0,0,NULL,'2026-08-07 06:00:00',NULL,NULL,'2026-08-02 05:59:15','2026-08-02 01:59:15','2026-08-02 05:59:15'),
(45,NULL,'226810',9,0,1,1,1,2,4,0,0,0,0,0,'10.20.8.205','Phone',NULL,0,1,NULL,'2026-07-29 06:00:00',NULL,NULL,'2026-07-24 05:59:15','2026-07-24 03:59:15','2026-07-24 05:59:15'),
(46,NULL,'305907',3,0,1,1,1,1,2,0,0,0,0,0,'10.20.4.77','Email',NULL,0,1,NULL,'2026-09-21 06:00:00',NULL,NULL,'2026-09-16 05:59:15','2026-09-15 21:59:15','2026-09-16 05:59:15'),
(47,NULL,'420192',5,0,1,3,1,10,2,0,0,0,0,0,'10.20.5.29','Email',NULL,0,1,NULL,'2026-09-02 06:00:00',NULL,NULL,'2026-08-28 05:59:15','2026-08-28 04:59:15','2026-08-28 05:59:15'),
(48,NULL,'223782',4,0,1,1,1,1,2,0,0,0,0,0,'10.20.8.84','API',NULL,0,0,NULL,'2026-10-01 06:00:00',NULL,NULL,'2026-09-26 05:59:15','2026-09-25 20:59:15','2026-09-26 05:59:15'),
(49,NULL,'224835',8,0,1,1,1,1,0,1,0,0,0,0,'10.20.4.32','API',NULL,0,0,NULL,'2026-07-23 06:00:00',NULL,NULL,'2026-07-18 05:59:15','2026-07-17 21:59:15','2026-07-18 05:59:15'),
(50,NULL,'305894',7,0,1,3,1,10,2,0,0,0,0,0,'10.20.4.239','Web',NULL,0,1,NULL,'2026-09-21 06:00:00',NULL,NULL,'2026-09-16 05:59:15','2026-09-15 22:59:15','2026-09-16 05:59:15'),
(51,NULL,'767502',8,0,1,1,1,2,0,0,0,0,0,0,'10.20.9.202','Phone',NULL,0,0,NULL,'2026-09-01 06:00:00',NULL,NULL,'2026-08-27 05:59:15','2026-08-27 00:59:15','2026-08-27 05:59:15'),
(52,NULL,'441565',12,0,1,3,1,10,3,0,0,0,0,0,'10.20.6.89','API',NULL,0,0,NULL,'2026-07-28 06:00:00',NULL,NULL,'2026-07-23 05:59:15','2026-07-22 23:59:15','2026-07-23 05:59:15'),
(53,NULL,'762918',3,0,1,1,1,11,2,0,0,0,0,0,'10.20.4.219','API',NULL,0,0,NULL,'2026-08-13 06:00:00',NULL,NULL,'2026-08-08 05:59:15','2026-08-08 05:59:15','2026-08-08 05:59:15'),
(54,NULL,'414769',7,0,1,1,1,11,3,0,0,0,0,0,'10.20.3.93','Web',NULL,0,0,NULL,'2026-08-31 06:00:00',NULL,NULL,'2026-08-26 05:59:16','2026-08-25 22:59:16','2026-08-26 05:59:16'),
(55,NULL,'554187',7,0,1,1,1,2,2,0,0,0,0,0,'10.20.1.106','API',NULL,0,0,NULL,'2026-08-14 06:00:00',NULL,NULL,'2026-08-09 05:59:16','2026-08-09 00:59:16','2026-08-09 05:59:16'),
(56,NULL,'535972',5,0,1,1,1,11,2,0,0,0,0,0,'10.20.7.176','Phone',NULL,0,1,NULL,'2026-07-17 06:00:00',NULL,NULL,'2026-07-12 05:59:16','2026-07-12 03:59:16','2026-07-12 05:59:16'),
(57,NULL,'950873',13,0,1,1,1,2,4,0,0,0,0,0,'10.20.2.104','Phone',NULL,0,0,NULL,'2026-08-17 06:00:00',NULL,NULL,'2026-08-12 05:59:16','2026-08-12 05:59:16','2026-08-12 05:59:16'),
(58,NULL,'671799',6,0,1,1,1,11,4,0,0,0,0,0,'10.20.1.108','API',NULL,0,0,NULL,'2026-07-27 06:00:00',NULL,NULL,'2026-07-22 05:59:16','2026-07-22 02:59:16','2026-07-22 05:59:16'),
(59,NULL,'103500',5,0,1,3,1,10,3,0,0,0,0,0,'10.20.1.142','Web',NULL,1,0,NULL,'2026-08-05 06:00:00',NULL,NULL,'2026-07-31 05:59:16','2026-07-30 22:59:16','2026-07-31 05:59:16'),
(60,NULL,'423938',9,0,1,1,1,11,4,0,0,0,0,0,'10.20.6.23','Phone',NULL,0,1,NULL,'2026-08-17 06:00:00',NULL,NULL,'2026-08-12 05:59:16','2026-08-11 22:59:16','2026-08-12 05:59:16'),
(61,NULL,'916831',10,0,1,1,1,1,5,0,0,0,0,0,'10.20.7.199','Email',NULL,0,1,NULL,'2026-10-02 06:00:00',NULL,NULL,'2026-09-27 05:59:16','2026-09-26 23:59:16','2026-09-27 05:59:16');
/*!40000 ALTER TABLE `ost_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_ticket__cdata`
--

DROP TABLE IF EXISTS `ost_ticket__cdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_ticket__cdata` (
  `ticket_id` int(11) unsigned NOT NULL,
  `subject` mediumtext DEFAULT NULL,
  `priority` mediumtext DEFAULT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_ticket__cdata`
--

LOCK TABLES `ost_ticket__cdata` WRITE;
/*!40000 ALTER TABLE `ost_ticket__cdata` DISABLE KEYS */;
INSERT INTO `ost_ticket__cdata` VALUES
(1,'osTicket Installed!',NULL),
(2,'Badge non abilitato al varco','2'),
(3,'Richiesta nuovo account per specializzando','1'),
(4,'Monitor guasto postazione triage','3'),
(5,'Errore invio ordine al magazzino','3'),
(6,'Referti LIS non arrivano in cartella','2'),
(7,'Stampante del reparto non stampa','3'),
(8,'Monitor guasto postazione triage','1'),
(9,'Badge non abilitato al varco','1'),
(10,'Badge non abilitato al varco','2'),
(11,'Accesso al FSE non funziona','3'),
(12,'Casella email piena','2'),
(13,'Errore invio ordine al magazzino','3'),
(14,'Badge non abilitato al varco','2'),
(15,'Richiesta installazione software DICOM viewer','4'),
(16,'Stampante del reparto non stampa','3'),
(17,'Monitor guasto postazione triage','3'),
(18,'Casella email piena','2'),
(19,'Referti LIS non arrivano in cartella','4'),
(20,'Referti LIS non arrivano in cartella','1'),
(21,'Errore invio ordine al magazzino','2'),
(22,'PC lentissimo in ambulatorio 3','2'),
(23,'Stampante del reparto non stampa','3'),
(24,'Casella email piena','3'),
(25,'Referti LIS non arrivano in cartella','2'),
(26,'Telefono IP senza linea','2'),
(27,'PC lentissimo in ambulatorio 3','2'),
(28,'Richiesta nuovo account per specializzando','2'),
(29,'Stampante del reparto non stampa','2'),
(30,'Monitor guasto postazione triage','3'),
(31,'PC lentissimo in ambulatorio 3','4'),
(32,'Badge non abilitato al varco','3'),
(33,'Wi-Fi assente in sala riunioni','3'),
(34,'Casella email piena','1'),
(35,'Richiesta nuovo account per specializzando','2'),
(36,'Monitor guasto postazione triage','3'),
(37,'Richiesta installazione software DICOM viewer','2'),
(38,'PC lentissimo in ambulatorio 3','4'),
(39,'Monitor guasto postazione triage','1'),
(40,'PC lentissimo in ambulatorio 3','2'),
(41,'Accesso al FSE non funziona','1'),
(42,'PC lentissimo in ambulatorio 3','3'),
(43,'Wi-Fi assente in sala riunioni','2'),
(44,'Badge non abilitato al varco','2'),
(45,'Monitor guasto postazione triage','2'),
(46,'Richiesta nuovo account per specializzando','3'),
(47,'Monitor guasto postazione triage','4'),
(48,'Monitor guasto postazione triage','4'),
(49,'Wi-Fi assente in sala riunioni','2'),
(50,'Stampante del reparto non stampa','2'),
(51,'Monitor guasto postazione triage','4'),
(52,'PC lentissimo in ambulatorio 3','2'),
(53,'Richiesta installazione software DICOM viewer','1'),
(54,'Errore invio ordine al magazzino','3'),
(55,'Monitor guasto postazione triage','1'),
(56,'Badge non abilitato al varco','2'),
(57,'Accesso al FSE non funziona','1'),
(58,'PC lentissimo in ambulatorio 3','2'),
(59,'Accesso al FSE non funziona','2'),
(60,'Richiesta nuovo account per specializzando','2'),
(61,'Errore invio ordine al magazzino','4');
/*!40000 ALTER TABLE `ost_ticket__cdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_ticket_priority`
--

DROP TABLE IF EXISTS `ost_ticket_priority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_ticket_priority` (
  `priority_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `priority` varchar(60) NOT NULL DEFAULT '',
  `priority_desc` varchar(30) NOT NULL DEFAULT '',
  `priority_color` varchar(7) NOT NULL DEFAULT '',
  `priority_urgency` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `ispublic` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`priority_id`),
  UNIQUE KEY `priority` (`priority`),
  KEY `priority_urgency` (`priority_urgency`),
  KEY `ispublic` (`ispublic`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_ticket_priority`
--

LOCK TABLES `ost_ticket_priority` WRITE;
/*!40000 ALTER TABLE `ost_ticket_priority` DISABLE KEYS */;
INSERT INTO `ost_ticket_priority` VALUES
(1,'low','Low','#DDFFDD',4,1),
(2,'normal','Normal','#FFFFF0',3,1),
(3,'high','High','#FEE7E7',2,1),
(4,'emergency','Emergency','#FEE7E7',1,1);
/*!40000 ALTER TABLE `ost_ticket_priority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_ticket_status`
--

DROP TABLE IF EXISTS `ost_ticket_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_ticket_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `state` varchar(16) DEFAULT NULL,
  `mode` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `properties` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_ticket_status`
--

LOCK TABLES `ost_ticket_status` WRITE;
/*!40000 ALTER TABLE `ost_ticket_status` DISABLE KEYS */;
INSERT INTO `ost_ticket_status` VALUES
(1,'Open','open',3,0,1,'{\"description\":\"Open tickets.\"}','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(2,'Resolved','closed',1,0,2,'{\"allowreopen\":true,\"reopenstatus\":0,\"description\":\"Resolved tickets\"}','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(3,'Closed','closed',3,0,3,'{\"allowreopen\":true,\"reopenstatus\":0,\"description\":\"Closed tickets. Tickets will still be accessible on client and staff panels.\"}','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(4,'Archived','archived',3,0,4,'{\"description\":\"Tickets only adminstratively available but no longer accessible on ticket queues and client panel.\"}','2026-10-08 06:22:17','0000-00-00 00:00:00'),
(5,'Deleted','deleted',3,0,5,'{\"description\":\"Tickets queued for deletion. Not accessible on ticket queues.\"}','2026-10-08 06:22:17','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `ost_ticket_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_translation`
--

DROP TABLE IF EXISTS `ost_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_translation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_hash` char(16) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `type` enum('phrase','article','override') DEFAULT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `revision` int(11) unsigned DEFAULT NULL,
  `agent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `lang` varchar(16) NOT NULL DEFAULT '',
  `text` mediumtext NOT NULL,
  `source_text` text DEFAULT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`lang`),
  KEY `object_hash` (`object_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_translation`
--

LOCK TABLES `ost_translation` WRITE;
/*!40000 ALTER TABLE `ost_translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_user`
--

DROP TABLE IF EXISTS `ost_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` int(10) unsigned NOT NULL,
  `default_email_id` int(10) NOT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `default_email_id` (`default_email_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_user`
--

LOCK TABLES `ost_user` WRITE;
/*!40000 ALTER TABLE `ost_user` DISABLE KEYS */;
INSERT INTO `ost_user` VALUES
(1,1,1,0,'osTicket Team','2026-10-08 06:22:17','2026-10-08 06:22:17'),
(2,2,2,0,'Francesca Romano','2026-10-09 05:59:02','2026-10-09 05:59:03'),
(3,3,3,0,'Luca Ferrari','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(4,4,4,0,'Sara Colombo','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(5,5,5,0,'Paolo Ricci','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(6,6,6,0,'Elena Marino','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(7,2,7,0,'Davide Greco','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(8,3,8,0,'Chiara Bruno','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(9,4,9,0,'Marco Gallo','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(10,5,10,0,'Anna Conti','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(11,6,11,0,'Giorgio De Luca','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(12,2,12,0,'Martina Costa','2026-10-09 05:59:03','2026-10-09 05:59:03'),
(13,3,13,0,'Stefano Giordano','2026-10-09 05:59:03','2026-10-09 05:59:03');
/*!40000 ALTER TABLE `ost_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_user__cdata`
--

DROP TABLE IF EXISTS `ost_user__cdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_user__cdata` (
  `user_id` int(11) unsigned NOT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `phone` mediumtext DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_user__cdata`
--

LOCK TABLES `ost_user__cdata` WRITE;
/*!40000 ALTER TABLE `ost_user__cdata` DISABLE KEYS */;
INSERT INTO `ost_user__cdata` VALUES
(2,NULL,NULL,'0874479717',''),
(3,NULL,NULL,'0874412492',''),
(4,NULL,NULL,'0874432615',''),
(5,NULL,NULL,'0874489202',''),
(6,NULL,NULL,'0874423159',''),
(7,NULL,NULL,'0874486930',''),
(8,NULL,NULL,'0874443743',''),
(9,NULL,NULL,'0874417379',''),
(10,NULL,NULL,'0874481295',''),
(11,NULL,NULL,'0874461528',''),
(12,NULL,NULL,'0874494187',''),
(13,NULL,NULL,'0874484635','');
/*!40000 ALTER TABLE `ost_user__cdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_user_account`
--

DROP TABLE IF EXISTS `ost_user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_user_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `timezone` varchar(64) DEFAULT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `passwd` varchar(128) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `registered` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_user_account`
--

LOCK TABLES `ost_user_account` WRITE;
/*!40000 ALTER TABLE `ost_user_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ost_user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ost_user_email`
--

DROP TABLE IF EXISTS `ost_user_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ost_user_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `user_email_lookup` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_user_email`
--

LOCK TABLES `ost_user_email` WRITE;
/*!40000 ALTER TABLE `ost_user_email` DISABLE KEYS */;
INSERT INTO `ost_user_email` VALUES
(1,1,0,'feedback@osticket.com'),
(2,2,0,'f.romano@ospedale.example'),
(3,3,0,'l.ferrari@ospedale.example'),
(4,4,0,'s.colombo@ospedale.example'),
(5,5,0,'p.ricci@ospedale.example'),
(6,6,0,'e.marino@ospedale.example'),
(7,7,0,'d.greco@ospedale.example'),
(8,8,0,'c.bruno@ospedale.example'),
(9,9,0,'m.gallo@ospedale.example'),
(10,10,0,'a.conti@ospedale.example'),
(11,11,0,'g.deluca@ospedale.example'),
(12,12,0,'m.costa@ospedale.example'),
(13,13,0,'s.giordano@ospedale.example');
/*!40000 ALTER TABLE `ost_user_email` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
